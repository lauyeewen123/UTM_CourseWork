<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headerit.php';
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <h4 class="mb-0">About Course Registration System</h4>
            </div>
        </div>
        
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <section class="mb-5">
                        <h5 class="mb-3"><i class="fas fa-info-circle me-2 text-primary"></i>System Overview</h5>
                        <p>The Course Registration System (CRS) is a comprehensive platform designed to streamline the course registration process for students and staff. This system facilitates efficient course management, student registration, and academic record keeping.</p>
                    </section>

                    <section class="mb-5">
                        <h5 class="mb-3"><i class="fas fa-cogs me-2 text-primary"></i>Key Features</h5>
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="feature-card p-3 border rounded">
                                    <h6><i class="fas fa-book me-2 text-success"></i>Course Management</h6>
                                    <p class="mb-0">Add, modify, and manage course offerings with ease.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-card p-3 border rounded">
                                    <h6><i class="fas fa-user-graduate me-2 text-success"></i>Student Registration</h6>
                                    <p class="mb-0">Streamlined registration process for students.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-card p-3 border rounded">
                                    <h6><i class="fas fa-chart-bar me-2 text-success"></i>Real-time Analytics</h6>
                                    <p class="mb-0">Monitor course capacities and registration trends.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="feature-card p-3 border rounded">
                                    <h6><i class="fas fa-shield-alt me-2 text-success"></i>Secure Access</h6>
                                    <p class="mb-0">Role-based access control for system security.</p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="mb-5">
                        <h5 class="mb-3"><i class="fas fa-code me-2 text-primary"></i>Technical Details</h5>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="fas fa-check-circle me-2 text-success"></i>Built with PHP and MySQL</li>
                            <li class="mb-2"><i class="fas fa-check-circle me-2 text-success"></i>Bootstrap 5 for responsive design</li>
                            <li class="mb-2"><i class="fas fa-check-circle me-2 text-success"></i>FontAwesome icons for enhanced UI</li>
                            <li class="mb-2"><i class="fas fa-check-circle me-2 text-success"></i>Secure session management</li>
                        </ul>
                    </section>
                </div>

                <div class="col-md-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><i class="fas fa-envelope me-2 text-primary"></i>Contact Support</h5>
                            <p class="card-text">For technical support or inquiries, please contact:</p>
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <i class="fas fa-envelope me-2"></i>
                                    support@crs.edu
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-phone me-2"></i>
                                    +60 123456789
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-clock me-2"></i>
                                    Monday - Friday, 9:00 AM - 5:00 PM
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="card mt-4">
                        <div class="card-body">
                            <h5 class="card-title mb-3"><i class="fas fa-code-branch me-2 text-primary"></i>Version Info</h5>
                            <p class="mb-2"><strong>Current Version:</strong> 1.0.0</p>
                            <p class="mb-2"><strong>Last Updated:</strong> March 2024</p>
                            <p class="mb-0"><strong>Developed by:</strong> Yeewen</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.feature-card {
    transition: all 0.3s ease;
    background-color: #fff;
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.card-title {
    color: #2c3e50;
    font-weight: 600;
}

section h5 {
    color: #2c3e50;
    font-weight: 600;
}

.list-unstyled li {
    padding: 0.5rem 0;
}
</style>

<?php include 'footer.php'; ?> 