<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}

include 'headeradvisor.php';
include 'dbconnect.php';
include 'includes/semester_helper.php';

//Get user id
$lecturer_id = $_SESSION['funame'];
$current_sem = getCurrentSemester($con);

//Retrieve all registered courses using course_assignment table
$sql = "SELECT r.r_tid, r.r_student, r.r_course, r.r_section, r.r_status, r.r_sem,
               u.u_name as student_name,
               c.c_name as course_name
        FROM tb_course_assignment ca
        INNER JOIN tb_course c ON ca.ca_course = c.c_code
        LEFT JOIN tb_registration r ON c.c_code = r.r_course
        LEFT JOIN tb_user u ON r.r_student = u.u_sno
        WHERE ca.ca_lecturer = ? 
        AND ca.ca_semester = ?
        AND ca.ca_status = 'active'
        ORDER BY r.r_sem DESC, r.r_course, u.u_name";

if ($stmt = mysqli_prepare($con, $sql)) {
    mysqli_stmt_bind_param($stmt, "ss", $lecturer_id, $current_sem);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}

// Debug
error_log("Lecturer ID: " . $lecturer_id);
error_log("Current Semester: " . $current_sem);
error_log("Number of records found: " . mysqli_num_rows($result));

?>

<div class="container py-4">
	<!-- Header Section -->
	<div class="d-flex justify-content-between align-items-center mb-4">
		<h4 class="mb-0">
			<i class="fas fa-book-reader me-2"></i>Assigned Courses and Students
		</h4>
		<div class="d-flex gap-2">
			<a href="courselist.php" class="btn btn-outline-primary">
				<i class="fas fa-th-list me-1"></i> View All Courses
			</a>
			<a href="view_student_list.php" class="btn btn-outline-primary">
				<i class="fas fa-users me-1"></i> Student Lists
			</a>
		</div>
	</div>

	<!-- Main Content -->
	<div class="card shadow-sm">
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-hover align-middle">
					<thead class="table-light">
						<tr>
							<th>Transaction ID</th>
							<th>Semester</th>
							<th>Student Info</th>
							<th>Course Info</th>
							<th>Status</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						if (mysqli_num_rows($result) > 0) {
							while($row = mysqli_fetch_assoc($result)) {
								echo "<tr>";
								echo "<td>" . htmlspecialchars($row['r_tid']) . "</td>";
								echo "<td>" . htmlspecialchars($row['r_sem']) . "</td>";
								echo "<td>
										<div class='d-flex flex-column'>
											<strong>" . htmlspecialchars($row['student_name']) . "</strong>
											<small class='text-muted'>" . htmlspecialchars($row['r_student']) . "</small>
										</div>
									  </td>";
								echo "<td>
										<div class='d-flex flex-column'>
											<strong>" . htmlspecialchars($row['course_name']) . "</strong>
											<small class='text-muted'>" . htmlspecialchars($row['r_course']) . " (Section " . htmlspecialchars($row['r_section']) . ")</small>
										</div>
									  </td>";
								echo "<td>";
								switch($row['r_status']) {
									case '1':
										echo '<span class="badge bg-warning">Pending</span>';
										break;
									case '2':
										echo '<span class="badge bg-success">Approved</span>';
										break;
									case '3':
										echo '<span class="badge bg-danger">Rejected</span>';
										break;
								}
								echo "</td>";
								echo "<td class='text-center'>
										<a href='view_student_details.php?id=" . urlencode($row['r_student']) . "' 
										   class='btn btn-primary btn-sm'>
											<i class='fas fa-eye me-1'></i> View Details
										</a>
									  </td>";
								echo "</tr>";
							}
						} else {
							echo "<tr><td colspan='6' class='text-center py-4'>No registrations found</td></tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<style>
.table th {
	font-weight: 600;
	color: #2c3e50;
}

.badge {
	padding: 0.5em 0.8em;
	font-weight: 500;
}

.btn-sm {
	padding: 0.4rem 0.8rem;
}

.card {
	border: none;
	border-radius: 10px;
}

.table-responsive {
	border-radius: 8px;
}

.table {
	margin-bottom: 0;
}

.text-muted {
	font-size: 0.875rem;
}

.btn-outline-primary {
	border-color: #4285f4;
	color: #4285f4;
}

.btn-outline-primary:hover {
	background-color: #4285f4;
	color: white;
}
</style>

<?php include 'footer.php';?>



