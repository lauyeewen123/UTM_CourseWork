<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Registration System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
  :root {
    --primary-blue: #1a73e8;      /* Google Blue */
    --hover-blue: #1557b0;        /* Darker Blue for Hover */
    --light-blue: #e8f0fe;        /* Very Light Blue */
    --white: #ffffff;
  }

  .navbar {
    background: var(--primary-blue) !important;
    padding: 1rem 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }

  .navbar-brand {
    font-size: 1.4rem;
    font-weight: 600;
    color: var(--white) !important;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .nav-link {
    color: var(--white) !important;
    padding: 0.7rem 1.2rem !important;
    border-radius: 6px;
    transition: all 0.2s ease;
    font-weight: 500;
    opacity: 0.9;
  }

  .nav-link:hover {
    background-color: rgba(255,255,255,0.1);
    opacity: 1;
  }

  .nav-link.active {
    background-color: rgba(255,255,255,0.2);
    opacity: 1;
  }

  .navbar-nav {
    gap: 0.3rem;
  }

  /* Special styling for action buttons */
  .nav-action {
    background: rgba(255,255,255,0.1);
    border-radius: 6px;
    margin: 0 0.2rem;
  }

  .nav-action:hover {
    background: rgba(255,255,255,0.2);
  }

  /* Logout button */
  .nav-link.logout {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.3);
  }

  .nav-link.logout:hover {
    background: rgba(255,255,255,0.25);
  }

  /* Mobile responsiveness */
  @media (max-width: 991.98px) {
    .navbar-nav {
      padding: 1rem 0;
    }
    .nav-link {
      padding: 0.8rem 1rem !important;
    }
  }
  </style>

</head>


<body>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="student.php">
      <i class="fas fa-graduation-cap"></i>
      CRS Student
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'student.php' ? 'active' : ''; ?>" href="student.php">
            <i class="fas fa-home me-2"></i>Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-action" href="courseregister.php">
            <i class="fas fa-plus-circle me-2"></i>Register Course
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-action" href="courseview.php">
            <i class="fas fa-list me-2"></i>View Courses
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-action" href="modifyregistration.php">
            <i class="fas fa-edit me-2"></i>Modify Registration
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link nav-action" href="editprofile.php">
            <i class="fas fa-user-edit me-2"></i>Edit Profile
          </a>
        </li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link logout" href="logout.php">
            <i class="fas fa-sign-out-alt me-2"></i>Logout
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

