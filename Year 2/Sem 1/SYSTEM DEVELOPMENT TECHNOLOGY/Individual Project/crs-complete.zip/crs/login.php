<?php include 'headermain.php';?>

<style>
:root {
    --card-border-radius: 20px;
    --input-border-radius: 12px;
}

.login-container {
    max-width: 450px;
    margin: 50px auto;
    animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

.login-card {
    border: none;
    border-radius: var(--card-border-radius);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    background: var(--white);
    overflow: hidden;
}

.login-card-header {
    background: linear-gradient(135deg, var(--primary-blue) 0%, var(--hover-blue) 100%);
    color: var(--white);
    text-align: center;
    padding: 25px;
    position: relative;
}

.login-card-header h4 {
    font-weight: 600;
    margin: 0;
    font-size: 1.5rem;
}

.login-card-header::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 5px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
}

.login-form {
    padding: 35px;
}

.user-type-selector {
    margin-bottom: 25px;
    padding: 5px;
    background: var(--light-blue);
    border-radius: var(--input-border-radius);
}

.user-type-selector .btn {
    width: 33.33%;
    padding: 12px 8px;
    border: none;
    transition: all 0.3s ease;
    font-weight: 500;
    position: relative;
    overflow: hidden;
}

.user-type-selector .btn:hover {
    transform: translateY(-1px);
}

.user-type-selector .btn.active {
    background: var(--primary-blue);
    color: var(--white);
    box-shadow: 0 4px 10px rgba(26, 115, 232, 0.2);
}

.form-control {
    border: 2px solid #e1e5ea;
    border-radius: var(--input-border-radius);
    padding: 14px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: #f8fafc;
}

.form-control:focus {
    border-color: var(--primary-blue);
    background: var(--white);
    box-shadow: 0 0 0 4px rgba(26, 115, 232, 0.1);
}

.form-label {
    font-weight: 500;
    color: #2d3748;
    margin-bottom: 8px;
}

.btn-login {
    width: 100%;
    padding: 14px;
    border-radius: var(--input-border-radius);
    font-weight: 600;
    font-size: 1.1rem;
    background: linear-gradient(135deg, var(--primary-blue) 0%, var(--hover-blue) 100%);
    border: none;
    transition: all 0.3s ease;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(26, 115, 232, 0.25);
}

.password-toggle {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #6c757d;
    z-index: 10;
    background: none;
    border: none;
    padding: 8px;
    transition: all 0.2s ease;
}

.password-toggle:hover {
    color: var(--primary-blue);
}

.alert {
    border-radius: var(--input-border-radius);
    border: none;
    padding: 15px;
    margin-bottom: 25px;
}

.alert-danger {
    background-color: #fee2e2;
    color: #dc2626;
}

.form-text {
    color: #6b7280;
    font-size: 0.875rem;
    margin-top: 6px;
}

.register-link {
    text-align: center;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #e5e7eb;
}

.register-link a {
    color: var(--primary-blue);
    text-decoration: none;
    font-weight: 500;
    transition: all 0.2s ease;
}

.register-link a:hover {
    color: var(--hover-blue);
    text-decoration: underline;
}

/* Input group improvements */
.input-group {
    position: relative;
}

.input-group .form-control {
    padding-right: 45px;
}

/* Responsive improvements */
@media (max-width: 576px) {
    .login-container {
        margin: 20px auto;
    }
    
    .login-form {
        padding: 25px;
    }
    
    .user-type-selector .btn {
        padding: 10px 5px;
        font-size: 0.9rem;
    }
    
    .btn-login {
        padding: 12px;
    }
}

/* Animation for alerts */
.alert {
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        transform: translateY(-10px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>

<div class="container login-container">
    <div class="card login-card">
        <div class="login-card-header">
            <h4 class="mb-0"><i class="fas fa-user-circle me-2"></i>User Login</h4>
        </div>
        
        <div class="login-form">
            <?php if(isset($_GET['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php 
                        if($_GET['error'] == 'invalid_credentials') {
                            echo "Invalid username or password!";
                        } else if($_GET['error'] == 'invalid_user_type') {
                            echo "Invalid user type! Please check your ID format.";
                        }
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="loginprocess.php">
                <div class="user-type-selector btn-group w-100 mb-4" role="group">
                    <input type="radio" class="btn-check" name="userType" id="student" value="student" checked>
                    <label class="btn" for="student">
                        <i class="fas fa-user-graduate me-2"></i>Student
                    </label>
                    
                    <input type="radio" class="btn-check" name="userType" id="advisor" value="advisor">
                    <label class="btn" for="advisor">
                        <i class="fas fa-chalkboard-teacher me-2"></i>Advisor
                    </label>
                    
                    <input type="radio" class="btn-check" name="userType" id="itstaff" value="itstaff">
                    <label class="btn" for="itstaff">
                        <i class="fas fa-user-cog me-2"></i>IT Staff
                    </label>
                </div>

                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-id-card me-2"></i>User ID
                    </label>
                    <input type="text" name="funame" class="form-control" required 
                           placeholder="S*** for Students, L*** for Lecturers, IT*** for IT Staff">
                    <div class="form-text">Format depends on user type selected above</div>
                </div>

                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-lock me-2"></i>Password
                    </label>
                    <div class="input-group">
                        <input type="password" name="fpwd" id="password" class="form-control" required 
                               placeholder="Enter your password">
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-login mb-3">
                    <i class="fas fa-sign-in-alt me-2"></i>Login
                </button>

                <div class="text-center mt-3">
                    <p class="mb-0">Don't have an account? 
                        <a href="register.php" class="text-primary">Register here</a>
                    </p>
                </div>

                <div class="text-center mt-3">
                    <p class="mb-0">
                        Forgot your password? <a href="forgot-password.php" class="text-primary">Reset here</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('toggleIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Update placeholder based on selected user type
document.querySelectorAll('input[name="userType"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const idInput = document.querySelector('input[name="funame"]');
        switch(this.value) {
            case 'student':
                idInput.placeholder = 'Enter Student ID (S***)';
                break;
            case 'advisor':
                idInput.placeholder = 'Enter Lecturer ID (L***)';
                break;
            case 'itstaff':
                idInput.placeholder = 'Enter IT Staff ID (IT***)';
                break;
        }
    });
});
</script>

<?php include 'footer.php';?>



