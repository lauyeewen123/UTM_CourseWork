<?php
// Check if session is not already started before calling session_start()
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('dbconnect.php');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['funame']) && isset($_POST['fpwd'])) {
    $username = trim($_POST['funame']);
    $password = trim($_POST['fpwd']);
    
    // Get user record including user type
    $query = "SELECT u.*, t.t_desc FROM tb_user u 
              JOIN tb_utype t ON u.u_utype = t.t_id 
              WHERE u.u_sno = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        
        if(password_verify($password, $row['u_pwd'])) {
            $_SESSION['logged_in'] = true;
            $_SESSION['funame'] = $username;
            $_SESSION['u_sno'] = $row['u_sno'];
            
            // Check user type from database
            switch($row['u_utype']) {
                case 3: // IT Staff
                    $_SESSION['usertype'] = 'itstaff';
                    $_SESSION['success_msg'] = "Login successfully!";
                    header("Location: staff.php");
                    break;
                case 2: // Student
                    $_SESSION['usertype'] = 'student';
                    $_SESSION['success_msg'] = "Login successfully!";
                    header("Location: student.php");
                    exit();
                case 1: // Lecturer
                    $_SESSION['usertype'] = 'advisor';
                    $_SESSION['success_msg'] = "Login successfully!";
                    header("Location: advisor.php");
                    exit();
            }
            exit();
        }
    }
    
    header("Location: login.php?error=invalid_credentials");
    exit();
} else {
    header("Location: login.php?error=missing_fields");
    exit();
}

mysqli_close($con);
?>