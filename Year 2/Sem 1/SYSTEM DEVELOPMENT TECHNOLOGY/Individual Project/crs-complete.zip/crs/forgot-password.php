<?php
// Add at the very top of the file
date_default_timezone_set('Asia/Kuala_Lumpur');  // Set Malaysia timezone

session_start();
include 'headermain.php';

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Process form submission
if(isset($_POST['send-reset'])) {
    try {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Include database connection
        include('dbconnect.php');

        // Check if email exists using prepared statement
        $query = "SELECT u_sno, u_name FROM tb_user WHERE u_email = ?";
        $stmt = mysqli_prepare($con, $query);
        
        if ($stmt === false) {
            throw new Exception("Database error");
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            
            // Generate secure reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store reset token in database
            $update_query = "UPDATE tb_user SET reset_token = ?, reset_expiry = ? WHERE u_email = ?";
            $stmt = mysqli_prepare($con, $update_query);
            mysqli_stmt_bind_param($stmt, "sss", $token, $expiry, $email);
            mysqli_stmt_execute($stmt);
            
            // Send reset email using PHPMailer
            require_once 'includes/email_helper.php';
            
            $resetLink = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $token;
            
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'lauyeewen@graduate.utm.my'; // Your Gmail address
            $mail->Password = 'penq njiw pogk kezt'; // Your new App Password
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Remove or set debug to 0 to hide the logs
            $mail->SMTPDebug = 0;  // Changed from 2 to 0 to hide debug output

            $mail->setFrom('your-email@gmail.com', 'Course Registration System');
            $mail->addAddress($email);
            
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset Request';
            $mail->Body = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                <h2 style='color: #1a73e8; text-align: center;'>Password Reset Request</h2>
                <div style='background-color: #f8f9fa; padding: 20px; border-radius: 5px;'>
                    <p>You have requested to reset your password. Click the button below to reset it:</p>
                    <div style='text-align: center; margin: 30px 0;'>
                        <a href='$resetLink' style='background-color: #1a73e8; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Reset Password</a>
                    </div>
                    <p>This link will expire in 24 hours.</p>
                    <p>If you didn't request this, please ignore this email.</p>
                </div>
            </div>";

            $mail->send();
            
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                  <script>
                  Swal.fire({
                      icon: 'success',
                      title: 'Email Sent!',
                      text: 'Password reset instructions have been sent to your email.',
                      confirmButtonColor: '#3085d6'
                  }).then((result) => {
                      if (result.isConfirmed) {
                          window.location.href = 'login.php';
                      }
                  });
                  </script>";
        } else {
            throw new Exception("No account found with that email address.");
        }
        
    } catch (Exception $e) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
              <script>
              Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: '" . addslashes($e->getMessage()) . "',
                  confirmButtonColor: '#3085d6'
              });
              </script>";
    }
}
?>

<div class="container py-5">
    <div class="col-md-6 mx-auto">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h3 class="card-title text-center mb-4">Reset Password</h3>
                
                <form method="POST" class="needs-validation" novalidate>
                    <div class="mb-4">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" id="email" required
                               placeholder="Enter your registered email">
                        <div class="invalid-feedback">Please enter a valid email address.</div>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" name="send-reset" class="btn btn-primary">
                            Send Reset Link
                        </button>
                    </div>

                    <div class="text-center mt-4">
                        <a href="login.php">Back to Login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 