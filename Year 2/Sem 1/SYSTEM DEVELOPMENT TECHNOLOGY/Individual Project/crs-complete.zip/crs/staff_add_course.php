<?php
ob_start();
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get lecturers from database
$sql_lecturers = "SELECT u_sno, u_name, u_email FROM tb_user WHERE u_utype = 1 ORDER BY u_name";
$result_lecturers = mysqli_query($con, $sql_lecturers);

if (!$result_lecturers) {
    die("Error in query: " . mysqli_error($con));
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $c_code = mysqli_real_escape_string($con, $_POST['c_code']);
    $c_name = mysqli_real_escape_string($con, $_POST['c_name']);
    $c_credit = mysqli_real_escape_string($con, $_POST['c_credit']);
    $c_max = mysqli_real_escape_string($con, $_POST['c_max']);
    $c_lec = mysqli_real_escape_string($con, $_POST['c_lec']);
    $c_synopsis = mysqli_real_escape_string($con, $_POST['c_synopsis']);

    // Validate inputs
    $errors = array();
    
    if (empty($c_code)) $errors[] = "Course code is required";
    if (empty($c_name)) $errors[] = "Course name is required";
    if (empty($c_credit)) $errors[] = "Credit hours are required";
    if (empty($c_max)) $errors[] = "Maximum students is required";
    if (empty($c_lec)) $errors[] = "Lecturer is required";
    if (empty($c_synopsis)) $errors[] = "Synopsis is required";

    // Check if course code already exists
    $check_sql = "SELECT c_code FROM tb_course WHERE c_code = '$c_code'";
    $check_result = mysqli_query($con, $check_sql);
    if (mysqli_num_rows($check_result) > 0) {
        $errors[] = "Course code already exists";
    }

    if (empty($errors)) {
        // Start transaction
        mysqli_begin_transaction($con);
        
        try {
            // First insert into tb_course
            $sql = "INSERT INTO tb_course (c_code, c_name, c_credit, c_max, c_lec, c_synopsis) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($con, $sql);
            mysqli_stmt_bind_param($stmt, "ssiiss", $c_code, $c_name, $c_credit, $c_max, $c_lec, $c_synopsis);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Error inserting into tb_course: " . mysqli_error($con));
            }
            
            // Get current active semester
            $sem_sql = "SELECT s_code FROM tb_semester WHERE s_status = 'active' LIMIT 1";
            $sem_result = mysqli_query($con, $sem_sql);
            if (!$sem_result || mysqli_num_rows($sem_result) == 0) {
                throw new Exception("No active semester found");
            }
            $semester = mysqli_fetch_assoc($sem_result)['s_code'];
            
            // Insert into course_assignment for the selected lecturer
            $assign_sql = "INSERT INTO tb_course_assignment (ca_course, ca_lecturer, ca_semester, ca_status) 
                          VALUES (?, ?, ?, 'active')";
            
            $stmt = mysqli_prepare($con, $assign_sql);
            mysqli_stmt_bind_param($stmt, "sss", $c_code, $c_lec, $semester);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Error inserting into tb_course_assignment: " . mysqli_error($con));
            }
            
            // If everything is successful, commit the transaction
            mysqli_commit($con);
            
            $_SESSION['success'] = "Course added successfully";
            header("Location: staff.php");
            exit();
            
        } catch (Exception $e) {
            // If there's an error, rollback the transaction
            mysqli_rollback($con);
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff_course_management.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Course Management
                </a>
                <h4 class="mb-0">Add New Course</h4>
            </div>
        </div>
        
        <div class="card-body">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" id="addCourseForm" onsubmit="return confirmSubmission()">
                <div class="mb-3">
                    <label for="courseCode" class="form-label">Course Code</label>
                    <input type="text" class="form-control" id="courseCode" name="c_code" required>
                </div>

                <div class="mb-3">
                    <label for="courseName" class="form-label">Course Name</label>
                    <input type="text" class="form-control" id="courseName" name="c_name" required>
                </div>

                <div class="mb-3">
                    <label for="creditHours" class="form-label">Credit Hours</label>
                    <input type="number" class="form-control" id="creditHours" name="c_credit" min="1" max="4" required>
                </div>

                <div class="mb-3">
                    <label for="maxStudents" class="form-label">Maximum Students</label>
                    <input type="number" class="form-control" id="maxStudents" name="c_max" min="1" value="30" required>
                </div>

                <div class="mb-3">
                    <label for="synopsis" class="form-label">Course Synopsis</label>
                    <textarea class="form-control" id="synopsis" name="c_synopsis" rows="4" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="c_lec" class="form-label">Course Lecturer</label>
                    <select name="c_lec" id="c_lec" class="form-control" required>
                        <option value="">Select a lecturer</option>
                        <?php
                        // Get all lecturers from the database
                        $lecturer_query = "SELECT u_sno, u_name FROM tb_user WHERE u_utype = 1 ORDER BY u_name";
                        $lecturer_result = mysqli_query($con, $lecturer_query);
                        
                        while ($lecturer = mysqli_fetch_assoc($lecturer_result)) {
                            echo "<option value='" . htmlspecialchars($lecturer['u_sno']) . "'>" . 
                                 htmlspecialchars($lecturer['u_name']) . " (" . htmlspecialchars($lecturer['u_sno']) . ")</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus-circle me-2"></i>Add Course
                    </button>
                    <a href="staff_course_management.php" class="btn btn-secondary">
                        <i class="fas fa-times-circle me-2"></i>Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmSubmission() {
    // Get the course details
    const courseCode = document.getElementById('courseCode').value;
    const courseName = document.getElementById('courseName').value;
    const lecturer = document.getElementById('c_lec');
    const lecturerName = lecturer.options[lecturer.selectedIndex].text;
    
    // Create confirmation message
    const message = `Are you sure you want to add this course?\n\n` +
                   `Course Code: ${courseCode}\n` +
                   `Course Name: ${courseName}\n` +
                   `Lecturer: ${lecturerName}`;
    
    return confirm(message);
}
</script>

<style>
.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.form-control:focus, .form-select:focus {
    border-color: #86b7fe;
    box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
}
</style>

<?php 
include 'footer.php';
ob_end_flush();
?> 