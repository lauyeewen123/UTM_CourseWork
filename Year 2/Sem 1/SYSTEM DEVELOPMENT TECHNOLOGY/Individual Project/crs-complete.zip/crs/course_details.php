<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

$lecturer_id = $_SESSION['funame'];
$course_code = isset($_GET['code']) ? mysqli_real_escape_string($con, $_GET['code']) : '';

// Verify course exists and belongs to lecturer using course_assignment
$course_sql = "SELECT c.*, ca.ca_semester 
               FROM tb_course c 
               INNER JOIN tb_course_assignment ca ON c.c_code = ca.ca_course
               WHERE c.c_code = ? 
               AND ca.ca_lecturer = ?
               AND ca.ca_status = 'active'";

if ($stmt = mysqli_prepare($con, $course_sql)) {
    mysqli_stmt_bind_param($stmt, "ss", $course_code, $lecturer_id);
    mysqli_stmt_execute($stmt);
    $course_result = mysqli_stmt_get_result($stmt);

    // Debug
    error_log("Course check - Lecturer: $lecturer_id, Course: $course_code");
    error_log("Rows found: " . mysqli_num_rows($course_result));
} else {
    die("Query failed: " . mysqli_error($con));
}

if (!$course_result || mysqli_num_rows($course_result) == 0) {
    echo '<div class="container mt-4">
            <div class="alert alert-danger">Course not found or access denied.</div>
          </div>';
    include 'footer.php';
    exit();
}

$course = mysqli_fetch_assoc($course_result);

// Get registered students for current semester
$students_sql = "SELECT r.*, u.u_name, u.u_email, u.u_contact 
                FROM tb_registration r
                JOIN tb_user u ON r.r_student = u.u_sno
                WHERE r.r_course = ?
                AND r.r_sem = ?
                ORDER BY r.r_section, u.u_name";

if ($stmt = mysqli_prepare($con, $students_sql)) {
    mysqli_stmt_bind_param($stmt, "ss", $course_code, $course['ca_semester']);
    mysqli_stmt_execute($stmt);
    $students_result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_student_list.php">Course Overview</a></li>
            <li class="breadcrumb-item active"><?php echo htmlspecialchars($course['c_code']); ?></li>
        </ol>
    </nav>

    <!-- Course Information -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Course Information</h5>
        </div>
        <div class="card-body">
            <h4><?php echo htmlspecialchars($course['c_code']); ?> - <?php echo htmlspecialchars($course['c_name']); ?></h4>
            <p>
                <strong>Credits:</strong> <?php echo htmlspecialchars($course['c_credit']); ?><br>
                <strong>Semester:</strong> <?php echo htmlspecialchars($course['ca_semester']); ?><br>
                <strong>Total Students:</strong> <?php echo mysqli_num_rows($students_result); ?>
            </p>
        </div>
    </div>

    <!-- Registered Students -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Registered Students</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Section</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($students_result) > 0) {
                            while($student = mysqli_fetch_assoc($students_result)) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($student['r_student']) . "</td>";
                                echo "<td>" . htmlspecialchars($student['u_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($student['r_section']) . "</td>";
                                echo "<td>";
                                switch($student['r_status']) {
                                    case '1':
                                        echo '<span class="badge bg-warning">Pending</span>';
                                        break;
                                    case '2':
                                        echo '<span class="badge bg-success">Approved</span>';
                                        break;
                                    case '3':
                                        echo '<span class="badge bg-danger">Rejected</span>';
                                        break;
                                }
                                echo "</td>";
                                echo "<td>
                                        <a href='view_student_details.php?id=" . htmlspecialchars($student['r_student']) . "' 
                                           class='btn btn-info btn-sm'>
                                            <i class='fas fa-user'></i> View Details
                                        </a>
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No students registered yet.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.badge {
    padding: 0.5em 0.8em;
}

.table td {
    vertical-align: middle;
}
</style>

<?php include 'footer.php'; ?> 