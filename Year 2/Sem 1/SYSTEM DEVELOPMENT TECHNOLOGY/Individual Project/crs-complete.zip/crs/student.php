<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'session_config.php';
checkStudentLogin();

// First include the header
include 'headerstudent.php';

// Then show the success message
if(isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" style="margin: 20px;">
        <strong>Login successfully!</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success_msg']); // Clear the message ?>
<?php endif; ?>

<?php
include 'dbconnect.php';

// Get user details - Modified query with proper error handling
$uic = $_SESSION['funame'];
$sql = "SELECT u.*, t.t_desc as user_type 
        FROM tb_user u 
        INNER JOIN tb_utype t ON u.u_utype = t.t_id 
        WHERE u.u_sno = ?";

// Use prepared statement to prevent SQL injection
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $uic);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}

$user = mysqli_fetch_assoc($result); // Changed from mysqli_fetch_array to mysqli_fetch_assoc

// Check if user exists
if (!$user) {
    die("User not found");
}

// Get profile picture path with null coalescing operator
$profile_pic = $user['u_profile_pic'] ?? 'img/profilepic.jpg';

// Get current semester registrations
$sql_current = "SELECT COUNT(*) as current_courses 
                FROM tb_registration r 
                WHERE r_student = '$uic' 
                AND r_sem = '2024/2025-1'
                AND r_status != 3";
$result_current = mysqli_query($con, $sql_current);
$current_courses = mysqli_fetch_array($result_current)['current_courses'];
?>

<style>
:root {
    --primary-blue: #4285f4;      /* Softer Google Blue */
    --secondary-blue: #5c9fff;    /* Light Blue */
    --hover-blue: #1a73e8;        /* Accent Blue */
    --light-blue: #f3f8ff;        /* Very Light Blue Background */
    --white: #ffffff;
    --text-dark: #2C3E50;
    --text-light: #6C757D;
}

/* Profile Card Styles */
.profile-section {
    background: linear-gradient(135deg, var(--secondary-blue) 0%, var(--primary-blue) 100%);
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 4px 15px rgba(66, 133, 244, 0.15);
}

.profile-image-wrapper {
    width: 160px;
    height: 160px;
    margin: 0 auto 1.5rem;
    position: relative;
    background: white;
    border-radius: 50%;
    padding: 5px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.profile-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
}

.profile-name {
    color: white;
    font-size: 1.8rem;
    font-weight: 600;
    text-align: center;
    margin-bottom: 0.3rem;
}

.profile-role {
    color: rgba(255,255,255,0.9);
    text-align: center;
    font-size: 1.1rem;
    margin-bottom: 2rem;
}

/* Info Container */
.info-container {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
}

.info-item {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 10px;
    padding: 0.8rem;
    margin-bottom: 0.8rem;
    color: white;
    transition: all 0.3s ease;
}

.info-item:hover {
    background: rgba(255,255,255,0.2);
}

/* Edit Profile Button */
.edit-profile-btn {
    display: inline-block;
    width: 100%;
    padding: 0.8rem;
    background: rgba(255,255,255,0.2);
    color: white;
    text-decoration: none;
    border-radius: 10px;
    text-align: center;
    transition: all 0.3s ease;
    border: 1px solid rgba(255,255,255,0.3);
}

.edit-profile-btn:hover {
    background: rgba(255,255,255,0.3);
    color: white;
    text-decoration: none;
}

/* Quick Actions */
.section-title {
    color: var(--text-dark);
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--secondary-blue);
}

.quick-action-card {
    background: var(--white);
    border-radius: 15px;
    padding: 2rem;
    text-align: center;
    transition: all 0.3s ease;
    text-decoration: none;
    color: var(--text-dark);
    border: 1px solid rgba(66, 133, 244, 0.1);
    box-shadow: 0 2px 10px rgba(66, 133, 244, 0.05);
}

.quick-action-card:hover {
    transform: translateY(-5px);
    border-color: var(--primary-blue);
    box-shadow: 0 5px 15px rgba(66, 133, 244, 0.1);
}

.quick-action-icon {
    font-size: 2.5rem;
    color: var(--primary-blue);
    margin-bottom: 1rem;
}

.quick-action-card h5 {
    color: var(--text-dark);
    margin-bottom: 0.5rem;
}

.quick-action-card p {
    color: var(--text-light);
    margin-bottom: 0;
}

/* Semester Summary */
.stats-card {
    background: var(--light-blue);
    border-radius: 15px;
    padding: 2rem;
    text-align: center;
    box-shadow: 0 2px 10px rgba(66, 133, 244, 0.05);
    border: 1px solid rgba(66, 133, 244, 0.1);
}

.stats-number {
    font-size: 2.5rem;
    font-weight: 600;
    color: var(--primary-blue);
    margin-bottom: 0.5rem;
}

.stats-label {
    color: var(--text-light);
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 1px;
}
</style>

<div class="container py-5">
    <div class="row">
        <!-- Profile Information Card -->
        <div class="col-lg-4 mb-4">
            <div class="profile-section">
                <div class="profile-header">
                    <div class="profile-image-wrapper">
                        <img src="<?php echo $profile_pic; ?>" class="profile-image" alt="Profile Picture">
                    </div>
                    <h2 class="profile-name"><?php echo $user['u_name']; ?></h2>
                    <p class="profile-role"><?php echo $user['user_type']; ?></p>
                </div>
                
                <div class="profile-info">
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-id-card"></i>
                        </div>
                        <span class="info-text"><?php echo $user['u_sno']; ?></span>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <span class="info-text"><?php echo $user['u_email']; ?></span>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <span class="info-text"><?php echo $user['u_contact']; ?></span>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <span class="info-text"><?php echo $user['u_state']; ?></span>
                    </div>
                </div>
                
                <a href="editprofile.php" class="edit-profile-btn">
                    <i class="fas fa-user-edit me-2"></i>Edit Profile
                </a>
            </div>
        </div>

        <div class="col-lg-8">
            <!-- Quick Actions -->
            <h4 class="section-title">Quick Actions</h4>
            <div class="row mb-5">
                <div class="col-md-6 mb-4">
                    <a href="courseregister.php" class="card quick-action-card">
                        <i class="fas fa-plus-circle quick-action-icon"></i>
                        <h5>Register New Course</h5>
                        <p class="text-muted mb-0">Add new courses to your semester</p>
                    </a>
                </div>
                <div class="col-md-6 mb-4">
                    <a href="courseview.php" class="card quick-action-card">
                        <i class="fas fa-list quick-action-icon"></i>
                        <h5>View My Courses</h5>
                        <p class="text-muted mb-0">Check your enrolled courses</p>
                    </a>
                </div>
                <div class="col-md-6 mb-4">
                    <a href="modifyregistration.php" class="card quick-action-card">
                        <i class="fas fa-edit quick-action-icon"></i>
                        <h5>Modify Registration</h5>
                        <p class="text-muted mb-0">Update your course selections</p>
                    </a>
                </div>
                <div class="col-md-6 mb-4">
                    <a href="editprofile.php" class="card quick-action-card">
                        <i class="fas fa-user-edit quick-action-icon"></i>
                        <h5>Update Profile</h5>
                        <p class="text-muted mb-0">Edit your personal information</p>
                    </a>
                </div>
            </div>

            <!-- Current Semester Summary -->
            <h4 class="section-title">Current Semester Summary</h4>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="stats-card">
                        <div class="stats-number"><?php echo $current_courses; ?></div>
                        <div class="stats-label">Registered Courses</div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="stats-card">
                        <div class="stats-number">2024/2025-1</div>
                        <div class="stats-label">Current Semester</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br>
<?php include 'footer.php';?>



