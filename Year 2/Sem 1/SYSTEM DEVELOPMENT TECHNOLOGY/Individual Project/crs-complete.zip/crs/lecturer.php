<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}

include 'headerlec.php';
include 'dbconnect.php';
include 'includes/semester_helper.php';

// Get current semester
$current_semester = getCurrentSemester($con);

// Get lecturer's courses count
$lecturer_id = $_SESSION['u_sno'];
$courses_sql = "SELECT COUNT(*) as course_count FROM tb_course WHERE c_lec = '$lecturer_id'";
$courses_result = mysqli_query($con, $courses_sql);
$courses_count = mysqli_fetch_assoc($courses_result)['course_count'];

// Get total students count
$students_sql = "SELECT COUNT(DISTINCT r.r_student) as student_count 
                FROM tb_registration r 
                JOIN tb_course c ON r.r_course = c.c_code 
                WHERE c.c_lec = '$lecturer_id' AND r.r_status = '2'";
$students_result = mysqli_query($con, $students_sql);
$students_count = mysqli_fetch_assoc($students_result)['student_count'];

// Get pending approvals count
$pending_sql = "SELECT COUNT(*) as pending_count 
               FROM tb_registration r 
               JOIN tb_course c ON r.r_course = c.c_code 
               WHERE c.c_lec = '$lecturer_id' AND r.r_status = '1'";
$pending_result = mysqli_query($con, $pending_sql);
$pending_count = mysqli_fetch_assoc($pending_result)['pending_count'];

// Get lecturer's courses
$my_courses_sql = "SELECT c.*, 
                   (SELECT COUNT(*) FROM tb_registration r 
                    WHERE r.r_course = c.c_code AND r.r_status = '2') as enrolled_students
                   FROM tb_course c 
                   WHERE c.c_lec = '$lecturer_id'
                   ORDER BY c.c_code";
$my_courses_result = mysqli_query($con, $my_courses_sql);
?>

<div class="container py-4">
    <!-- Semester Information -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Lecturer Dashboard</h2>
        <div class="current-semester">
            <span class="badge bg-primary">
                <i class="fas fa-calendar-alt me-2"></i>
                Current Semester: <?php echo formatSemesterName($current_semester); ?>
            </span>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <h3 class="card-title">
                        <i class="fas fa-book me-2"></i>
                        Assigned Courses
                    </h3>
                    <h2 class="display-4 mb-0"><?php echo $courses_count; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <h3 class="card-title">
                        <i class="fas fa-users me-2"></i>
                        Total Students
                    </h3>
                    <h2 class="display-4 mb-0"><?php echo $students_count; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-warning text-white h-100">
                <div class="card-body">
                    <h3 class="card-title">
                        <i class="fas fa-clock me-2"></i>
                        Pending Approvals
                    </h3>
                    <h2 class="display-4 mb-0"><?php echo $pending_count; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- My Courses Table -->
    <div class="card">
        <div class="card-header">
            <h4 class="mb-0"><i class="fas fa-book me-2"></i>My Courses</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credit Hours</th>
                            <th>Students</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($course = mysqli_fetch_assoc($my_courses_result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($course['c_code']); ?></td>
                                <td><?php echo htmlspecialchars($course['c_name']); ?></td>
                                <td><?php echo $course['c_credit']; ?></td>
                                <td>
                                    <?php echo $course['enrolled_students']; ?>/<?php echo $course['c_max']; ?>
                                    <?php if ($course['enrolled_students'] >= $course['c_max']): ?>
                                        <span class="badge bg-danger">Full</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="lecturer_course_details.php?code=<?php echo $course['c_code']; ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-info-circle"></i> Details
                                    </a>
                                    <a href="lecturer_course_students.php?code=<?php echo $course['c_code']; ?>" 
                                       class="btn btn-success btn-sm">
                                        <i class="fas fa-users"></i> Students
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php';?>



