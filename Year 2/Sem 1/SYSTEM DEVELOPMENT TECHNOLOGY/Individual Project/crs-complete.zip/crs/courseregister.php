<?php 
include('crssession.php');
if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];

// Calculate total credits
$sql_credits = "SELECT 
    SUM(c.c_credit) as total_credits,
    SUM(CASE WHEN r.r_status = 2 THEN c.c_credit ELSE 0 END) as approved_credits
    FROM tb_registration r
    JOIN tb_course c ON r.r_course = c.c_code
    WHERE r.r_student = '$uic' AND r.r_sem = '2024/2025-1'";
$result_credits = mysqli_query($con, $sql_credits);
$credits = mysqli_fetch_assoc($result_credits);
?>

<div class="container">
  <br><br>
    <h4>Course Registration</h4>
    
    <div class="alert alert-info">
        Total Credits: <?php echo $credits['total_credits'] ?? 0; ?> 
        (Approved: <?php echo $credits['approved_credits'] ?? 0; ?>)
    </div>

    <!-- Search bar with button -->
    <div class="d-flex mb-3">
        <input type="text" id="courseSearch" class="form-control" placeholder="Enter course code or name..." style="margin-right: 10px;">
        <button class="btn btn-primary" onclick="filterCourses()">Search</button>
    </div>

    <form method="POST" action="courseregisterprocess.php" onsubmit="return confirmRegistration();">
        <div class="mb-3">
            <label>Select Course</label>
            <select name="fcourse" id="courseSelect" class="form-select" required>
                <option value="">Select a course</option>
                <?php
                $sql = "SELECT c.* 
                        FROM tb_course c 
                        WHERE NOT EXISTS (
                            SELECT 1 
                            FROM tb_registration r 
                            WHERE r.r_course = c.c_code 
                            AND r.r_student = '$uic'
                            AND r.r_sem = '2024/2025-1'
                        )
                        ORDER BY c.c_code";
                
                $result = mysqli_query($con, $sql);
                
                if (!$result) {
                    echo "Query failed: " . mysqli_error($con);
                } else {
                    while($row = mysqli_fetch_array($result)) {
                        echo "<option value='" . $row['c_code'] . "'>" 
                             . $row['c_code'] . " - " 
                             . $row['c_name'] . " (" 
                             . $row['c_credit'] . " credits)</option>";
                    }
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Select Section</label>
            <select name="fsection" class="form-select" required>
                <option value="">Select section</option>
                <?php
                for($i = 1; $i < 3; $i++) {
                    echo "<option value='{$i}'>Section {$i}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Select Semester</label>
            <select name="fsem" class="form-select" required>
                <option value="2024/2025-1">2024/2025-1</option>
                <option value="2024/2025-2">2024/2025-2</option>
            </select>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Register Course</button>
            <button type="reset" class="btn btn-secondary">Clear Form</button>
        </div>
    </form>

    <!-- Add notice below the form -->
    <div class="alert alert-info mt-3" style="font-size: 0.9rem;">
        <i class="fas fa-info-circle"></i> Note: Course registration will be automatically approved if the selected section has available capacity.
    </div>
</div>

<style>
.form-select {
    padding: 0.375rem 2.25rem 0.375rem 0.75rem;
    font-size: 1rem;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    width: 100%;
}

.form-control {
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
}

#courseSearch {
    margin-bottom: 10px;
    min-width: 300px; /* Ensure search box is wide enough */
}

.btn {
    margin-right: 10px;
}

#searchMessage {
    font-size: 0.9rem;
    margin-top: 5px;
}

.form-select option {
    padding: 8px 12px;
}
</style>

<script>
function filterCourses() {
    var input = document.getElementById('courseSearch');
    var filter = input.value.toLowerCase();
    var select = document.getElementById('courseSelect');
    var options = select.getElementsByTagName('option');
    var found = false;
    
    // Reset select to first option
    select.selectedIndex = 0;
    
    // If search is empty, show all options
    if (filter === '') {
        for (var i = 0; i < options.length; i++) {
            options[i].style.display = "";
        }
        return;
    }

    for (var i = 0; i < options.length; i++) {
        var option = options[i];
        var text = option.text.toLowerCase();
        
        if (text.indexOf(filter) > -1) {
            option.style.display = "";
            found = true;
            // If this is the first match, select it
            if (!select.value) {
                option.selected = true;
            }
        } else {
            option.style.display = "none";
        }
    }
    
    // Show message if no courses found
    var message = document.getElementById('searchMessage');
    if (!message) {
        message = document.createElement('div');
        message.id = 'searchMessage';
        message.className = 'alert alert-info mt-2';
        select.parentNode.appendChild(message);
    }
    
    if (!found) {
        message.style.display = '';
        message.textContent = 'No courses found matching "' + input.value + '"';
        select.value = ''; // Reset selection if no matches
    } else {
        message.style.display = 'none';
    }
}

// Auto-search as user types (with delay)
var searchTimeout;
document.getElementById('courseSearch').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(filterCourses, 300); // 300ms delay
});

// Search on Enter key
document.getElementById('courseSearch').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        filterCourses();
    }
});

// Add confirmation function
function confirmRegistration() {
    const courseSelect = document.querySelector('select[name="fcourse"]');
    const sectionSelect = document.querySelector('select[name="fsection"]');
    const semesterSelect = document.querySelector('select[name="fsem"]');
    
    // Get the selected course details
    const selectedCourse = courseSelect.options[courseSelect.selectedIndex].text;
    const selectedSection = sectionSelect.value;
    const selectedSemester = semesterSelect.value;
    
    // Create confirmation message
    const message = `Are you sure you want to register for:\n\n` +
                   `Course: ${selectedCourse}\n` +
                   `Section: ${selectedSection}\n` +
                   `Semester: ${selectedSemester}\n\n` +
                   `This action cannot be undone.`;
    
    return confirm(message);
}

// Update clear form button to also clear search
document.querySelector('button[type="reset"]').addEventListener('click', function() {
    if(confirm('Are you sure you want to clear the form?')) {
        document.getElementById('courseSearch').value = '';
        filterCourses();
    } else {
        event.preventDefault(); // Prevent form reset if user cancels
    }
});
</script>

<?php include 'footer.php'; ?>



