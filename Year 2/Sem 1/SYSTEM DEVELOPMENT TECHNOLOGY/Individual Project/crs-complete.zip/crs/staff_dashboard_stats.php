<?php
function getDashboardStats($con) {
    $stats = array(
        'courses' => 0,
        'students' => 0,
        'lecturers' => 0,
        'pending' => 0
    );
    
    // Total Courses
    $query = "SELECT COUNT(*) as count FROM tb_course";
    $result = mysqli_query($con, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $stats['courses'] = $row['count'];
    }
    
    // Total Students (u_utype = 2)
    $query = "SELECT COUNT(*) as count FROM tb_user WHERE u_utype = '2'";
    $result = mysqli_query($con, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $stats['students'] = $row['count'];
    }
    
    // Total Lecturers (u_utype = 1)
    $query = "SELECT COUNT(*) as count FROM tb_user WHERE u_utype = '1'";
    $result = mysqli_query($con, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $stats['lecturers'] = $row['count'];
    }
    
    // Pending Registrations (r_status = 1)
    $query = "SELECT COUNT(*) as count FROM tb_registration WHERE r_status = '1'";
    $result = mysqli_query($con, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $stats['pending'] = $row['count'];
    }
    
    return $stats;
}
?> 