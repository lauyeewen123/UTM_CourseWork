<?php
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get all lecturers with their course count
$sql = "SELECT u.*, 
        (SELECT COUNT(*) FROM tb_course c WHERE c.c_lec = u.u_sno) as course_count
        FROM tb_user u 
        WHERE u.u_utype = '1' 
        ORDER BY u.u_name";
$result = mysqli_query($con, $sql);
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <h4 class="mb-0">Lecturer List</h4>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="lecturersTable">
                    <thead>
                        <tr>
                            <th>Lecturer ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>State</th>
                            <th>Courses Teaching</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['u_sno']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_email']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_contact']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_state']); ?></td>
                                <td><?php echo $row['course_count']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#lecturersTable').DataTable({
        "pageLength": 25
    });
});
</script>

<?php include 'footer.php'; ?> 