<?php 
require_once 'session_config.php';
checkITStaffLogin();
include('dbconnect.php');

$staff_id = $_SESSION['u_sno'];

// Handle form submission BEFORE including header
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $contact = mysqli_real_escape_string($con, $_POST['contact']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $dob = mysqli_real_escape_string($con, $_POST['dob']);
    $state = mysqli_real_escape_string($con, $_POST['state']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $current_password = $_POST['current_password'];
    
    // Verify current password
    $verify_sql = "SELECT u_pwd FROM tb_user WHERE u_sno = ?";
    if ($stmt = mysqli_prepare($con, $verify_sql)) {
        mysqli_stmt_bind_param($stmt, "s", $staff_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);

        if ($user && password_verify($current_password, $user['u_pwd'])) {
            // Update profile information
            $update_sql = "UPDATE tb_user SET 
                          u_name = ?, 
                          u_email = ?, 
                          u_contact = ?,
                          u_gender = ?, 
                          u_dob = ?,
                          u_state = ?,
                          u_address = ?
                          WHERE u_sno = ?";
            
            if ($stmt = mysqli_prepare($con, $update_sql)) {
                mysqli_stmt_bind_param($stmt, "ssssssss", 
                    $name, 
                    $email, 
                    $contact,
                    $gender,
                    $dob,
                    $state,
                    $address,
                    $staff_id
                );
                
                if (mysqli_stmt_execute($stmt)) {
                    // Handle password change if new password is provided
                    if (!empty($_POST['new_password'])) {
                        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                        $pwd_sql = "UPDATE tb_user SET u_pwd = ? WHERE u_sno = ?";
                        if ($pwd_stmt = mysqli_prepare($con, $pwd_sql)) {
                            mysqli_stmt_bind_param($pwd_stmt, "ss", $new_password, $staff_id);
                            mysqli_stmt_execute($pwd_stmt);
                        }
                    }
                    $_SESSION['success'] = "Profile updated successfully!";
                    header("Location: staff_profile.php");
                    exit();
                }
            }
        } else {
            $_SESSION['error'] = "Current password is incorrect.";
            header("Location: edit_staff_profile.php");
            exit();
        }
    }
}

// Fetch staff details BEFORE including header
$sql = "SELECT * FROM tb_user WHERE u_sno = ?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $staff_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$staff = mysqli_fetch_assoc($result);

// Include header AFTER all potential redirects
include('headerit.php');
?>

<div class="container py-4">
    <!-- Modern Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb bg-white shadow-sm p-3 rounded-3 border">
            <li class="breadcrumb-item">
                <a href="staff.php" class="text-decoration-none">
                    <i class="fas fa-home text-primary"></i> Dashboard
                </a>
            </li>
            <li class="breadcrumb-item">
                <a href="staff_profile.php" class="text-decoration-none">
                    <i class="fas fa-user-circle text-primary"></i> My Profile
                </a>
            </li>
            <li class="breadcrumb-item active">
                <i class="fas fa-edit text-primary"></i> Edit Profile
            </li>
        </ol>
    </nav>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['error']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Edit Profile</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="" id="editProfileForm" onsubmit="return confirmUpdate(event)">
                <!-- Basic Information Section -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-user me-2"></i>Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Staff ID</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($staff['u_sno']); ?>" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($staff['u_name']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($staff['u_email']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="text" class="form-control" name="contact" value="<?php echo htmlspecialchars($staff['u_contact']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo ($staff['u_gender'] === 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($staff['u_gender'] === 'Female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="dob" value="<?php echo htmlspecialchars($staff['u_dob']); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">State</label>
                                <input type="text" class="form-control" name="state" value="<?php echo htmlspecialchars($staff['u_state']); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($staff['u_address']); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Password Change Section -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-lock me-2"></i>Change Password</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <div class="password-requirements">
                                    <h6><i class="fas fa-info-circle me-2"></i>Password Requirements:</h6>
                                    <ul class="requirements-list">
                                        <li id="length">
                                            <i class="fas fa-times"></i>
                                            At least 8 characters long
                                        </li>
                                        <li id="uppercase">
                                            <i class="fas fa-times"></i>
                                            Contains at least one uppercase letter
                                        </li>
                                        <li id="lowercase">
                                            <i class="fas fa-times"></i>
                                            Contains at least one lowercase letter
                                        </li>
                                        <li id="number">
                                            <i class="fas fa-times"></i>
                                            Contains at least one number
                                        </li>
                                        <li id="special">
                                            <i class="fas fa-times"></i>
                                            Contains at least one special character
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Current Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="current_password" required>
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(this)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">New Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="new_password" id="newPassword">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(this)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="confirm_password" id="confirmPassword">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(this)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                    <a href="staff_profile.php" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.password-requirements {
    background-color: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1rem;
}

.requirements-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.requirements-list li {
    margin-bottom: 0.5rem;
    color: #6c757d;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: color 0.3s ease;
}

.requirements-list li i {
    transition: all 0.3s ease;
}

.requirements-list li.valid {
    color: #198754;
}

.requirements-list li i.fa-check {
    color: #198754;
}

.requirements-list li i.fa-times {
    color: #dc3545;
}

.breadcrumb {
    transition: all 0.3s ease;
}

.breadcrumb:hover {
    box-shadow: 0 4px 15px rgba(0,0,0,0.08) !important;
}

.breadcrumb-item a {
    color: #333;
    transition: all 0.3s ease;
}

.breadcrumb-item a:hover {
    color: #0d6efd;
    text-decoration: none;
}

.breadcrumb-item.active {
    color: #6c757d;
}

.breadcrumb-item + .breadcrumb-item::before {
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    content: "\f054";
    font-size: 0.8rem;
    color: #6c757d;
}
</style>

<script>
document.getElementById('newPassword').addEventListener('input', function() {
    validatePassword(this.value);
});

function validatePassword(password) {
    const requirements = {
        length: { regex: /.{8,}/, element: document.getElementById('length') },
        uppercase: { regex: /[A-Z]/, element: document.getElementById('uppercase') },
        lowercase: { regex: /[a-z]/, element: document.getElementById('lowercase') },
        number: { regex: /[0-9]/, element: document.getElementById('number') },
        special: { regex: /[!@#$%^&*(),.?":{}|<>]/, element: document.getElementById('special') }
    };

    // Check each requirement
    Object.keys(requirements).forEach(req => {
        const { regex, element } = requirements[req];
        if (regex.test(password)) {
            element.classList.add('valid');
            element.querySelector('i').classList.remove('fa-times');
            element.querySelector('i').classList.add('fa-check');
            element.querySelector('i').style.color = '#198754'; // Green color
        } else {
            element.classList.remove('valid');
            element.querySelector('i').classList.remove('fa-check');
            element.querySelector('i').classList.add('fa-times');
            element.querySelector('i').style.color = '#dc3545'; // Red color
        }
    });

    return Object.values(requirements).every(({ regex }) => regex.test(password));
}

function togglePassword(button) {
    const input = button.previousElementSibling;
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function confirmUpdate(event) {
    event.preventDefault();
    
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword) {
        if (!validatePassword(newPassword)) {
            Swal.fire({
                title: 'Invalid Password',
                text: 'Please make sure your password meets all requirements.',
                icon: 'error'
            });
            return false;
        }
        
        if (newPassword !== confirmPassword) {
            Swal.fire({
                title: 'Password Mismatch',
                text: 'New password and confirm password do not match.',
                icon: 'error'
            });
            return false;
        }
    }
    
    Swal.fire({
        title: 'Confirm Update',
        text: 'Are you sure you want to update your profile?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, update it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('editProfileForm').submit();
        }
    });
    
    return false;
}
</script>

<!-- Add SweetAlert2 library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php include 'footer.php'; ?> 