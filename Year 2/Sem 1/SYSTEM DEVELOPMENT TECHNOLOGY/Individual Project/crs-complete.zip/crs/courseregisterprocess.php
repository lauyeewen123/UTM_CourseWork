<?php 

include('crssession.php');
if(!session_id())
{
  session_start();
}

include('dbconnect.php');

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

try {
    // Verify user is logged in
    if (!isset($_SESSION['logged_in'])) {
        header('Location: login.php');
        exit();
    }

    if(!isset($_POST['fcourse'])) {
        // If no form submission, redirect to course registration page
        header('Location: courseregister.php');
        exit();
    }

    // Sanitize inputs
    $course = sanitize_input($_POST['fcourse']);
    $section = intval($_POST['fsection']); // Convert to integer explicitly
    $semester = sanitize_input($_POST['fsem']);
    $student_id = $_SESSION['funame'];

    // Debug information
    error_log("Course: " . $course);
    error_log("Section: " . $section);
    error_log("Semester: " . $semester);
    error_log("Student ID: " . $student_id);

    // First check if the course exists
    $check_course = "SELECT c_code FROM tb_course WHERE c_code = ?";
    $stmt = mysqli_prepare($con, $check_course);
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . mysqli_error($con));
    }
    
    if (!mysqli_stmt_bind_param($stmt, "s", $course)) {
        throw new Exception("Error binding parameters: " . mysqli_stmt_error($stmt));
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing query: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($result) == 0) {
        throw new Exception("Course not found");
    }
    mysqli_stmt_close($stmt);

    // Check if student already registered
    $check_reg = "SELECT r_tid FROM tb_registration WHERE r_student = ? AND r_course = ? AND r_sem = ?";
    $stmt = mysqli_prepare($con, $check_reg);
    if (!$stmt) {
        throw new Exception("Error preparing check statement: " . mysqli_error($con));
    }
    
    if (!mysqli_stmt_bind_param($stmt, "sss", $student_id, $course, $semester)) {
        throw new Exception("Error binding check parameters: " . mysqli_stmt_error($stmt));
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing check query: " . mysqli_stmt_error($stmt));
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($result) > 0) {
        throw new Exception("You are already registered for this course");
    }
    mysqli_stmt_close($stmt);

    // Insert the registration
    $insert_sql = "INSERT INTO tb_registration (r_student, r_course, r_section, r_sem, r_status) VALUES (?, ?, ?, ?, 1)";
    $stmt = mysqli_prepare($con, $insert_sql);
    if (!$stmt) {
        throw new Exception("Error preparing insert statement: " . mysqli_error($con));
    }
    
    if (!mysqli_stmt_bind_param($stmt, "ssis", $student_id, $course, $section, $semester)) {
        throw new Exception("Error binding insert parameters: " . mysqli_stmt_error($stmt));
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception("Error executing insert: " . mysqli_stmt_error($stmt));
    }
    mysqli_stmt_close($stmt);

    // Success message
    echo "<script>
        if(confirm('Course registration successful! Do you want to register for another course?')) {
            window.location.href='courseregister.php';
        } else {
            window.location.href='modifyregistration.php';
        }
    </script>";
    exit();

} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    echo "<script>
        alert('Registration failed: " . addslashes($e->getMessage()) . "');
        window.location.href='courseregister.php';
    </script>";
    exit();
} finally {
    if (isset($con)) {
        mysqli_close($con);
    }
}

?>