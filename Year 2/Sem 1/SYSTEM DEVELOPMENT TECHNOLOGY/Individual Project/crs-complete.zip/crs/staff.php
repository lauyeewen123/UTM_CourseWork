<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');
require_once __DIR__ . '/staff_dashboard_stats.php';

// Add error checking
if (!function_exists('getDashboardStats')) {
    die("Error: staff_dashboard_stats.php was included but getDashboardStats function not found");
}

$stats = getDashboardStats($con);

// Get recent registrations using r_tid instead of date since we don't have a date column yet
$recent_registrations_sql = "SELECT r.*, c.c_name, u.u_name, s.s_desc as status_desc
                           FROM tb_registration r
                           JOIN tb_course c ON r.r_course = c.c_code
                           JOIN tb_user u ON r.r_student = u.u_sno
                           JOIN tb_status s ON r.r_status = s.s_id
                           ORDER BY r.r_tid DESC LIMIT 5";  // Using r_tid (registration ID) for now

$recent_registrations = mysqli_query($con, $recent_registrations_sql);

// Get courses nearing capacity
$near_capacity_sql = "SELECT c.*, 
                     (SELECT COUNT(*) FROM tb_registration r 
                      WHERE r.r_course = c.c_code AND r.r_status = '2') as enrolled_students
                     FROM tb_course c
                     HAVING enrolled_students >= (c_max * 0.8)
                     ORDER BY (enrolled_students/c_max) DESC
                     LIMIT 5";
$near_capacity = mysqli_query($con, $near_capacity_sql);

// Debug connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if session is not already started before calling session_start()
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- Add this at the top of the body content -->
<?php if(isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Login successfully!</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success_msg']); // Clear the message ?>
<?php endif; ?>

<!-- Add this JavaScript for auto-dismiss -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto dismiss alert after 3 seconds
    const alertElement = document.querySelector('.alert');
    if (alertElement) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alertElement);
            bsAlert.close();
        }, 3000);
    }
});
</script>

<!-- Add this right after your header -->
<div class="container py-4">
    <?php 
    // Only show success messages that are specifically for the current page
    if (isset($_SESSION['success']) && $_SESSION['success'] != 'You have been successfully logged out'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <h2 class="mb-4">Dashboard Overview</h2>
    
    <div class="row g-4 mb-5">
        <!-- Total Courses -->
        <div class="col-lg-3 col-md-6">
            <div class="stat-card bg-primary text-white rounded-4">
                <div class="d-flex align-items-center p-4">
                    <div class="stat-icon me-3">
                        <i class="fas fa-book-open fa-2x"></i>
                    </div>
                    <div>
                        <h1 class="display-4 mb-0"><?php echo $stats['courses']; ?></h1>
                        <p class="mb-2">Total Courses</p>
                        <a href="staff_course_management.php" class="text-white text-decoration-none">
                            Manage Courses <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Students -->
        <div class="col-lg-3 col-md-6">
            <div class="stat-card bg-success text-white rounded-4">
                <div class="d-flex align-items-center p-4">
                    <div class="stat-icon me-3">
                        <i class="fas fa-user-graduate fa-2x"></i>
                    </div>
                    <div>
                        <h1 class="display-4 mb-0"><?php echo $stats['students']; ?></h1>
                        <p class="mb-2">Total Students</p>
                        <a href="staff_view_students.php" class="text-white text-decoration-none">
                            View Students <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Lecturers -->
        <div class="col-lg-3 col-md-6">
            <div class="stat-card bg-purple text-white rounded-4">
                <div class="d-flex align-items-center p-4">
                    <div class="stat-icon me-3">
                        <i class="fas fa-chalkboard-teacher fa-2x"></i>
                    </div>
                    <div>
                        <h1 class="display-4 mb-0"><?php echo $stats['lecturers']; ?></h1>
                        <p class="mb-2">Total Lecturers</p>
                        <a href="staff_view_lecturers.php" class="text-white text-decoration-none">
                            View Lecturers <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Registrations -->
        <div class="col-lg-3 col-md-6">
            <div class="stat-card bg-orange text-white rounded-4">
                <div class="d-flex align-items-center p-4">
                    <div class="stat-icon me-3">
                        <i class="fas fa-clock fa-2x"></i>
                    </div>
                    <div>
                        <h1 class="display-4 mb-0"><?php echo $stats['pending']; ?></h1>
                        <p class="mb-2">Pending Registrations</p>
                        <a href="staff_registrations.php" class="text-white text-decoration-none">
                            View Registrations <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity and Alerts Row -->
    <div class="row g-4">
        <!-- Recent Registrations -->
        <div class="col-lg-6">
            <div class="content-card">
                <div class="content-card-header">
                    <h5><i class="fas fa-history me-2"></i>Recent Course Registrations</h5>
                </div>
                <div class="content-card-body">
                    <?php if ($recent_registrations && mysqli_num_rows($recent_registrations) > 0): ?>
                        <?php while ($reg = mysqli_fetch_assoc($recent_registrations)): ?>
                            <div class="registration-item">
                                <div class="registration-content">
                                    <div class="student-info">
                                        <h6 class="student-name">
                                            <i class="fas fa-user-graduate me-2 text-primary"></i>
                                            <?php echo htmlspecialchars($reg['u_name']); ?>
                                        </h6>
                                        <p class="course-name">
                                            <i class="fas fa-book me-2 text-muted"></i>
                                            <?php echo htmlspecialchars($reg['c_name']); ?>
                                        </p>
                                    </div>
                                    <div class="registration-status">
                                        <span class="status-badge status-<?php 
                                            echo ($reg['r_status'] == '1') ? 'pending' : 
                                                 (($reg['r_status'] == '2') ? 'approved' : 'rejected'); 
                                        ?>">
                                            <?php echo htmlspecialchars($reg['status_desc']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-inbox fa-3x mb-3"></i>
                            <p>No recent registrations</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Courses Near Capacity -->
        <div class="col-lg-6">
            <div class="content-card">
                <div class="content-card-header">
                    <h5><i class="fas fa-chart-pie me-2"></i>Courses Nearing Capacity</h5>
                </div>
                <div class="content-card-body">
                    <?php if ($near_capacity && mysqli_num_rows($near_capacity) > 0): ?>
                        <?php while ($course = mysqli_fetch_assoc($near_capacity)): ?>
                            <div class="capacity-item">
                                <div class="capacity-content">
                                    <div class="course-info">
                                        <h6 class="course-name">
                                            <i class="fas fa-book-open me-2 text-primary"></i>
                                            <?php echo htmlspecialchars($course['c_name']); ?>
                                        </h6>
                                        <p class="course-code">
                                            <i class="fas fa-code me-2 text-muted"></i>
                                            Code: <?php echo htmlspecialchars($course['c_code']); ?>
                                        </p>
                                    </div>
                                    <div class="capacity-info">
                                        <div class="enrollment-count">
                                            <?php echo $course['enrolled_students']; ?>/<?php echo $course['c_max']; ?>
                                        </div>
                                        <div class="capacity-progress">
                                            <div class="progress">
                                                <div class="progress-bar bg-<?php 
                                                    $percentage = ($course['enrolled_students']/$course['c_max']*100);
                                                    echo ($percentage >= 90) ? 'danger' : 
                                                         (($percentage >= 75) ? 'warning' : 'info'); 
                                                ?>" 
                                                    role="progressbar" 
                                                    style="width: <?php echo $percentage; ?>%">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-chart-line fa-3x mb-3"></i>
                            <p>No courses nearing capacity</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Dashboard Styles */
.welcome-section {
    padding: 20px 0;
}

/* Stat Cards */
.stat-card {
    transition: transform 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.stat-card:hover {
    transform: translateY(-5px);
}

.bg-purple {
    background-color: #6f42c1;
}

.bg-orange {
    background-color: #fd7e14;
}

.display-4 {
    font-size: 2.5rem;
    font-weight: 600;
}

.stat-icon {
    opacity: 0.8;
}

/* Content Cards */
.content-card {
    background: white;
    border-radius: 15px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.05);
    height: 100%;
}

.content-card-header {
    padding: 20px 25px;
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.content-card-header h5 {
    margin: 0;
    color: #2c3e50;
}

.content-card-body {
    padding: 20px 25px;
}

/* Registration and Capacity Items */
.registration-item,
.capacity-item {
    padding: 15px;
    margin-bottom: 15px;
    border-radius: 10px;
    background-color: #f8f9fa;
    transition: all 0.3s ease;
}

.registration-item:hover,
.capacity-item:hover {
    background-color: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.registration-content,
.capacity-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.student-info,
.course-info {
    flex: 1;
}

.student-name,
.course-name {
    font-size: 1rem;
    margin-bottom: 5px;
    color: #2c3e50;
}

.course-name,
.course-code {
    color: #6c757d;
    margin-bottom: 0;
    font-size: 0.9rem;
}

/* Status Badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
}

.status-approved {
    background-color: #d4edda;
    color: #155724;
}

.status-pending {
    background-color: #fff3cd;
    color: #856404;
}

.status-rejected {
    background-color: #f8d7da;
    color: #721c24;
}

/* Capacity Progress */
.capacity-info {
    text-align: right;
}

.enrollment-count {
    font-weight: 500;
    margin-bottom: 5px;
    color: #2c3e50;
}

.capacity-progress {
    width: 120px;
}

.progress {
    height: 8px;
    border-radius: 4px;
    background-color: #e9ecef;
}

/* Card Headers */
.content-card-header h5 {
    font-size: 1.1rem;
    font-weight: 600;
    color: #2c3e50;
}

.content-card-header i {
    opacity: 0.7;
}
</style>

<?php include 'footer.php';?>



