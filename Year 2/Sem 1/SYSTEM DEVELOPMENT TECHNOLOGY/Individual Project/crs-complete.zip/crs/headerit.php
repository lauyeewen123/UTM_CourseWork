<?php
require_once 'session_config.php';
checkITStaffLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Registration System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Add Font Awesome for icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <style>
    /* Navbar Styling */
    .navbar {
      padding: 1rem;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .navbar-brand {
      font-size: 1.25rem;
      font-weight: 600;
    }

    .nav-link {
      font-size: 1rem;
      padding: 0.5rem 1rem !important;
      transition: all 0.3s ease;
    }

    .nav-link:hover {
      background-color: rgba(255,255,255,0.1);
      border-radius: 4px;
    }

    .nav-link.active {
      background-color: rgba(255,255,255,0.2);
      border-radius: 4px;
    }

    /* Card Headers Consistency */
    .card-header {
      background-color: #f8f9fa;
      border-bottom: 1px solid rgba(0,0,0,0.125);
      padding: 1rem;
    }

    .card-header h4 {
      color: #2c3e50;
      font-weight: 600;
      margin: 0;
    }

    /* Back Button Consistency */
    .btn-secondary {
      background-color: #6c757d;
      border: none;
      padding: 0.5rem 1rem;
      transition: all 0.3s ease;
    }

    .btn-secondary:hover {
      background-color: #5a6268;
      transform: translateY(-1px);
    }

    /* Search Form Styling */
    .search-form {
      display: flex;
      align-items: center;
    }

    .search-form .form-control {
      border-radius: 4px 0 0 4px;
      border-right: none;
    }

    .search-form .btn {
      border-radius: 0 4px 4px 0;
    }

    /* Footer Styling */
    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: #2c3e50;
      color: white;
      text-align: center;
      padding: 1rem;
      z-index: 1000;
    }

    /* Content Padding for Fixed Footer */
    body {
      padding-bottom: 60px;
    }

    /* Consistent Table Styling */
    .table thead th {
      background-color: #f8f9fa;
      border-bottom: 2px solid #dee2e6;
    }

    /* Badge Styling */
    .badge {
      padding: 0.5em 0.8em;
      font-weight: 500;
    }
  </style>

</head>


<body>

<nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="staff.php">
      <i class="fas fa-user-shield me-2"></i>IT Staff
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'staff.php' ? 'active' : ''; ?>" href="staff.php">
            <i class="fas fa-home me-1"></i>Dashboard
          </a>
        </li>
        
        <!-- Course Management Dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-book me-1"></i>Course Management
          </a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="staff_add_course.php">
              <i class="fas fa-plus me-1"></i>Add New Course
            </a>
            <a class="dropdown-item" href="staff_modify_courses.php">
              <i class="fas fa-edit me-1"></i>Modify Courses
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="staff_view_courses.php">
              <i class="fas fa-list me-1"></i>View All Courses
            </a>
          </div>
        </li>

        <!-- Registration Management -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-clipboard-list me-1"></i>Registration
          </a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="staff_registrations.php">
              <i class="fas fa-tasks me-1"></i>Manage Registrations
            </a>
            <a class="dropdown-item" href="staff_pending_registrations.php">
              <i class="fas fa-clock me-1"></i>Pending Approvals
            </a>
          </div>
        </li>
      </ul>

      <!-- Add Profile and Logout Dropdown -->
      <ul class="navbar-nav ms-auto me-3">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle me-1"></i>
            <?php 
              // Display staff name if available
              if(isset($_SESSION['u_name'])) {
                echo htmlspecialchars($_SESSION['u_name']);
              } else {
                echo "My Account";
              }
            ?>
          </a>
          <div class="dropdown-menu dropdown-menu-end">
            <a class="dropdown-item <?php echo basename($_SERVER['PHP_SELF']) == 'staff_profile.php' ? 'active' : ''; ?>" href="staff_profile.php">
              <i class="fas fa-user me-2"></i>My Profile
            </a>
            <a class="dropdown-item <?php echo basename($_SERVER['PHP_SELF']) == 'edit_staff_profile.php' ? 'active' : ''; ?>" href="edit_staff_profile.php">
              <i class="fas fa-user-edit me-2"></i>Edit Profile
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logout.php">
              <i class="fas fa-sign-out-alt me-2"></i>Logout
            </a>
          </div>
        </li>
      </ul>

      
    </div>
  </div>
</nav>
