<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

// Debug
error_log("Session ID: " . session_id());
error_log("Session funame: " . $_SESSION['funame']);

$lecturer_id = $_SESSION['funame'];

// Get lecturer details with error checking
$sql = "SELECT u.*, COUNT(ca.ca_course) as total_courses 
        FROM tb_user u 
        LEFT JOIN tb_course_assignment ca ON u.u_sno = ca.ca_lecturer 
        AND ca.ca_status = 'active'
        WHERE u.u_sno = ? AND u.u_utype = '1'
        GROUP BY u.u_sno";

if ($stmt = mysqli_prepare($con, $sql)) {
    mysqli_stmt_bind_param($stmt, "s", $lecturer_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $lecturer = mysqli_fetch_assoc($result);
} else {
    die("Query failed: " . mysqli_error($con));
}

// Debug lecturer data
error_log("Lecturer data: " . print_r($lecturer, true));

// If lecturer data is not found, show error
if (!$lecturer) {
    echo '<div class="container py-4">
            <div class="alert alert-danger">
                Error: Lecturer information not found.
            </div>
          </div>';
    include 'footer.php';
    exit();
}

// Debug
error_log("Gender from DB: " . $lecturer['u_gender']);

// Function to format date
function formatDate($date) {
    return date('d-m-Y', strtotime($date));
}

// Function to get gender text - Updated with more detailed checks
function getGender($code) {
    if (empty($code)) {
        return 'Not Specified';
    }
    $code = strtoupper(trim($code)); // Normalize the input
    switch ($code) {
        case 'M':
        case 'MALE':
            return 'Male';
        case 'F':
        case 'FEMALE':
            return 'Female';
        default:
            return 'Not Specified';
    }
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item active">My Profile</li>
        </ol>
    </nav>

    <div class="row">
        <!-- Left Column -->
        <div class="col-md-4">
            <!-- Profile Card -->
            <div class="card profile-card mb-4">
                <div class="card-body text-center">
                    <div class="lecturer-avatar mb-4">
                        <i class="fas fa-user-tie fa-4x"></i>
                    </div>
                    <h4 class="mb-2"><?php echo htmlspecialchars($lecturer['u_name']); ?></h4>
                    <p class="text-muted mb-3">Lecturer ID: <?php echo htmlspecialchars($lecturer['u_sno']); ?></p>
                    <div class="d-grid gap-2">
                        <a href="edit_lecturer_profile.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-edit me-2"></i>Edit Profile
                        </a>
                    </div>
                </div>
            </div>

            <!-- Statistics Card -->
            <div class="card stats-card">
                <div class="card-body">
                    <h5 class="card-title text-uppercase mb-4">Statistics</h5>
                    <div class="stat-item">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="stat-label">
                                <i class="fas fa-book-open me-2"></i>
                                Assigned Courses
                            </div>
                            <div class="stat-value"><?php echo $lecturer['total_courses']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-md-8">
            <!-- Profile Information -->
            <div class="card info-card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Profile Information</h5>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <!-- Full Name -->
                        <div class="info-item">
                            <label>Full Name</label>
                            <div class="info-value"><?php echo htmlspecialchars($lecturer['u_name']); ?></div>
                        </div>

                        <!-- Staff ID -->
                        <div class="info-item">
                            <label>Staff ID</label>
                            <div class="info-value"><?php echo htmlspecialchars($lecturer['u_sno']); ?></div>
                        </div>

                        <!-- Email -->
                        <div class="info-item">
                            <label>Email</label>
                            <div class="info-value">
                                <i class="fas fa-envelope me-2 text-muted"></i>
                                <?php echo htmlspecialchars($lecturer['u_email']); ?>
                            </div>
                        </div>

                        <!-- Phone -->
                        <div class="info-item">
                            <label>Phone</label>
                            <div class="info-value">
                                <i class="fas fa-phone me-2 text-muted"></i>
                                <?php echo htmlspecialchars($lecturer['u_contact']); ?>
                            </div>
                        </div>

                        <!-- Gender -->
                        <div class="info-item">
                            <label>Gender</label>
                            <div class="info-value">
                                <i class="fas fa-user me-2 text-muted"></i>
                                <?php echo htmlspecialchars(getGender($lecturer['u_gender'])); ?>
                            </div>
                        </div>

                        <!-- Date of Birth -->
                        <div class="info-item">
                            <label>Date of Birth</label>
                            <div class="info-value">
                                <i class="fas fa-calendar me-2 text-muted"></i>
                                <?php echo isset($lecturer['u_dob']) ? formatDate($lecturer['u_dob']) : 'Not Specified'; ?>
                            </div>
                        </div>

                        <!-- State -->
                        <div class="info-item">
                            <label>State</label>
                            <div class="info-value">
                                <i class="fas fa-map-marker-alt me-2 text-muted"></i>
                                <?php echo htmlspecialchars($lecturer['u_state'] ?? 'Not Specified'); ?>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="info-item">
                            <label>Address</label>
                            <div class="info-value">
                                <i class="fas fa-home me-2 text-muted"></i>
                                <?php echo htmlspecialchars($lecturer['u_address'] ?? 'Not Specified'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.profile-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,0,0,0.08);
}

.lecturer-avatar {
    width: 120px;
    height: 120px;
    background: linear-gradient(135deg, #6e8efb, #4285f4);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    color: white;
}

.stats-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,0,0,0.08);
}

.info-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,0,0,0.08);
}

.card-header {
    background-color: #fff;
    border-bottom: 1px solid rgba(0,0,0,0.05);
    padding: 1.5rem;
    border-radius: 15px 15px 0 0 !important;
}

.info-grid {
    display: grid;
    gap: 1.5rem;
}

.info-item {
    padding: 1rem;
    border-radius: 10px;
    background-color: #f8f9fa;
    transition: all 0.3s ease;
}

.info-item:hover {
    background-color: #e9ecef;
    transform: translateY(-2px);
}

.info-item label {
    font-size: 0.875rem;
    color: #6c757d;
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.info-value {
    font-size: 1rem;
    color: #212529;
}

.stat-item {
    padding: 1rem;
    background-color: #f8f9fa;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.stat-item:hover {
    background-color: #e9ecef;
}

.stat-label {
    font-size: 0.9rem;
    color: #6c757d;
}

.stat-value {
    font-size: 1.25rem;
    font-weight: 600;
    color: #4285f4;
}

.breadcrumb-item a {
    color: #4285f4;
    text-decoration: none;
    transition: color 0.3s ease;
}

.breadcrumb-item a:hover {
    color: #1967d2;
}

.btn-primary {
    background: linear-gradient(135deg, #6e8efb, #4285f4);
    border: none;
    padding: 0.8rem 1.5rem;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(66, 133, 244, 0.3);
}
</style>

<?php include 'footer.php'; ?> 