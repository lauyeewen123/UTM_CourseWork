<footer class="footer mt-auto py-3 bg-primary text-white">
    <div class="container text-center">
        <div class="d-flex justify-content-center align-items-center">
            <span>CRS Developed by Yeewen &copy; <?php echo date('Y'); ?></span>
        </div>
    </div>
</footer>

<style>
.footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    background-color: #0d6efd !important;
    font-size: 0.9rem;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
}
</style>

</body>
</html>
