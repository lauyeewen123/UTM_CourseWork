<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

// Debug URL parameters
echo "<!-- Debug URL parameters: ";
print_r($_GET);
echo " -->";

// Get student ID from URL and lecturer ID from session
$student_id = isset($_GET['id']) ? mysqli_real_escape_string($con, $_GET['id']) : '';
$lecturer_id = $_SESSION['funame'];

// If no student ID provided, show error
if (empty($student_id)) {
    echo '<div class="container mt-4">
            <div class="alert alert-danger">
                No student ID provided in URL.<br>
                Please access this page through the proper channel with a student ID parameter (?id=S001)
            </div>
          </div>';
    include 'footer.php';
    exit();
}

// Debug output
echo "<!-- Debug Info:<br>
Student ID: $student_id<br>
Lecturer ID: $lecturer_id<br>
-->";

// Modified query to use correct column name u_utype
$student_check = "SELECT * FROM tb_user WHERE u_sno = '$student_id' AND u_utype = '2'";
$student_check_result = mysqli_query($con, $student_check);

// Debug the query
if (!$student_check_result) {
    echo '<div class="container mt-4">
            <div class="alert alert-danger">
                Query Error: ' . mysqli_error($con) . '<br>
                Query: ' . $student_check . '
            </div>
          </div>';
    include 'footer.php';
    exit();
}

if (mysqli_num_rows($student_check_result) == 0) {
    echo '<div class="container mt-4">
            <div class="alert alert-danger">
                Student ID "' . htmlspecialchars($student_id) . '" not found in the system.<br>
                Please check if:<br>
                1. The student ID is correct<br>
                2. The student is registered in the system<br>
                3. You have the correct permissions to view this student
            </div>
          </div>';
    include 'footer.php';
    exit();
}

// Check if student is registered in any of lecturer's courses
$registration_check = "SELECT DISTINCT r.*, c.c_name, c.c_credit 
                      FROM tb_registration r
                      INNER JOIN tb_course c ON r.r_course = c.c_code
                      INNER JOIN tb_course_assignment ca ON c.c_code = ca.ca_course
                      WHERE r.r_student = ? 
                      AND ca.ca_lecturer = ?
                      AND ca.ca_status = 'active'";

if ($stmt = mysqli_prepare($con, $registration_check)) {
    mysqli_stmt_bind_param($stmt, "ss", $student_id, $lecturer_id);
    mysqli_stmt_execute($stmt);
    $registration_result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}

if (mysqli_num_rows($registration_result) == 0) {
    echo '<div class="container mt-4">
            <div class="alert alert-warning">
                This student is not registered in any of your courses.
            </div>
          </div>';
    include 'footer.php';
    exit();
}

// If we get here, we can display the student details
$student_details = mysqli_fetch_assoc($student_check_result);

// Get all courses registered by this student with this lecturer
$courses_query = "SELECT r.*, c.c_name, c.c_credit
                 FROM tb_registration r
                 INNER JOIN tb_course c ON r.r_course = c.c_code
                 INNER JOIN tb_course_assignment ca ON c.c_code = ca.ca_course
                 WHERE r.r_student = ?
                 AND ca.ca_lecturer = ?
                 AND ca.ca_status = 'active'
                 ORDER BY r.r_sem DESC";

if ($stmt = mysqli_prepare($con, $courses_query)) {
    mysqli_stmt_bind_param($stmt, "ss", $student_id, $lecturer_id);
    mysqli_stmt_execute($stmt);
    $courses_result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}

// Enhanced query for detailed student information
$detailed_query = "SELECT 
    u.*,
    COUNT(DISTINCT r.r_course) as total_courses,
    COUNT(DISTINCT CASE WHEN r.r_status = '2' THEN r.r_course END) as approved_courses,
    COUNT(DISTINCT CASE WHEN r.r_status = '1' THEN r.r_course END) as received_courses,
    COUNT(DISTINCT CASE WHEN r.r_status = '3' THEN r.r_course END) as rejected_courses,
    SUM(CASE WHEN r.r_status = '2' THEN c.c_credit ELSE 0 END) as total_credits
    FROM tb_user u
    LEFT JOIN tb_registration r ON u.u_sno = r.r_student
    LEFT JOIN tb_course c ON r.r_course = c.c_code
    LEFT JOIN tb_course_assignment ca ON c.c_code = ca.ca_course
    WHERE u.u_sno = ?
    AND (ca.ca_lecturer = ? OR ca.ca_lecturer IS NULL)
    AND (ca.ca_status = 'active' OR ca.ca_status IS NULL)
    GROUP BY u.u_sno";

if ($stmt = mysqli_prepare($con, $detailed_query)) {
    mysqli_stmt_bind_param($stmt, "ss", $student_id, $lecturer_id);
    mysqli_stmt_execute($stmt);
    $detailed_result = mysqli_stmt_get_result($stmt);
    $student_details = mysqli_fetch_assoc($detailed_result);
} else {
    die("Query failed: " . mysqli_error($con));
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_student_list.php">Course Overview</a></li>
            <li class="breadcrumb-item active">Student Details</li>
        </ol>
    </nav>

    <div class="row mb-4">
        <!-- Main Profile Card -->
        <div class="col-md-4 mb-4 mb-md-0">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <!-- Profile Header -->
                    <div class="text-center mb-4">
                        <div class="student-avatar mx-auto mb-3">
                            <?php if (!empty($student_details['u_profile_pic'])): ?>
                                <img src="<?php echo htmlspecialchars($student_details['u_profile_pic']); ?>" 
                                     class="rounded-circle" alt="Profile Picture"
                                     style="width: 100px; height: 100px; object-fit: cover;">
                            <?php else: ?>
                                <i class="fas fa-user-circle fa-4x text-primary"></i>
                            <?php endif; ?>
                        </div>
                        <h4 class="mb-1"><?php echo htmlspecialchars($student_details['u_name']); ?></h4>
                        <span class="badge bg-primary mb-2">Student</span>
                    </div>

                    <!-- Personal Information -->
                    <div class="personal-info">
                        <h6 class="text-uppercase text-muted mb-3">Personal Information</h6>
                        
                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-id-card me-2"></i>Student ID</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_sno']); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-envelope me-2"></i>Email</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_email']); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-phone me-2"></i>Phone Number</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_contact'] ?? 'Not provided'); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-map-marker-alt me-2"></i>Address</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_address'] ?? 'Not provided'); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-map me-2"></i>State</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_state'] ?? 'Not provided'); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-birthday-cake me-2"></i>Date of Birth</label>
                            <p class="mb-0"><?php echo $student_details['u_dob'] ? date('d M Y', strtotime($student_details['u_dob'])) : 'Not provided'; ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-venus-mars me-2"></i>Gender</label>
                            <p class="mb-0"><?php echo htmlspecialchars($student_details['u_gender'] ?? 'Not provided'); ?></p>
                        </div>

                        <div class="info-item mb-3">
                            <label class="text-muted mb-1"><i class="fas fa-calendar me-2"></i>Registration Date</label>
                            <p class="mb-0"><?php echo date('d M Y', strtotime($student_details['u_req'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics and Course Info (right column) -->
        <div class="col-md-8">
            <!-- Course Registrations -->
            <div class="card shadow-sm">
                <div class="card-header bg-light py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Course Registrations</h5>
                        <span class="badge bg-primary"><?php echo mysqli_num_rows($courses_result); ?> Courses</span>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (mysqli_num_rows($courses_result) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Semester</th>
                                        <th>Course Code</th>
                                        <th>Course Name</th>
                                        <th>Credits</th>
                                        <th>Section</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($course['r_sem']); ?></td>
                                            <td>
                                                <a href="course_details.php?code=<?php echo urlencode($course['r_course']); ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo htmlspecialchars($course['r_course']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo htmlspecialchars($course['c_name']); ?></td>
                                            <td><?php echo htmlspecialchars($course['c_credit']); ?></td>
                                            <td><?php echo htmlspecialchars($course['r_section']); ?></td>
                                            <td>
                                                <?php
                                                switch($course['r_status']) {
                                                    case '1':
                                                        echo '<span class="badge bg-warning">Pending</span>';
                                                        break;
                                                    case '2':
                                                        echo '<span class="badge bg-success">Approved</span>';
                                                        break;
                                                    case '3':
                                                        echo '<span class="badge bg-danger">Rejected</span>';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                            <p class="mb-0">No course registrations found for this student.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

.student-avatar {
    width: 100px;
    height: 100px;
    background-color: #f8f9fa;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    box-shadow: 0 0 0 5px rgba(66, 133, 244, 0.1);
}

.table th {
    font-weight: 600;
    color: #2c3e50;
}

.badge {
    font-size: 0.875rem;
    padding: 0.5em 1em;
}

.breadcrumb-item a {
    color: #4285f4;
    text-decoration: none;
}

.breadcrumb-item a:hover {
    text-decoration: underline;
}

.table-responsive {
    border-radius: 8px;
}

.table {
    margin-bottom: 0;
}

.card-header {
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.text-primary {
    color: #4285f4 !important;
}

.bg-primary {
    background-color: #4285f4 !important;
}

.bg-warning {
    background-color: #f1b44c !important;
}

.table td a {
    color: #4285f4;
}

.table td a:hover {
    color: #1a73e8;
}

.personal-info {
    border-top: 1px solid rgba(0,0,0,0.05);
    padding-top: 1.5rem;
}

.info-item label {
    font-size: 0.875rem;
    display: block;
}

.info-item p {
    font-weight: 500;
}

.info-item i {
    color: #4285f4;
    width: 20px;
}

.text-uppercase {
    letter-spacing: 0.5px;
    font-size: 0.75rem;
    font-weight: 600;
}
</style>

<?php include 'footer.php'; ?> 