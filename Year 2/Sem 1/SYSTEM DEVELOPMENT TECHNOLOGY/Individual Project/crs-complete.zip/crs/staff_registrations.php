<?php
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Handle status update if submitted
if (isset($_POST['update_status'])) {
    $r_tid = mysqli_real_escape_string($con, $_POST['r_tid']);
    $new_status = mysqli_real_escape_string($con, $_POST['new_status']);
    
    // Get course info and current enrollment before updating
    $check_sql = "SELECT r.r_course, c.c_max, 
                  (SELECT COUNT(*) FROM tb_registration 
                   WHERE r_course = r.r_course AND r_status = '2') as current_enrolled
                  FROM tb_registration r
                  JOIN tb_course c ON r.r_course = c.c_code
                  WHERE r.r_tid = '$r_tid'";
    $check_result = mysqli_query($con, $check_sql);
    
    if ($check_result && mysqli_num_rows($check_result) > 0) {
        $check_data = mysqli_fetch_assoc($check_result);
        
        // Check if approving would exceed max students
        if ($new_status == '2' && ($check_data['current_enrolled'] >= $check_data['c_max'])) {
            $_SESSION['error'] = "Cannot approve: Course has reached maximum capacity";
        } else {
            $update_sql = "UPDATE tb_registration SET r_status = '$new_status' WHERE r_tid = '$r_tid'";
            if (mysqli_query($con, $update_sql)) {
                $_SESSION['success'] = "Registration status updated successfully";
            } else {
                $_SESSION['error'] = "Error updating status: " . mysqli_error($con);
            }
        }
    }
}

// Handle registration deletion
if (isset($_GET['delete'])) {
    $r_tid = mysqli_real_escape_string($con, $_GET['delete']);
    $delete_sql = "DELETE FROM tb_registration WHERE r_tid = '$r_tid'";
    if (mysqli_query($con, $delete_sql)) {
        $_SESSION['success'] = "Registration deleted successfully";
    } else {
        $_SESSION['error'] = "Error deleting registration: " . mysqli_error($con);
    }
}

// Get all registrations with related information
$sql = "SELECT r.*, c.c_code, c.c_name, u.u_name, s.s_desc as status_desc,
        c.c_max, 
        (SELECT COUNT(*) FROM tb_registration 
         WHERE r_course = r.r_course AND r_status = '2') as current_enrolled
        FROM tb_registration r
        JOIN tb_course c ON r.r_course = c.c_code
        JOIN tb_user u ON r.r_student = u.u_sno
        JOIN tb_status s ON r.r_status = s.s_id
        ORDER BY r.r_tid DESC";
$result = mysqli_query($con, $sql);

if (!$result) {
    die("Error in query: " . mysqli_error($con));
}

// Get status options for dropdown
$status_sql = "SELECT * FROM tb_status ORDER BY s_id";
$status_result = mysqli_query($con, $status_sql);
if (!$status_result) {
    die("Error fetching statuses: " . mysqli_error($con));
}

$statuses = [];
while ($status = mysqli_fetch_assoc($status_result)) {
    $statuses[] = $status;
}
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <h4 class="mb-0">Manage Student Course Registrations</h4>
            </div>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover" id="registrationTable">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Status</th>
                            <th>Enrollment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['c_code']); ?></td>
                                    <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo ($row['r_status'] == '1') ? 'warning' : 
                                                 (($row['r_status'] == '2') ? 'success' : 'danger'); 
                                        ?>">
                                            <?php echo htmlspecialchars($row['status_desc']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo $row['current_enrolled']; ?>/<?php echo $row['c_max']; ?>
                                        <?php if ($row['current_enrolled'] >= $row['c_max']): ?>
                                            <span class="badge bg-danger">Full</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form method="POST" action="" class="d-inline" onsubmit="return confirmUpdate(this)">
                                            <input type="hidden" name="r_tid" value="<?php echo $row['r_tid']; ?>">
                                            <select name="new_status" class="form-select form-select-sm d-inline-block w-auto me-1">
                                                <?php foreach ($statuses as $status): ?>
                                                    <option value="<?php echo $status['s_id']; ?>"
                                                            <?php echo ($row['r_status'] == $status['s_id']) ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($status['s_desc']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" name="update_status" class="btn btn-primary btn-sm">
                                                Update
                                            </button>
                                        </form>
                                        
                                        <a href="staff_registrations.php?delete=<?php echo $row['r_tid']; ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this registration?')">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No registrations found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables CSS and JS -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
function confirmUpdate(form) {
    const studentName = form.closest('tr').cells[0].textContent;
    const courseCode = form.closest('tr').cells[1].textContent;
    const courseName = form.closest('tr').cells[2].textContent;
    const newStatus = form.querySelector('select[name="new_status"] option:checked').text;
    
    const message = `Are you sure you want to update this registration?\n\n` +
                   `Student: ${studentName}\n` +
                   `Course: ${courseCode} - ${courseName}\n` +
                   `New Status: ${newStatus}\n\n` +
                   `Click OK to confirm the update.`;
    
    return confirm(message);
}

$(document).ready(function() {
    $('#registrationTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
});
</script>

<?php include 'footer.php'; ?> 