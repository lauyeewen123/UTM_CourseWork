-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2025 at 09:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_crs`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_course`
--

CREATE TABLE `tb_course` (
  `c_code` varchar(10) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  `c_credit` int(11) NOT NULL,
  `c_lec` varchar(10) NOT NULL,
  `c_synopsis` text DEFAULT NULL COMMENT 'Course synopsis/description',
  `c_section` int(11) NOT NULL DEFAULT 2 COMMENT 'Number of sections available',
  `c_max` int(11) NOT NULL DEFAULT 35 COMMENT 'Maximum students per section'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course`
--

INSERT INTO `tb_course` (`c_code`, `c_name`, `c_credit`, `c_lec`, `c_synopsis`, `c_section`, `c_max`) VALUES
('SECD2523', 'Database Management', 3, 'L005', 'Concepts and techniques in database design and management. Includes SQL, normalization, and database development lifecycle.', 2, 30),
('SECJ1013', 'Programming Fundamentals', 3, 'L003', 'Introduction to problem solving techniques and programming concepts using Python. Covers basic algorithms, data types, and program structure.', 2, 35),
('SECJ1033', 'Programming Technique 1', 3, 'L002', 'Introduction to programming concepts using C++ programming language. Topics include data types, control structures, functions, arrays, and basic object-oriented programming.', 2, 35),
('SECJ2013', 'Data Structures and Algorithms', 3, 'L005', '-', 2, 30),
('SECJ2154', 'Object Oriented Programming', 3, 'L004', 'Advanced programming concepts using Java with focus on object-oriented principles including inheritance, polymorphism, and encapsulation.', 2, 35),
('SECP3723', 'System Development Technology', 3, 'L001', 'Study of system development methodologies and techniques. Focus on analysis, design, and implementation of software systems.', 2, 35),
('SECR1213', 'Network Communications', 3, 'L001', '-', 2, 30),
('SECV2223', 'Web Programming', 3, 'L003', 'Development of web applications using current technologies and frameworks. Covers HTML, CSS, JavaScript, and backend development.', 2, 35);

-- --------------------------------------------------------

--
-- Table structure for table `tb_course_assignment`
--

CREATE TABLE `tb_course_assignment` (
  `ca_id` int(11) NOT NULL,
  `ca_course` varchar(10) NOT NULL,
  `ca_lecturer` varchar(10) NOT NULL,
  `ca_semester` varchar(20) NOT NULL,
  `ca_status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_course_assignment`
--

INSERT INTO `tb_course_assignment` (`ca_id`, `ca_course`, `ca_lecturer`, `ca_semester`, `ca_status`, `created_at`, `updated_at`) VALUES
(1, 'SECJ1033', 'L002', '2024/2025-1', 'active', '2025-01-24 01:40:08', '2025-01-24 01:40:08'),
(2, 'SECP3723', 'L001', '2024/2025-1', 'active', '2025-01-24 01:40:08', '2025-01-24 01:40:08'),
(5, 'SECJ1013', 'L003', '2024/2025-1', 'active', '2025-01-24 02:09:02', '2025-01-28 08:23:59'),
(7, 'SECJ2154', 'L004', '2024/2025-1', 'active', '2025-01-24 02:09:02', '2025-01-28 08:24:36'),
(9, 'SECD2523', 'L005', '2024/2025-1', 'active', '2025-01-24 02:09:02', '2025-01-28 08:24:52'),
(11, 'SECV2223', 'L003', '2024/2025-1', 'active', '2025-01-24 02:09:02', '2025-01-24 02:09:02'),
(14, 'SECJ2013', 'L005', '2024/2025-1', 'active', '2025-01-28 08:18:22', '2025-01-28 08:18:22'),
(15, 'SECR1213', 'L001', '2024/2025-1', 'active', '2025-01-28 08:25:24', '2025-01-28 08:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_registration`
--

CREATE TABLE `tb_registration` (
  `r_tid` int(11) NOT NULL COMMENT 'This is the transaction id',
  `r_student` varchar(10) NOT NULL,
  `r_course` varchar(10) NOT NULL,
  `r_sem` varchar(11) NOT NULL,
  `r_status` int(11) NOT NULL,
  `r_section` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_registration`
--

INSERT INTO `tb_registration` (`r_tid`, `r_student`, `r_course`, `r_sem`, `r_status`, `r_section`) VALUES
(2, 'S002', 'SECJ1033', '2024/2025-1', 2, 1),
(8, 'S001', 'SECJ1013', '2024/2025-1', 2, 1),
(9, 'S001', 'SECD2523', '2024/2025-1', 2, 2),
(10, 'S002', 'SECP3723', '2024/2025-1', 2, 1),
(12, 'S001', 'SECV2223', '2024/2025-1', 2, 1),
(14, 'S002', 'SECJ1013', '2024/2025-1', 2, 1),
(19, 'S002', 'SECJ2154', '2024/2025-1', 2, 1),
(21, 'S002', 'SECV2223', '2024/2025-1', 2, 1),
(26, 'S001', 'SECJ2154', '2024/2025-1', 2, 2),
(28, 'S001', 'SECP3723', '2024/2025-1', 2, 1),
(33, 'S003', 'SECJ1013', '2024/2025-1', 2, 1),
(34, 'S003', 'SECP3723', '2024/2025-1', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_semester`
--

CREATE TABLE `tb_semester` (
  `s_code` varchar(20) NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `s_start_date` date NOT NULL,
  `s_end_date` date NOT NULL,
  `s_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_semester`
--

INSERT INTO `tb_semester` (`s_code`, `s_name`, `s_start_date`, `s_end_date`, `s_status`, `created_at`, `updated_at`) VALUES
('2024/2025-1', 'Semester 1', '2024-09-01', '2025-01-31', 'active', '2025-01-24 01:40:08', '2025-01-24 01:40:08'),
('2024/2025-2', 'Semester 2', '2025-02-01', '2025-06-30', 'inactive', '2025-01-24 01:40:08', '2025-01-24 01:40:08');

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `s_id` int(11) NOT NULL,
  `s_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`s_id`, `s_desc`) VALUES
(1, 'Received'),
(2, 'Approved'),
(3, 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `u_sno` varchar(10) NOT NULL,
  `u_pwd` varchar(255) DEFAULT NULL,
  `u_email` varchar(30) NOT NULL,
  `u_name` varchar(50) NOT NULL,
  `u_contact` int(11) NOT NULL,
  `u_state` varchar(20) NOT NULL,
  `u_req` timestamp NULL DEFAULT NULL,
  `u_utype` int(11) NOT NULL,
  `u_profile_pic` varchar(255) DEFAULT NULL,
  `u_address` varchar(255) DEFAULT NULL,
  `u_dob` date DEFAULT NULL,
  `u_gender` enum('Male','Female') DEFAULT NULL,
  `reset_token` varchar(64) DEFAULT NULL,
  `reset_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`u_sno`, `u_pwd`, `u_email`, `u_name`, `u_contact`, `u_state`, `u_req`, `u_utype`, `u_profile_pic`, `u_address`, `u_dob`, `u_gender`, `reset_token`, `reset_expiry`) VALUES
('IT001', '$2y$10$Pw.H.L7VMgomObR10avP5.kehdRzYJPCPwzAUWN2UKFabguG7fvt6', 'yeewen@gmail.com', 'Lau Yee Wen', 123456789, 'Kuala Lumpur', '2023-01-31 16:00:00', 3, NULL, 'No 12, Jalan Indah 1, Taman Indah', '1990-01-25', 'Female', NULL, NULL),
('L001', '$2y$10$RW.h.fAjcvBzAFCfPB1a0e7wHRN3eBFVUDLWDoZyZjO9HRxdTbtba', 'aina@gmail.com', 'Aina Abdul', 191111111, 'Johor', '2023-01-31 16:00:00', 1, NULL, 'No 78, Jalan Skudai, Taman Skudai', '1985-08-10', 'Female', NULL, NULL),
('L002', '$2y$10$vEq/7ZCkg4uRpDiNvb5SRuyIS3C6OjfeMURaN/LOVLb8K.uZMTfHe', 'faz@gmail.com', 'Fazura Abdul', 172222222, 'Kelantan', '2023-09-30 16:00:00', 1, NULL, 'No 90, Jalan KB 1/5, Kota Bharu', '1982-11-25', 'Female', NULL, NULL),
('L003', '$2y$10$rQfpj8sVzTqeYPAgHf5xrOQtZBiGvNJap.82fZt7r8MFobaxKAbku', 'sarah.lee@utm.my', 'Dr. Sarah Lee', 12, 'Johor', NULL, 1, NULL, 'No 34, Jalan Pulai 2, Taman Pulai', '1980-04-30', 'Female', NULL, NULL),
('L004', '$2y$10$UzYvz1sODIuFtldcpnCVpOUFA4PdE1ogRcVMBRUGPTPcGrxfxzSAG', 'ahmad.kamal@utm.my', 'Dr. Ahmad Kamal', 13, 'Johor', NULL, 1, NULL, 'No 56, Jalan Tebrau, Taman Tebrau', '1978-09-15', 'Male', NULL, NULL),
('L005', '$2y$10$EZsl2s9M1sDF0nGPuX9fL.uMD.sRYxIc2OP9YfZlFqIL6.mh2MzOO', 'nurul.aina@utm.my', 'Dr. Nurul Aina', 163456789, 'Johor', NULL, 1, NULL, 'No 12, Jalan Larkin, Taman Larkin', '1983-12-05', 'Female', NULL, NULL),
('S001', '$2y$10$gfZ1x.mE3J7Iz/6zxFl/fuoOvaGV0lVCL1IGUG26Of7191syp1t7q', 'fatfat@gmail.com', 'Fatah Abdul', 133333333, 'Melaka', '2024-01-31 16:00:00', 2, 'uploads/profile_pictures/S001_1737806131.jpg', 'No 123, Jalan Melaka Raya 1, Taman Melaka Raya', '2000-05-15', 'Male', NULL, NULL),
('S002', '$2y$10$Trx.SmL2oB7penNUB4Ant.n1g1NrVbUkVGXCR93z5WaEVpw7Z07PS', 'kam@gmail.com', 'Kamarul Abdul', 124444444, 'Selangor', '2023-09-30 16:00:00', 2, NULL, 'No 45, Jalan SS15/4, Subang Jaya', '2001-03-22', 'Male', NULL, NULL),
('S003', '$2y$10$oaZAzEEF0er/G8rf8JbMQ.a7K8IE3snsJUJE.ITLhg20VUIRFT3B.', 'gennie6922@gmail.com', 'Gennie Lau', 166896478, 'Johor', '2025-01-27 06:45:25', 2, 'uploads/profile_pictures/S003_1738050632.jpg', 'No 22, Jalan Bukit Indah, Taman Bukit Indah', '2004-02-22', 'Female', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_utype`
--

CREATE TABLE `tb_utype` (
  `t_id` int(11) NOT NULL,
  `t_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_utype`
--

INSERT INTO `tb_utype` (`t_id`, `t_desc`) VALUES
(1, 'Lecturer'),
(2, 'Student'),
(3, 'IT Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD PRIMARY KEY (`c_code`),
  ADD KEY `c_lec` (`c_lec`);

--
-- Indexes for table `tb_course_assignment`
--
ALTER TABLE `tb_course_assignment`
  ADD PRIMARY KEY (`ca_id`),
  ADD KEY `fk_course` (`ca_course`),
  ADD KEY `fk_lecturer` (`ca_lecturer`),
  ADD KEY `fk_semester` (`ca_semester`);

--
-- Indexes for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD PRIMARY KEY (`r_tid`) USING BTREE,
  ADD KEY `r_student` (`r_student`),
  ADD KEY `r_course` (`r_course`),
  ADD KEY `r_status` (`r_status`);

--
-- Indexes for table `tb_semester`
--
ALTER TABLE `tb_semester`
  ADD PRIMARY KEY (`s_code`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`u_sno`),
  ADD KEY `u_utype` (`u_utype`);

--
-- Indexes for table `tb_utype`
--
ALTER TABLE `tb_utype`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_course_assignment`
--
ALTER TABLE `tb_course_assignment`
  MODIFY `ca_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tb_registration`
--
ALTER TABLE `tb_registration`
  MODIFY `r_tid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'This is the transaction id', AUTO_INCREMENT=35;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_course`
--
ALTER TABLE `tb_course`
  ADD CONSTRAINT `tb_course_ibfk_1` FOREIGN KEY (`c_lec`) REFERENCES `tb_user` (`u_sno`);

--
-- Constraints for table `tb_course_assignment`
--
ALTER TABLE `tb_course_assignment`
  ADD CONSTRAINT `fk_course` FOREIGN KEY (`ca_course`) REFERENCES `tb_course` (`c_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_lecturer` FOREIGN KEY (`ca_lecturer`) REFERENCES `tb_user` (`u_sno`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_semester` FOREIGN KEY (`ca_semester`) REFERENCES `tb_semester` (`s_code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_registration`
--
ALTER TABLE `tb_registration`
  ADD CONSTRAINT `tb_registration_ibfk_1` FOREIGN KEY (`r_student`) REFERENCES `tb_user` (`u_sno`),
  ADD CONSTRAINT `tb_registration_ibfk_2` FOREIGN KEY (`r_course`) REFERENCES `tb_course` (`c_code`),
  ADD CONSTRAINT `tb_registration_ibfk_3` FOREIGN KEY (`r_status`) REFERENCES `tb_status` (`s_id`);

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`u_utype`) REFERENCES `tb_utype` (`t_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
