<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
if ($_SESSION['urole'] != 'admin') {
    header('Location: login.php');
    exit();
}
include 'headeradmin.php';
include 'dbconnect.php';

// Get summary counts
$sql_courses = "SELECT COUNT(*) as total_courses FROM tb_course";
$sql_students = "SELECT COUNT(*) as total_students FROM tb_user WHERE u_role='student'";
$sql_lecturers = "SELECT COUNT(*) as total_lecturers FROM tb_user WHERE u_role='lecturer'";
$sql_pending = "SELECT COUNT(*) as pending_registrations FROM tb_registration WHERE r_status='1'";

$courses = mysqli_fetch_assoc(mysqli_query($con, $sql_courses));
$students = mysqli_fetch_assoc(mysqli_query($con, $sql_students));
$lecturers = mysqli_fetch_assoc(mysqli_query($con, $sql_lecturers));
$pending = mysqli_fetch_assoc(mysqli_query($con, $sql_pending));
?>

<div class="container py-4">
    <h2 class="mb-4">Admin Dashboard</h2>
    
    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Courses</h5>
                    <h2><?php echo $courses['total_courses']; ?></h2>
                    <a href="admin_courses.php" class="text-white">Manage Courses →</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Students</h5>
                    <h2><?php echo $students['total_students']; ?></h2>
                    <a href="admin_students.php" class="text-white">View Students →</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Lecturers</h5>
                    <h2><?php echo $lecturers['total_lecturers']; ?></h2>
                    <a href="admin_lecturers.php" class="text-white">View Lecturers →</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5 class="card-title">Pending Registrations</h5>
                    <h2><?php echo $pending['pending_registrations']; ?></h2>
                    <a href="admin_registrations.php" class="text-dark">View Registrations →</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <a href="admin_add_course.php" class="btn btn-primary w-100 mb-2">
                                <i class="fas fa-plus"></i> Add New Course
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_courses.php" class="btn btn-success w-100 mb-2">
                                <i class="fas fa-edit"></i> Modify Courses
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_registrations.php" class="btn btn-warning w-100 mb-2">
                                <i class="fas fa-tasks"></i> Manage Registrations
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="admin_reports.php" class="btn btn-info w-100 mb-2">
                                <i class="fas fa-chart-bar"></i> View Reports
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Recent Activities</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Course</th>
                            <th>Student</th>
                            <th>Action</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT r.*, c.c_name, u.u_name, s.s_desc
                                FROM tb_registration r
                                JOIN tb_course c ON r.r_course = c.c_code
                                JOIN tb_user u ON r.r_student = u.u_sno
                                JOIN tb_status s ON r.r_status = s.s_id
                                ORDER BY r.r_date DESC LIMIT 5";
                        $result = mysqli_query($con, $sql);
                        
                        while ($row = mysqli_fetch_assoc($result)) {
                            $statusClass = ($row['r_status'] == '1') ? 'warning' : 
                                         (($row['r_status'] == '2') ? 'success' : 'danger');
                            
                            echo "<tr>";
                            echo "<td>" . date('Y-m-d', strtotime($row['r_date'])) . "</td>";
                            echo "<td>" . htmlspecialchars($row['c_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['u_name']) . "</td>";
                            echo "<td>Course Registration</td>";
                            echo "<td><span class='badge bg-{$statusClass}'>" . 
                                 htmlspecialchars($row['s_desc']) . "</span></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 