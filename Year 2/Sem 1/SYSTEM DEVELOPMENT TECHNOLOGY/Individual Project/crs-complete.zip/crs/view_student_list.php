<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

$lecturer_id = $_SESSION['funame'];

// Get current semester
$sem_query = "SELECT DISTINCT r_sem FROM tb_registration ORDER BY r_sem DESC LIMIT 1";
$sem_result = mysqli_query($con, $sem_query);
$current_sem = mysqli_fetch_assoc($sem_result)['r_sem'];

// Get all courses assigned to this lecturer using course_assignment table
$courses_query = "SELECT c.*, 
                  COUNT(DISTINCT r.r_student) as student_count,
                  COUNT(DISTINCT CASE WHEN r.r_sem = ? THEN r.r_student END) as current_students
                  FROM tb_course_assignment ca
                  INNER JOIN tb_course c ON ca.ca_course = c.c_code
                  LEFT JOIN tb_registration r ON c.c_code = r.r_course
                  WHERE ca.ca_lecturer = ? 
                  AND ca.ca_semester = ?
                  AND ca.ca_status = 'active'
                  GROUP BY c.c_code
                  ORDER BY c.c_code";

if ($stmt = mysqli_prepare($con, $courses_query)) {
    mysqli_stmt_bind_param($stmt, "sss", $current_sem, $lecturer_id, $current_sem);
    mysqli_stmt_execute($stmt);
    $courses_result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}

// Debug
error_log("Lecturer ID: " . $lecturer_id);
error_log("Current Semester: " . $current_sem);
error_log("Number of courses found: " . mysqli_num_rows($courses_result));
?>

<div class="container py-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">My Courses Overview</h4>
            <p class="text-muted mb-0">Current Semester: <?php echo htmlspecialchars($current_sem); ?></p>
        </div>
        <div class="d-flex gap-2">
            <a href="courselist.php" class="btn btn-outline-primary">
                <i class="fas fa-list me-1"></i> Registration List
            </a>
        </div>
    </div>

    <!-- Course Cards -->
    <div class="row g-4">
        <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
            <?php
            // Get student counts by status for this course in current semester
            $status_query = "SELECT 
                COUNT(CASE WHEN r_status = '2' THEN 1 END) as approved,
                COUNT(CASE WHEN r_status = '1' THEN 1 END) as pending,
                COUNT(CASE WHEN r_status = '3' THEN 1 END) as rejected
                FROM tb_registration 
                WHERE r_course = '{$course['c_code']}'
                AND r_sem = '$current_sem'";
            $status_result = mysqli_query($con, $status_query);
            $status_counts = mysqli_fetch_assoc($status_result);
            
            // Calculate capacity percentage
            $capacity_percentage = ($status_counts['approved'] / $course['c_max']) * 100;
            $capacity_class = $capacity_percentage >= 90 ? 'bg-danger' : 
                            ($capacity_percentage >= 70 ? 'bg-warning' : 'bg-success');
            ?>
            
            <div class="col-md-6 col-lg-4">
                <div class="card h-100">
                    <div class="card-header bg-light py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0"><?php echo htmlspecialchars($course['c_code']); ?></h5>
                            <span class="badge bg-primary"><?php echo htmlspecialchars($course['c_credit']); ?> Credits</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h6 class="mb-3"><?php echo htmlspecialchars($course['c_name']); ?></h6>
                        
                        <!-- Capacity Progress Bar -->
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">Course Capacity</small>
                                <small class="text-muted"><?php echo $status_counts['approved']; ?>/<?php echo $course['c_max']; ?></small>
                            </div>
                            <div class="progress" style="height: 6px;">
                                <div class="progress-bar <?php echo $capacity_class; ?>" 
                                     role="progressbar" 
                                     style="width: <?php echo $capacity_percentage; ?>%" 
                                     aria-valuenow="<?php echo $capacity_percentage; ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100"></div>
                            </div>
                        </div>

                        <!-- Status Counts -->
                        <div class="d-flex justify-content-between mb-3">
                            <?php if ($status_counts['pending'] > 0): ?>
                                <span class="badge bg-warning">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo $status_counts['pending']; ?> Pending
                                </span>
                            <?php endif; ?>
                            <?php if ($status_counts['approved'] > 0): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check me-1"></i>
                                    <?php echo $status_counts['approved']; ?> Enrolled
                                </span>
                            <?php endif; ?>
                            <?php if ($status_counts['rejected'] > 0): ?>
                                <span class="badge bg-danger">
                                    <i class="fas fa-times me-1"></i>
                                    <?php echo $status_counts['rejected']; ?> Rejected
                                </span>
                            <?php endif; ?>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-grid gap-2">
                            <a href="view_course_students.php?code=<?php echo urlencode($course['c_code']); ?>" 
                               class="btn btn-primary">
                                <i class="fas fa-users me-1"></i> View Students
                            </a>
                            <a href="course_details.php?code=<?php echo urlencode($course['c_code']); ?>" 
                               class="btn btn-outline-secondary">
                                <i class="fas fa-info-circle me-1"></i> Course Details
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>

        <?php if (mysqli_num_rows($courses_result) == 0): ?>
            <div class="col-12">
                <div class="card bg-light border-0">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                        <h5>No Courses Assigned</h5>
                        <p class="text-muted mb-0">You currently don't have any courses assigned to you.</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.card {
    transition: transform 0.2s;
    border: none;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.card-header {
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.badge {
    padding: 0.5em 0.8em;
    font-weight: 500;
}

.progress {
    background-color: #e9ecef;
    border-radius: 10px;
}

.progress-bar {
    border-radius: 10px;
}

.btn {
    padding: 0.5rem 1rem;
    font-weight: 500;
}

.btn-outline-secondary {
    border-color: #dee2e6;
    color: #6c757d;
}

.btn-outline-secondary:hover {
    background-color: #f8f9fa;
    color: #6c757d;
    border-color: #dee2e6;
}

.text-muted {
    color: #6c757d !important;
}
</style>

<?php include 'footer.php'; ?> 