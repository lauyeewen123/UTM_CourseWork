<?php
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get all registration history with related information
$sql = "SELECT r.*, c.c_name, u.u_name, s.s_desc as status_desc,
        c.c_max, 
        (SELECT COUNT(*) FROM tb_registration 
         WHERE r_course = r.r_course AND r_status = '2') as current_enrolled
        FROM tb_registration r
        JOIN tb_course c ON r.r_course = c.c_code
        JOIN tb_user u ON r.r_student = u.u_sno
        JOIN tb_status s ON r.r_status = s.s_id
        ORDER BY r.reg_date DESC";
$result = mysqli_query($con, $sql);
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <h4 class="mb-0">Registration History</h4>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="historyTable">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Status</th>
                            <th>Course Capacity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo date('Y-m-d', strtotime($row['reg_date'])); ?></td>
                                <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo ($row['r_status'] == '1') ? 'warning' : 
                                             (($row['r_status'] == '2') ? 'success' : 'danger'); 
                                    ?>">
                                        <?php echo htmlspecialchars($row['status_desc']); ?>
                                    </span>
                                </td>
                                <td><?php echo $row['current_enrolled']; ?>/<?php echo $row['c_max']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#historyTable').DataTable({
        "order": [[0, "desc"]],
        "pageLength": 25
    });
});
</script> 