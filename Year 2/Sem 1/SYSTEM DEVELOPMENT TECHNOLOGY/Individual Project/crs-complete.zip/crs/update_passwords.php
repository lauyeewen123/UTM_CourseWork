<?php
include('dbconnect.php');

// Array of user credentials [username => plain_password]
$users = [
    'IT001' => '123456',
    'IT002' => '123456', 
    'L001' => '123456',
    'L002' => '123456',
    'L003' => '123456',
    'L004' => '123456',
    'L005' => '123456',
    'S001' => '123456',
    'S002' => '123456'
];

foreach ($users as $username => $password) {
    // Generate proper password hash
    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Update the database
    $query = "UPDATE tb_user SET u_pwd = ? WHERE u_sno = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "ss", $hash, $username);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "Updated password for $username<br>";
    } else {
        echo "Error updating password for $username: " . mysqli_error($con) . "<br>";
    }
}

mysqli_close($con);
echo "Password update complete!";
?> 