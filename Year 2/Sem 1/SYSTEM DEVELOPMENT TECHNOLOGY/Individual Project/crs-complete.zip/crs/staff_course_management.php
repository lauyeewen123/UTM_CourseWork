<?php
require_once 'session_config.php';
checkITStaffLogin();

include 'headerit.php';
include 'dbconnect.php';
if(!session_id()) {
    session_start();
}
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <h4 class="mb-0">Course Management</h4>
            </div>
        </div>
        <div class="card-body">
            <div class="list-group">
                <a href="staff_add_course.php" class="list-group-item list-group-item-action d-flex align-items-center">
                    <i class="fas fa-plus-circle me-3"></i>
                    Add New Course
                </a>
                <a href="staff_modify_courses.php" class="list-group-item list-group-item-action d-flex align-items-center">
                    <i class="fas fa-edit me-3"></i>
                    Modify Courses
                </a>
                <a href="staff_view_courses.php" class="list-group-item list-group-item-action d-flex align-items-center">
                    <i class="fas fa-list me-3"></i>
                    View All Courses
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 