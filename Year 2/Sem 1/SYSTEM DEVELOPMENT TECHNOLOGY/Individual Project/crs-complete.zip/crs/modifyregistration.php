<?php
session_start();
require_once 'crssession.php';
require_once 'dbconnect.php';
include 'headerstudent.php';

$uic = $_SESSION['funame'];

// Display any messages
if(isset($_SESSION['success'])) {
    echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
            " . $_SESSION['success'] . "
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    unset($_SESSION['success']);
}
if(isset($_SESSION['error'])) {
    echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
            " . $_SESSION['error'] . "
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
          </div>";
    unset($_SESSION['error']);
}

// Calculate total credits for current registrations
$sql_credits = "SELECT SUM(c.c_credit) as total_credits
                FROM tb_registration r
                JOIN tb_course c ON r.r_course = c.c_code
                WHERE r.r_student = '$uic' 
                AND r.r_sem = '2024/2025-1'
                AND r.r_status IN (1,2)";
$result_credits = mysqli_query($con, $sql_credits);
$credits = mysqli_fetch_assoc($result_credits);

// Get pending registrations with section info
$sql = "SELECT r.r_tid, r.r_course, c.c_name, r.r_sem, r.r_section,
               s.s_desc as status, c.c_credit,
               (SELECT COUNT(*) 
                FROM tb_registration r2 
                WHERE r2.r_course = r.r_course 
                AND r2.r_section = r.r_section 
                AND r2.r_status IN (1,2)) as section_enrolled,
               c.c_max as section_capacity
        FROM tb_registration r
        LEFT JOIN tb_course c ON r.r_course = c.c_code
        LEFT JOIN tb_status s ON r.r_status = s.s_id
        WHERE r.r_student = '$uic' 
        ORDER BY r.r_sem DESC, r.r_course ASC";

$result = mysqli_query($con, $sql);
?>

<div class="container">
    <br><br>
    <h5>Modify Registration</h5>

    <!-- Credit Summary Card -->
    <div class="card mb-4">
        <div class="card-body">
            <h6>Total Credits Selected: <?php echo $credits['total_credits'] ?? 0; ?> credits</h6>
        </div>
    </div>

    <form action="process_registration.php" method="POST">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Section</th>
                    <th>Credits</th>
                    <th>Semester</th>
                    <th>Status</th>
                    <th>Section Capacity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if(mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_array($result)) { 
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['r_course']); ?></td>
                        <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['r_section']); ?></td>
                        <td><?php echo htmlspecialchars($row['c_credit']); ?></td>
                        <td><?php echo htmlspecialchars($row['r_sem']); ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo ($row['status'] == 'Received') ? 'warning' : 
                                     (($row['status'] == 'Approved') ? 'success' : 'danger'); 
                            ?>">
                                <?php echo htmlspecialchars($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo $row['section_enrolled']; ?>/<?php echo $row['section_capacity']; ?>
                        </td>
                        <td>
                            <?php if($row['status'] == 'Received') { ?>
                                <button type="button" class="btn btn-sm btn-danger" 
                                        onclick="submitForm('<?php echo $row['r_tid']; ?>')">
                                    Cancel
                                </button>
                            <?php } ?>
                        </td>
                    </tr>
                <?php 
                    }
                ?>
                    <!-- Submit button row -->
                    <tr>
                        <td colspan="8" class="text-center">
                            <button type="submit" name="submit_all" class="btn btn-primary" 
                                    onclick="return confirmSubmitAll()">
                                Submit All Registrations
                            </button>
                        </td>
                    </tr>
                <?php
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No pending registrations found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </form>

    <!-- Add notice below the button -->
    <div class="alert alert-info mt-3" style="font-size: 0.9rem;">
        <i class="fas fa-info-circle"></i> Important: Please click "Submit All Registrations" button to confirm your course registrations. Your courses will be auto-approved if sections have available capacity.
    </div>
</div>

<script>
// Function to handle cancel confirmation and submission
function submitForm(tid) {
    if(confirm('Are you sure you want to cancel this registration?')) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = 'process_registration.php';
        
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'cancel';
        input.value = tid;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }
}

// Confirmation for submitting all registrations
function confirmSubmitAll() {
    const message = `Are you sure you want to submit all pending registrations?\n\n` +
                   `This will finalize your course registrations for this semester.\n` +
                   `Courses will be auto-approved if sections have available capacity.\n\n` +
                   `This action cannot be undone.`;
    return confirm(message);
}
</script>

<?php 
include 'footer.php'; 