<?php
session_start();
include('dbconnect.php');

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

try {
    if(isset($_POST['email'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Check if email exists
        $query = "SELECT u_sno, u_name FROM tb_user WHERE u_email = ?";
        $stmt = mysqli_prepare($con, $query);
        
        if ($stmt === false) {
            throw new Exception("Database error");
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            
            // Generate secure reset token
            $token = bin2hex(random_bytes(32));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store reset token
            $token_query = "INSERT INTO password_resets (user_id, token, expiry) VALUES (?, ?, ?)";
            $token_stmt = mysqli_prepare($con, $token_query);
            mysqli_stmt_bind_param($token_stmt, "sss", $user['u_sno'], $token, $expiry);
            
            if(mysqli_stmt_execute($token_stmt)) {
                // Configure email
                $to = $email;
                $subject = "Password Reset Request";
                $reset_link = "http://yourdomain.com/reset-password.php?token=" . $token;
                
                $message = "Dear " . htmlspecialchars($user['u_name']) . ",\n\n";
                $message .= "Click the following link to reset your password:\n";
                $message .= $reset_link . "\n\n";
                $message .= "This link will expire in 1 hour.\n";
                $message .= "If you didn't request this, please ignore this email.\n";
                
                $headers = "From: noreply@yourdomain.com";
                
                // Send email
                if(mail($to, $subject, $message, $headers)) {
                    $_SESSION['success'] = "Password reset instructions sent to your email.";
                } else {
                    throw new Exception("Failed to send email");
                }
            } else {
                throw new Exception("Failed to process reset request");
            }
        } else {
            $_SESSION['error'] = "No account found with that email address.";
        }
    }
} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
    $_SESSION['error'] = "An error occurred. Please try again later.";
} finally {
    if (isset($stmt)) {
        mysqli_stmt_close($stmt);
    }
    if (isset($token_stmt)) {
        mysqli_stmt_close($token_stmt);
    }
    if (isset($con)) {
        mysqli_close($con);
    }
}

header("Location: forgot-password.php");
exit();
?> 