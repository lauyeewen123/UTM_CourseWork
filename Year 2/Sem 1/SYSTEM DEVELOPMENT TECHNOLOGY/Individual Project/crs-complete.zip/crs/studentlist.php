<?php
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

// Get course code and lecturer ID from URL or session
$course_code = isset($_GET['course']) ? mysqli_real_escape_string($con, $_GET['course']) : 'SECP3723';
$lecturer_id = mysqli_real_escape_string($con, $_SESSION['funame']);

// Get course details
$course_query = "SELECT c.c_name, c.c_credit, c.c_max 
                 FROM tb_course c 
                 WHERE c.c_code = '$course_code' AND c.c_lec = '$lecturer_id'";
$course_result = mysqli_query($con, $course_query);
$course_data = mysqli_fetch_assoc($course_result);

// Get enrolled students
$student_query = "SELECT r.r_tid, r.r_student, u.u_name, u.u_email, 
                         r.r_status, r.reg_date
                  FROM tb_registration r
                  JOIN tb_user u ON r.r_student = u.u_sno
                  WHERE r.r_course = '$course_code'
                  ORDER BY r.reg_date DESC";
$student_result = mysqli_query($con, $student_query);

if (!$student_result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="#"><?php echo htmlspecialchars($course_code); ?></a></li>
            <li class="breadcrumb-item active">Student List</li>
        </ol>
    </nav>

    <!-- Course Info Card -->
    <div class="card mb-4">
        <div class="card-body bg-light">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo htmlspecialchars($course_code); ?> - <?php echo htmlspecialchars($course_data['c_name']); ?></h4>
                    <p class="text-muted mb-0"><?php echo htmlspecialchars($course_data['c_credit']); ?> Credits</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="badge bg-primary">
                        Class Capacity: <?php echo mysqli_num_rows($student_result); ?>/<?php echo htmlspecialchars($course_data['c_max']); ?> students
                    </div>
                    <?php if (mysqli_num_rows($student_result) < $course_data['c_max']): ?>
                        <div class="badge bg-success ms-2">Auto-approval Available</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Student List Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Student List</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Registration Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($student_result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['r_student']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_email']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $row['r_status'] == 'Approved' ? 'success' : 'warning'; ?>">
                                        <?php echo htmlspecialchars($row['r_status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d M Y H:i', strtotime($row['reg_date'])); ?></td>
                                <td>
                                    <a href="studentdetails.php?id=<?php echo $row['r_student']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-user-circle"></i> View Details
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <?php if (mysqli_num_rows($student_result) == 0): ?>
                            <tr>
                                <td colspan="6" class="text-center">No students enrolled in this course.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?> 