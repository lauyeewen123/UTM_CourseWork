<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'session_config.php';  
checkAdvisorLogin();

// First include the header
include 'headeradvisor.php';

// Then show the success message
if(isset($_SESSION['success_msg'])): ?>
    <div class="alert alert-success alert-dismissible fade show" style="margin: 20px;">
        <strong>Login successfully!</strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success_msg']); // Clear the message ?>
<?php endif;

// Properly separate includes with semicolons
include 'crssession.php';
include 'dbconnect.php';
include 'includes/semester_helper.php';

// Get lecturer ID and ensure it's a string
$lecturer_id = isset($_SESSION['funame']) ? strval($_SESSION['funame']) : '';

// Get current semester and ensure it's a string
$current_semester = strval(getCurrentSemester($con));

// Debug
error_log("Lecturer ID: " . $lecturer_id);
error_log("Current Semester: " . $current_semester);

try {
	// Count assigned courses
	$course_query = "SELECT COUNT(*) as count 
					FROM tb_course_assignment 
					WHERE ca_lecturer = ? 
					AND ca_semester = ? 
					AND ca_status = 'active'";
					
	if ($stmt = mysqli_prepare($con, $course_query)) {
		mysqli_stmt_bind_param($stmt, "ss", $lecturer_id, $current_semester);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$courses_count = mysqli_fetch_assoc($result)['count'];
		mysqli_stmt_close($stmt);
	} else {
		throw new Exception("Failed to prepare course count query");
	}

	// Count total students
	$students_query = "SELECT COUNT(DISTINCT r.r_student) as student_count 
					  FROM tb_course_assignment ca
					  LEFT JOIN tb_registration r ON ca.ca_course = r.r_course 
					  AND r.r_sem = ca.ca_semester
					  WHERE ca.ca_lecturer = ? 
					  AND ca.ca_semester = ?
					  AND ca.ca_status = 'active'";
					  
	if ($stmt = mysqli_prepare($con, $students_query)) {
		mysqli_stmt_bind_param($stmt, "ss", $lecturer_id, $current_semester);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$students_count = mysqli_fetch_assoc($result)['student_count'];
		mysqli_stmt_close($stmt);
	} else {
		throw new Exception("Failed to prepare student count query");
	}

	// Count pending approvals
	$pending_query = "SELECT COUNT(*) as count 
					 FROM tb_course_assignment ca
					 INNER JOIN tb_registration r ON ca.ca_course = r.r_course 
					 AND r.r_sem = ca.ca_semester
					 WHERE ca.ca_lecturer = ? 
					 AND ca.ca_semester = ?
					 AND ca.ca_status = 'active'
					 AND r.r_status = 1";
					 
	if ($stmt = mysqli_prepare($con, $pending_query)) {
		mysqli_stmt_bind_param($stmt, "ss", $lecturer_id, $current_semester);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		$pending_count = mysqli_fetch_assoc($result)['count'];
		mysqli_stmt_close($stmt);
	} else {
		throw new Exception("Failed to prepare pending count query");
	}

	// Get course list
	$courses_query = "SELECT c.c_code, c.c_name, c.c_credit,
					 (SELECT COUNT(*) 
					  FROM tb_registration r 
					  WHERE r.r_course = c.c_code 
					  AND r.r_sem = ?) as student_count
					 FROM tb_course_assignment ca
					 INNER JOIN tb_course c ON ca.ca_course = c.c_code
					 WHERE ca.ca_lecturer = ? 
					 AND ca.ca_semester = ?
					 AND ca.ca_status = 'active'
					 GROUP BY c.c_code, c.c_name, c.c_credit
					 ORDER BY c.c_code";
					 
	if ($stmt = mysqli_prepare($con, $courses_query)) {
		mysqli_stmt_bind_param($stmt, "sss", $current_semester, $lecturer_id, $current_semester);
		mysqli_stmt_execute($stmt);
		$courses_result = mysqli_stmt_get_result($stmt);
	} else {
		throw new Exception("Failed to prepare courses query");
	}

} catch (Exception $e) {
	error_log("Error in advisor.php: " . $e->getMessage());
	$error_message = "An error occurred while loading the dashboard.";
}
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col-12">
            <h2>Lecturer Dashboard</h2>
            <p class="text-muted">Current Semester: <?php echo htmlspecialchars($current_semester); ?></p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <!-- Assigned Courses Card -->
        <div class="col-md-4">
            <div class="stat-card bg-primary">
                <div class="stat-card-content">
                    <h6>Assigned Courses</h6>
                    <h1><?php echo intval($courses_count); ?></h1>
                    <a href="courselist.php" class="stat-link">View Courses <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>

        <!-- Total Students Card -->
        <div class="col-md-4">
            <div class="stat-card bg-success">
                <div class="stat-card-content">
                    <h6>Total Students</h6>
                    <h1><?php echo intval($students_count); ?></h1>
                    <a href="view_student_list.php" class="stat-link">View Students <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>

        <!-- Pending Approvals Card -->
        <div class="col-md-4">
            <div class="stat-card bg-orange">
                <div class="stat-card-content">
                    <h6>Pending Approvals</h6>
                    <h1><?php echo intval($pending_count); ?></h1>
                    <a href="approval.php" class="stat-link">View Approvals <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>

    <style>
    .stat-card {
        padding: 1.5rem;
        border-radius: 8px;
        color: white;
        height: 100%;
        transition: transform 0.2s;
        position: relative;
    }

    .stat-card:hover {
        transform: translateY(-5px);
    }

    .stat-card-content h6 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 500;
        opacity: 0.9;
    }

    .stat-card-content h1 {
        margin: 0.5rem 0 0.5rem 0;
        font-size: 3.5rem;
        font-weight: 600;
    }

    .stat-link {
        color: rgba(255, 255, 255, 0.8);
        text-decoration: none;
        font-size: 0.9rem;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: color 0.2s;
    }

    .stat-link:hover {
        color: white;
    }

    .stat-link i {
        font-size: 0.8rem;
    }

    .bg-orange {
        background-color: #ff6b35;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .stat-card-content h1 {
            font-size: 2.5rem;
        }
    }
    </style>

    <!-- My Courses Section -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">My Courses</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credit Hours</th>
                            <th>Students</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        while ($course = mysqli_fetch_assoc($courses_result)): 
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($course['c_code']); ?></td>
                                <td><?php echo htmlspecialchars($course['c_name']); ?></td>
                                <td><?php echo htmlspecialchars($course['c_credit']); ?></td>
                                <td><?php echo $course['student_count']; ?></td>
                                <td>
                                    <a href="view_course_students.php?code=<?php echo urlencode($course['c_code']); ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-users me-1"></i> View Student List
                                    </a>
                                    <a href="course_details.php?code=<?php echo urlencode($course['c_code']); ?>" 
                                       class="btn btn-warning btn-sm">
                                        <i class="fas fa-info-circle me-1"></i> Course Details
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                        <?php if (mysqli_num_rows($courses_result) == 0): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-books fa-3x mb-3"></i>
                                        <p>No courses assigned yet.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    margin-bottom: 1.5rem;
}

.table > :not(caption) > * > * {
    padding: 1rem 0.75rem;
}

.btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.875rem;
}

.btn-primary {
    background-color: #0d6efd;
    border-color: #0d6efd;
    color: white;
}

.btn-warning {
    background-color: #fd7e14;
    border-color: #fd7e14;
    color: white;
}

.btn + .btn {
    margin-left: 0.5rem;
}

.table-hover tbody tr:hover {
    background-color: rgba(0,0,0,.02);
}
</style>

<?php include 'footer.php';?>



