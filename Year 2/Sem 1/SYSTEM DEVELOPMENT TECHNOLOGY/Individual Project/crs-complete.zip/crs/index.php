<?php include 'headermain.php';?>

<div class="container">
    <!-- Hero Section -->
    <div class="hero-section text-center py-5">
        <h1 class="display-4 fw-bold mb-4">Welcome to Course Registration System</h1>
        <p class="lead mb-4">Streamline your academic journey with our easy-to-use course registration platform</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="register.php" class="btn btn-primary btn-lg">
                <i class="fas fa-user-plus me-2"></i>Get Started
            </a>
            <a href="login.php" class="btn btn-outline-primary btn-lg">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </a>
        </div>
    </div>

    <!-- Features Section -->
    <div class="row g-4 py-5">
        <div class="col-md-4">
            <div class="feature-card p-4 rounded-3 h-100">
                <div class="feature-icon mb-3">
                    <i class="fas fa-laptop-code fa-2x text-primary"></i>
                </div>
                <h3 class="h5 mb-3">Easy Course Registration</h3>
                <p class="text-muted">Browse and register for courses with just a few clicks. Our intuitive interface makes course selection simple.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card p-4 rounded-3 h-100">
                <div class="feature-icon mb-3">
                    <i class="fas fa-calendar-check fa-2x text-primary"></i>
                </div>
                <h3 class="h5 mb-3">Real-time Updates</h3>
                <p class="text-muted">Get instant updates on course availability, registration status, and important deadlines.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card p-4 rounded-3 h-100">
                <div class="feature-icon mb-3">
                    <i class="fas fa-user-graduate fa-2x text-primary"></i>
                </div>
                <h3 class="h5 mb-3">Academic Progress</h3>
                <p class="text-muted">Track your academic journey and manage your course history efficiently.</p>
            </div>
        </div>
    </div>

    <!-- Call to Action -->
    <div class="cta-section text-center py-5">
        <h2 class="mb-4">Ready to Begin?</h2>
        <p class="lead mb-4">Join thousands of students who have already simplified their course registration process.</p>
        <a href="register.php" class="btn btn-lg btn-primary">Register Now</a>
    </div>
</div>

<style>
:root {
    --primary-blue: #4285f4;
    --secondary-blue: #5c9fff;
    --hover-blue: #1a73e8;
    --light-blue: #f3f8ff;
}

.hero-section {
    padding: 5rem 0;
    background: linear-gradient(135deg, var(--light-blue) 0%, #ffffff 100%);
    border-radius: 16px;
    margin: 2rem 0;
}

.feature-card {
    background: white;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: 1px solid rgba(0,0,0,0.05);
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
}

.feature-icon {
    color: var(--primary-blue);
}

.btn-primary {
    background: var(--primary-blue);
    border-color: var(--primary-blue);
    padding: 0.8rem 2rem;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: var(--hover-blue);
    border-color: var(--hover-blue);
    transform: translateY(-2px);
}

.btn-outline-primary {
    color: var(--primary-blue);
    border-color: var(--primary-blue);
    padding: 0.8rem 2rem;
    transition: all 0.3s ease;
}

.btn-outline-primary:hover {
    background: var(--primary-blue);
    border-color: var(--primary-blue);
    transform: translateY(-2px);
}

.cta-section {
    background: linear-gradient(135deg, var(--light-blue) 0%, #ffffff 100%);
    border-radius: 16px;
    margin: 2rem 0;
    padding: 4rem 2rem;
}

@media (max-width: 768px) {
    .hero-section {
        padding: 3rem 1rem;
    }
    
    .feature-card {
        margin-bottom: 1rem;
    }
}
</style>

<?php include 'footer.php';?>



