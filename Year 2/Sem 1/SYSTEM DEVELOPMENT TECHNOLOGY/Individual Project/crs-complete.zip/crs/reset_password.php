<?php
date_default_timezone_set('Asia/Kuala_Lumpur');
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once 'dbconnect.php';

// Verify token silently
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $stmt = $con->prepare("SELECT * FROM tb_user WHERE reset_token = ? AND reset_expiry > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
              <script>
              Swal.fire({
                  icon: 'error',
                  title: 'Invalid or Expired Link',
                  text: 'Please request a new password reset link.',
                  confirmButtonColor: '#3085d6'
              }).then((result) => {
                  if (result.isConfirmed) {
                      window.location.href = 'forgot-password.php';
                  }
              });
              </script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .password-requirements {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 10px;
        }
        .requirement {
            margin: 5px 0;
        }
        .requirement i {
            margin-right: 5px;
        }
        .requirement.valid {
            color: #198754;
        }
        .requirement.invalid {
            color: #dc3545;
        }
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="text-center mb-0">Reset Password</h3>
                    </div>
                    <div class="card-body">
                        <form action="update_password.php" method="POST" onsubmit="return validateForm()">
                            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">Student/Staff ID</label>
                                <input type="text" class="form-control" id="user_id" name="user_id" required>
                            </div>
                            <div class="mb-3 position-relative">
                                <label for="password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <i class="bi bi-eye-slash password-toggle" id="togglePassword"></i>
                            </div>
                            <div class="password-requirements">
                                <div class="requirement" id="length">
                                    <i class="bi bi-x-circle"></i> At least 8 characters long
                                </div>
                                <div class="requirement" id="uppercase">
                                    <i class="bi bi-x-circle"></i> Contains uppercase letter
                                </div>
                                <div class="requirement" id="lowercase">
                                    <i class="bi bi-x-circle"></i> Contains lowercase letter
                                </div>
                                <div class="requirement" id="number">
                                    <i class="bi bi-x-circle"></i> Contains number
                                </div>
                                <div class="requirement" id="special">
                                    <i class="bi bi-x-circle"></i> Contains special character
                                </div>
                            </div>
                            <div class="mb-3 position-relative">
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                <i class="bi bi-eye-slash password-toggle" id="toggleConfirmPassword"></i>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Reset Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function validateForm() {
        var password = document.getElementById('password').value;
        var confirmPassword = document.getElementById('confirm_password').value;
        
        // Check if all requirements are met
        if (!isPasswordValid(password)) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid Password',
                text: 'Please meet all password requirements.',
                confirmButtonColor: '#3085d6'
            });
            return false;
        }
        
        if (password !== confirmPassword) {
            Swal.fire({
                icon: 'error',
                title: 'Passwords Do Not Match',
                text: 'Please make sure both passwords are the same.',
                confirmButtonColor: '#3085d6'
            });
            return false;
        }
        return true;
    }

    function isPasswordValid(password) {
        const requirements = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        return Object.values(requirements).every(req => req === true);
    }

    // Real-time password validation
    document.getElementById('password').addEventListener('input', function() {
        const password = this.value;
        updateRequirements(password);
    });

    function updateRequirements(password) {
        const requirements = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        for (const [req, valid] of Object.entries(requirements)) {
            const element = document.getElementById(req);
            element.classList.toggle('valid', valid);
            element.classList.toggle('invalid', !valid);
            element.querySelector('i').className = valid ? 'bi bi-check-circle' : 'bi bi-x-circle';
        }
    }

    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const password = document.getElementById('password');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.className = `bi ${type === 'password' ? 'bi-eye-slash' : 'bi-eye'} password-toggle`;
    });

    document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
        const password = document.getElementById('confirm_password');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.className = `bi ${type === 'password' ? 'bi-eye-slash' : 'bi-eye'} password-toggle`;
    });
    </script>
</body>
</html> 