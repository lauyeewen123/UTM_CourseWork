<?php
ob_start();
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get all courses with lecturer names and enrollment counts
$sql = "SELECT c.*, u.u_name as lecturer_name,
        (SELECT COUNT(*) FROM tb_registration r 
         WHERE r.r_course = c.c_code AND r.r_status = '2') as enrolled_students
        FROM tb_course c
        LEFT JOIN tb_user u ON c.c_lec = u.u_sno
        ORDER BY c.c_code";
$result = mysqli_query($con, $sql);

// Handle course deletion
if (isset($_GET['delete'])) {
    $course_code = mysqli_real_escape_string($con, $_GET['delete']);
    
    // Check if course has enrollments
    $check_sql = "SELECT COUNT(*) as count FROM tb_registration WHERE r_course = '$course_code'";
    $check_result = mysqli_query($con, $check_sql);
    $check_data = mysqli_fetch_assoc($check_result);
    
    if ($check_data['count'] > 0) {
        $_SESSION['error'] = "Cannot delete course: Students are enrolled in this course";
    } else {
        $delete_sql = "DELETE FROM tb_course WHERE c_code = '$course_code'";
        if (mysqli_query($con, $delete_sql)) {
            $_SESSION['success'] = "Course deleted successfully";
            header("Location: staff_modify_courses.php");
            exit();
        } else {
            $_SESSION['error'] = "Error deleting course: " . mysqli_error($con);
        }
    }
}
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff_course_management.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Course Management
                </a>
                <h4 class="mb-0">Modify Courses</h4>
            </div>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover" id="coursesTable">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credit Hours</th>
                            <th>Max Students</th>
                            <th>Lecturer</th>
                            <th>Current Enrollment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['c_code']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_credit']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_max']); ?></td>
                                <td><?php echo htmlspecialchars($row['lecturer_name']); ?></td>
                                <td>
                                    <?php echo $row['enrolled_students']; ?>/<?php echo $row['c_max']; ?>
                                    <?php if ($row['enrolled_students'] >= $row['c_max']): ?>
                                        <span class="badge bg-danger">Full</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="staff_edit_course.php?code=<?php echo urlencode($row['c_code']); ?>" 
                                       class="btn btn-primary btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    
                                    <?php if ($row['enrolled_students'] == 0): ?>
                                        <button onclick="confirmDelete('<?php echo htmlspecialchars($row['c_code']); ?>', '<?php echo htmlspecialchars($row['c_name']); ?>')" 
                                                class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#coursesTable').DataTable({
        "pageLength": 25
    });
});

function confirmDelete(courseCode, courseName) {
    const message = `Are you sure you want to delete this course?\n\n` +
                   `Course Code: ${courseCode}\n` +
                   `Course Name: ${courseName}\n\n` +
                   `This action cannot be undone!`;
    
    if (confirm(message)) {
        window.location.href = `staff_modify_courses.php?delete=${encodeURIComponent(courseCode)}`;
    }
}
</script>

<?php include 'footer.php'; ?>
<?php ob_end_flush(); ?> 