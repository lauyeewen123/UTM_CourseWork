<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];
$msg = '';

// Add this at the top of the file after session and includes
if(isset($_SESSION['upload_message'])) {
    $msg = $_SESSION['upload_message'];
    unset($_SESSION['upload_message']); // Clear the message after displaying
}

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// First, get current user data
$username = $_SESSION['funame'];
$query = "SELECT * FROM tb_user WHERE u_sno = ?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Check if user exists
if (!$user) {
    die("User not found");
}

// Add this temporarily for debugging
error_log("Password hash format check: " . substr($user['u_pwd'], 0, 7));
// Should start with "$2y$10$" for bcrypt

// Handle form submission
try {
    if(isset($_POST['update_profile'])) {
        // Sanitize inputs
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $contact = sanitize_input($_POST['contact']);
        $state = sanitize_input($_POST['state']);
        $address = sanitize_input($_POST['address']);
        $dob = sanitize_input($_POST['dob']);
        $gender = $_POST['gender'];
        if (!in_array($gender, ['Male', 'Female'])) {
            $gender = null;
        }

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Prepare update query
        $query = "UPDATE tb_user SET 
                  u_email = ?, 
                  u_contact = ?, 
                  u_state = ?,
                  u_address = ?,
                  u_dob = ?,
                  u_gender = ?
                  WHERE u_sno = ?";

        $update_stmt = mysqli_prepare($con, $query);
        if ($update_stmt === false) {
            throw new Exception("Prepare failed: " . mysqli_error($con));
        }

        // Bind parameters
        mysqli_stmt_bind_param($update_stmt, "sssssss", 
            $email,
            $contact,
            $state,
            $address,
            $dob,
            $gender,
            $username
        );

        // Handle password change if requested
        if(!empty($_POST['current_password']) && !empty($_POST['new_password'])) {
            // Add debug logging
            error_log("Current password from form: " . $_POST['current_password']);
            error_log("Stored hash: " . $user['u_pwd']);
            
            // Verify the current password
            if(password_verify($_POST['current_password'], $user['u_pwd'])) {
                $new_password_hash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                
                $pwd_query = "UPDATE tb_user SET u_pwd = ? WHERE u_sno = ?";
                $pwd_stmt = mysqli_prepare($con, $pwd_query);
                mysqli_stmt_bind_param($pwd_stmt, "ss", $new_password_hash, $username);
                
                if(!mysqli_stmt_execute($pwd_stmt)) {
                    throw new Exception("Failed to update password: " . mysqli_stmt_error($pwd_stmt));
                }
                mysqli_stmt_close($pwd_stmt);
                
                $msg = '<div class="alert alert-success">Password updated successfully!</div>';
            } else {
                // Add specific error message for incorrect password
                error_log("Password verification failed for user: " . $username);
                throw new Exception("Current password is incorrect");
            }
        }

        // Execute the main update
        if (!mysqli_stmt_execute($update_stmt)) {
            throw new Exception("Update failed: " . mysqli_stmt_error($update_stmt));
        }
        mysqli_stmt_close($update_stmt);

        // Refresh user data after update
        $user['u_email'] = $email;
        $user['u_contact'] = $contact;
        $user['u_state'] = $state;
        $user['u_address'] = $address;
        $user['u_dob'] = $dob;
        $user['u_gender'] = $gender;

        $msg = '<div class="alert alert-success">Profile updated successfully!</div>';
    }
} catch (Exception $e) {
    error_log("Profile update error: " . $e->getMessage());
    $msg = '<div class="alert alert-danger">' . $e->getMessage() . '</div>';
}

// Handle profile picture upload
if(isset($_POST['upload_picture'])) {
    try {
        if(!isset($_FILES['profile_picture'])) {
            throw new Exception("No file uploaded");
        }

        $file = $_FILES['profile_picture'];
        
        // Validate file
        if($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Upload failed with error code: " . $file['error']);
        }

        // Validate file type
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_info = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($file_info, $file['tmp_name']);
        finfo_close($file_info);

        if(!in_array($mime_type, $allowed_types)) {
            throw new Exception("Invalid file type. Only JPG, PNG and GIF are allowed.");
        }

        // Validate file size (max 5MB)
        if($file['size'] > 5 * 1024 * 1024) {
            throw new Exception("File is too large. Maximum size is 5MB.");
        }

        // Create upload directory if it doesn't exist
        $upload_dir = 'uploads/profile_pictures/';
        if(!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $username . '_' . time() . '.' . $extension;
        $filepath = $upload_dir . $filename;

        // Move uploaded file
        if(!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new Exception("Failed to save file.");
        }

        // Update database with new profile picture path
        $update_query = "UPDATE tb_user SET u_profile_pic = ? WHERE u_sno = ?";
        $update_stmt = mysqli_prepare($con, $update_query);
        mysqli_stmt_bind_param($update_stmt, "ss", $filepath, $username);
        
        if(!mysqli_stmt_execute($update_stmt)) {
            // If database update fails, delete the uploaded file
            unlink($filepath);
            throw new Exception("Failed to update profile picture in database.");
        }
        mysqli_stmt_close($update_stmt);

        $_SESSION['upload_message'] = '<div class="alert alert-success">Profile picture updated successfully!</div>';
        
        // Redirect to refresh the page and show new image
        header("Location: editprofile.php");
        exit();

    } catch (Exception $e) {
        $_SESSION['upload_message'] = '<div class="alert alert-danger">' . $e->getMessage() . '</div>';
        header("Location: editprofile.php");
        exit();
    }
}

// Update the profile picture display section
$profile_pic = $user['u_profile_pic'] ? $user['u_profile_pic'] . "?t=" . time() : 'img/profilepic.jpg';
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php 
            if(isset($msg)) {
                echo $msg;
            }
            ?>
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-edit me-2"></i>Edit Profile
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Profile Picture Upload -->
                    <div class="text-center mb-4">
                        <img src="<?php echo htmlspecialchars($profile_pic); ?>" class="rounded-circle shadow-sm" 
                             alt="Profile Picture" style="width: 150px; height: 150px; object-fit: cover;">
                        <form method="POST" enctype="multipart/form-data" class="mt-3" onsubmit="return confirmPictureUpdate();">
                            <div class="mb-3">
                                <input type="file" class="form-control" name="profile_picture" 
                                       accept="image/*" required>
                            </div>
                            <button type="submit" name="upload_picture" class="btn btn-primary btn-sm">
                                <i class="fas fa-camera me-2"></i>Update Picture
                            </button>
                        </form>
                        <h4 class="mt-3"><?php echo htmlspecialchars($user['u_name']); ?></h4>
                        <p class="text-muted">Student ID: <?php echo htmlspecialchars($user['u_sno']); ?></p>
                    </div>

                    <!-- Profile Information Form -->
                    <form method="POST" class="needs-validation" novalidate onsubmit="return confirmProfileUpdate();">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-id-card me-2"></i>Student ID
                                </label>
                                <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($user['u_sno']); ?>" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-user me-2"></i>Name
                                </label>
                                <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($user['u_name']); ?>" readonly>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-calendar"></i> Date of Birth
                            </label>
                            <input type="date" name="dob" class="form-control" value="<?php echo $user['u_dob']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-envelope me-2"></i>Email
                            </label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['u_email']); ?>" required>
                            <div class="invalid-feedback">
                                Please provide a valid email address.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-phone me-2"></i>Contact
                            </label>
                            <input type="text" name="contact" class="form-control" value="<?php echo htmlspecialchars($user['u_contact']); ?>" 
                                   pattern="[0-9]+" required>
                            <div class="invalid-feedback">
                                Please provide a valid contact number.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-venus-mars"></i> Gender
                            </label>
                            <select class="form-control" name="gender" id="gender" required>
                                <option value="">Select Gender</option>
                                <option value="Male" <?php echo ($user['u_gender'] === 'Male') ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo ($user['u_gender'] === 'Female') ? 'selected' : ''; ?>>Female</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-home"></i> Address
                            </label>
                            <textarea name="address" class="form-control" rows="3"><?php echo $user['u_address']; ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-map-marker-alt me-2"></i>State
                            </label>
                            <select name="state" class="form-select" required>
                                <?php
                                $states = array("Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan", 
                                              "Pahang", "Penang", "Perak", "Perlis", "Sabah", "Sarawak", 
                                              "Selangor", "Terengganu", "Kuala Lumpur", "Labuan", "Putrajaya");
                                foreach($states as $state) {
                                    $selected = ($state == $user['u_state']) ? 'selected' : '';
                                    echo "<option value='" . htmlspecialchars($state) . "' $selected>" . htmlspecialchars($state) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Password Change Section -->
                        <div class="card mb-4 mt-4 bg-light">
                            <div class="card-body">
                                <h6 class="card-title">
                                    <i class="fas fa-key me-2"></i>Change Password
                                </h6>
                                <div class="mb-3">
                                    <label class="form-label">Current Password</label>
                                    <input type="password" name="current_password" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" id="newPassword" class="form-control">
                                    <div class="mt-2">
                                        <p>Password must contain:</p>
                                        <div id="length">
                                            <span class="check-icon">✗</span> At least 8 characters
                                        </div>
                                        <div id="uppercase">
                                            <span class="check-icon">✗</span> At least one uppercase letter (A-Z)
                                        </div>
                                        <div id="lowercase">
                                            <span class="check-icon">✗</span> At least one lowercase letter (a-z)
                                        </div>
                                        <div id="number">
                                            <span class="check-icon">✗</span> At least one number (0-9)
                                        </div>
                                        <div id="special">
                                            <span class="check-icon">✗</span> At least one special character (!@#$%^&*)
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" name="confirm_password" id="confirmPassword" class="form-control">
                                    <div id="passwordMatch" style="margin-top: 5px;"></div>
                                </div>
                            </div>
                        </div>

                        <style>
                        .check-icon {
                            margin-right: 5px;
                        }
                        #length.valid, #uppercase.valid, #lowercase.valid, #number.valid, #special.valid {
                            color: green;
                        }
                        #length.invalid, #uppercase.invalid, #lowercase.invalid, #number.invalid, #special.invalid {
                            color: red;
                        }
                        </style>

                        <div class="d-grid gap-2">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update Profile
                            </button>
                            <a href="student.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Back to Profile
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form validation script -->
<script>
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>

<!-- Add this JavaScript at the top of your HTML or before closing </body> -->
<script>
function confirmProfileUpdate() {
    return confirm('Are you sure you want to update your profile information?');
}

function confirmPictureUpdate() {
    return confirm('Are you sure you want to update your profile picture?');
}

// Password validation
document.getElementById('newPassword').addEventListener('input', function() {
    const password = this.value;
    
    // Check requirements
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[!@#$%^&*]/.test(password)
    };

    // Update requirement indicators
    Object.keys(requirements).forEach(req => {
        const element = document.getElementById(req);
        const checkIcon = element.querySelector('.check-icon');
        if (requirements[req]) {
            element.className = 'valid';
            checkIcon.textContent = '✓';
        } else {
            element.className = 'invalid';
            checkIcon.textContent = '✗';
        }
    });
});

// Form submission validation
document.querySelector('form').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword || confirmPassword || document.querySelector('[name="current_password"]').value) {
        // Validate current password is filled
        if (!document.querySelector('[name="current_password"]').value) {
            e.preventDefault();
            alert('Please enter your current password');
            return;
        }
        
        // Validate new password fields
        if (!newPassword || !confirmPassword) {
            e.preventDefault();
            alert('Please fill in both new password fields');
            return;
        }
        
        // Validate password requirements
        const requirements = {
            length: newPassword.length >= 8,
            uppercase: /[A-Z]/.test(newPassword),
            lowercase: /[a-z]/.test(newPassword),
            number: /[0-9]/.test(newPassword),
            special: /[!@#$%^&*]/.test(newPassword)
        };
        
        if (!Object.values(requirements).every(Boolean)) {
            e.preventDefault();
            alert('New password does not meet all requirements');
            return;
        }
        
        // Check if passwords match
        if (newPassword !== confirmPassword) {
            e.preventDefault();
            alert('New passwords do not match');
            return;
        }
    }
});

// Add password match validation
document.getElementById('confirmPassword').addEventListener('input', checkPasswordMatch);
document.getElementById('newPassword').addEventListener('input', checkPasswordMatch);

function checkPasswordMatch() {
    const password = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const matchDiv = document.getElementById('passwordMatch');
    
    if (confirmPassword === '') {
        matchDiv.innerHTML = '';
    } else if (password === confirmPassword) {
        matchDiv.innerHTML = '<span style="color: green;">✓ Passwords match</span>';
    } else {
        matchDiv.innerHTML = '<span style="color: red;">✗ Passwords do not match</span>';
    }
}
</script>

<br><br><br><br><br>

<?php include 'footer.php'; ?> 