<?php
date_default_timezone_set('Asia/Kuala_Lumpur');
error_reporting(0); // Turn off error reporting
ini_set('display_errors', 0); // Don't show errors
header('Content-Type: text/html'); // Only output HTML

session_start();
require_once 'dbconnect.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Processing...</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($token) || empty($user_id) || empty($password) || empty($confirm_password)) {
        ?>
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Missing Fields',
            text: 'Please fill in all required fields.',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.history.back();
            }
        });
        </script>
        <?php
        exit();
    }
    
    if ($password !== $confirm_password) {
        ?>
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Passwords Do Not Match',
            text: 'Please make sure your passwords match.',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.history.back();
            }
        });
        </script>
        <?php
        exit();
    }
    
    // First, verify the user ID
    $verify_stmt = $con->prepare("SELECT * FROM tb_user WHERE u_sno = ?");
    $verify_stmt->bind_param("s", $user_id);
    $verify_stmt->execute();
    $result = $verify_stmt->get_result();
    
    if ($result->num_rows == 0) {
        ?>
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Invalid Student/Staff ID',
            text: 'The ID you entered does not match our records.',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.history.back();
            }
        });
        </script>
        <?php
        exit();
    }
    
    // Update password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $update_stmt = $con->prepare("UPDATE tb_user SET u_pwd = ?, reset_token = NULL, reset_expiry = NULL WHERE u_sno = ?");
    $update_stmt->bind_param("ss", $hashed_password, $user_id);
    
    if ($update_stmt->execute()) {
        ?>
        <script>
        Swal.fire({
            icon: 'success',
            title: 'Password Updated!',
            text: 'Your password has been successfully reset.',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'login.php';
            }
        });
        </script>
        <?php
    } else {
        ?>
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Could not update password. Please try again.',
            confirmButtonColor: '#3085d6'
        }).then((result) => {
            if (result.isConfirmed) {
                window.history.back();
            }
        });
        </script>
        <?php
    }
}
?>
</body>
</html> 