<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';
//Get user id
$uic= $_SESSION['funame'];

?>

<style>
.semester-tabs {
    border-bottom: 2px solid var(--primary-blue);
    margin-bottom: 2rem;
}

.nav-tabs {
    border: none;
    gap: 0.5rem;
}

.nav-tabs .nav-link {
    border: none;
    color: var(--text-dark);
    padding: 0.8rem 1.5rem;
    border-radius: 8px 8px 0 0;
    font-weight: 500;
    transition: all 0.3s ease;
}

.nav-tabs .nav-link:hover {
    background: var(--light-blue);
    border: none;
}

.nav-tabs .nav-link.active {
    background: var(--primary-blue);
    color: white;
    border: none;
}

.table {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(66, 133, 244, 0.05);
    overflow: hidden;
}

.table thead {
    background: var(--light-blue);
}

.table th {
    color: var(--text-dark);
    font-weight: 600;
    border-bottom: 2px solid var(--primary-blue);
}

.status-badge {
    padding: 0.4rem 0.8rem;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 500;
}

.status-registered {
    background: #E3F2FD;
    color: #1565C0;
}

.status-pending {
    background: #FFF3E0;
    color: #E65100;
}

.status-completed {
    background: #E8F5E9;
    color: #2E7D32;
}
</style>

<div class="container">
	<br><br>
	<h5 class="section-title">Course Registration History</h5>

	<!-- Semester Tabs -->
	<ul class="nav nav-tabs semester-tabs" id="semesterTabs" role="tablist">
		<li class="nav-item" role="presentation">
			<button class="nav-link active" data-bs-toggle="tab" data-bs-target="#current" type="button">
				Current Semester (2024/2025-1)
			</button>
		</li>
		<li class="nav-item" role="presentation">
			<button class="nav-link" data-bs-toggle="tab" data-bs-target="#previous" type="button">
				Previous Semesters
			</button>
		</li>
	</ul>

	<!-- Tab Content -->
	<div class="tab-content">
		<!-- Current Semester Tab -->
		<div class="tab-pane fade show active" id="current">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Course Code</th>
							<th>Course Name</th>
							<th>Credit Hours</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$current_sem = "2024/2025-1";
						$sql = "SELECT r.*, c.*, s.s_desc 
							   FROM tb_registration r
							   LEFT JOIN tb_course c ON r.r_course = c.c_code
							   LEFT JOIN tb_status s ON r.r_status = s.s_id
							   WHERE r_student = '$uic' AND r_sem = '$current_sem'
							   ORDER BY r_course ASC";
						$result = mysqli_query($con, $sql);
						
						if(mysqli_num_rows($result) > 0) {
							while($row = mysqli_fetch_array($result)) {
								echo "<tr>";
								echo "<td>".$row['r_course']."</td>";
								echo "<td>".$row['c_name']."</td>";
								echo "<td>".$row['c_credit']."</td>";
								echo "<td><span class='status-badge status-".$row['s_desc']."'>".$row['s_desc']."</span></td>";
								echo "</tr>";
							}
						} else {
							echo "<tr><td colspan='4' class='text-center'>No courses registered for current semester</td></tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>

		<!-- Previous Semesters Tab -->
		<div class="tab-pane fade" id="previous">
			<div class="table-responsive">
				<table class="table">
					<thead>
						<tr>
							<th>Semester</th>
							<th>Course Code</th>
							<th>Course Name</th>
							<th>Credit Hours</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$sql = "SELECT r.*, c.*, s.s_desc 
							   FROM tb_registration r
							   LEFT JOIN tb_course c ON r.r_course = c.c_code
							   LEFT JOIN tb_status s ON r.r_status = s.s_id
							   WHERE r_student = '$uic' AND r_sem < '$current_sem'
							   ORDER BY r_sem DESC, r_course ASC";
						$result = mysqli_query($con, $sql);
						
						if(mysqli_num_rows($result) > 0) {
							while($row = mysqli_fetch_array($result)) {
								echo "<tr>";
								echo "<td>".$row['r_sem']."</td>";
								echo "<td>".$row['r_course']."</td>";
								echo "<td>".$row['c_name']."</td>";
								echo "<td>".$row['c_credit']."</td>";
								echo "<td><span class='status-badge status-".$row['s_desc']."'>".$row['s_desc']."</span></td>";
								echo "</tr>";
							}
						} else {
							echo "<tr><td colspan='5' class='text-center'>No previous semester records found</td></tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php include 'footer.php';?>



