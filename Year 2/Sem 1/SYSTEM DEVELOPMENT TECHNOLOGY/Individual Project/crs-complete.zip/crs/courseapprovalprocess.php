<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}


include 'headeradvisor.php';
include 'dbconnect.php';

//Get transaction id
if(isset($_GET['id']))
{
	$tid= $_GET['id'];
}

//Retrieve all registered courses
$sql = "SELECT * FROM tb_registration
		LEFT JOIN tb_user ON tb_registration.r_student = tb_user.u_sno
		LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
		LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
		WHERE r_tid = '$tid'";

//Execute SQL statement
$result= mysqli_query($con, $sql);
$row= mysqli_fetch_array($result);

// Function to check if course is full
function isCourseAvailable($course_code, $con) {
    // Get current enrollment and max capacity
    $sql = "SELECT 
            c.c_max,
            COUNT(DISTINCT CASE WHEN r.r_status = '2' THEN r.r_student END) as enrolled_count
            FROM tb_course c
            LEFT JOIN tb_registration r ON c.c_code = r.r_course
            WHERE c.c_code = '$course_code'
            GROUP BY c.c_code";
    
    $result = mysqli_query($con, $sql);
    if (!$result) {
        die("Error checking course capacity: " . mysqli_error($con));
    }
    
    $row = mysqli_fetch_assoc($result);
    return ($row && $row['enrolled_count'] < $row['c_max']);
}

// Handle registration approval
if (isset($_GET['id'])) {
    $r_tid = mysqli_real_escape_string($con, $_GET['id']);
    $is_auto = isset($_GET['auto']) && $_GET['auto'] == '1';
    
    // Get registration details
    $sql = "SELECT r.r_course, r.r_status, c.c_lec 
            FROM tb_registration r
            JOIN tb_course c ON r.r_course = c.c_code
            WHERE r.r_tid = '$r_tid'";
    $result = mysqli_query($con, $sql);
    
    if (!$result) {
        die("Error getting registration details: " . mysqli_error($con));
    }
    
    $registration = mysqli_fetch_assoc($result);
    
    // Check if lecturer has access to this course
    if ($registration['c_lec'] != $_SESSION['funame']) {
        $_SESSION['error'] = "Access denied";
        header('Location: advisor.php');
        exit();
    }
    
    if ($is_auto) {
        // Check if course is available for auto-approval
        if (isCourseAvailable($registration['r_course'], $con)) {
            // Auto approve the registration
            $sql = "UPDATE tb_registration 
                    SET r_status = '2' 
                    WHERE r_tid = '$r_tid' 
                    AND r_status = '1'";
            $result = mysqli_query($con, $sql);
            
            if ($result) {
                $_SESSION['success'] = "Registration automatically approved";
            } else {
                $_SESSION['error'] = "Error updating registration: " . mysqli_error($con);
            }
        } else {
            $_SESSION['error'] = "Course is full - manual approval required";
        }
        
        header('Location: view_student_list.php?code=' . $registration['r_course']);
        exit();
    } else {
        // Show manual approval form
        include 'headeradvisor.php';
        ?>
        
        <div class="container py-4">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Update Registration Status</h4>
                        </div>
                        <div class="card-body">
                            <?php if (isCourseAvailable($registration['r_course'], $con)): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i> 
                                    Auto-approval is available for this course
                                </div>
                            <?php endif; ?>
                            
                            <form action="courseapprovalprocess.php" method="post">
                                <input type="hidden" name="r_tid" value="<?php echo $r_tid; ?>">
                                
                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="">Select Status</option>
                                        <?php
                                        $sql = "SELECT * FROM tb_status";
                                        $result = mysqli_query($con, $sql);
                                        while ($status = mysqli_fetch_assoc($result)) {
                                            $selected = ($status['s_id'] == $registration['r_status']) ? 'selected' : '';
                                            echo "<option value='{$status['s_id']}' {$selected}>{$status['s_desc']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Update Status</button>
                                <a href="view_student_list.php?code=<?php echo $registration['r_course']; ?>" 
                                   class="btn btn-secondary">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
        include 'footer.php';
        exit();
    }
}

// Handle form submission
if (isset($_POST['r_tid'])) {
    $r_tid = mysqli_real_escape_string($con, $_POST['r_tid']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    
    // Get course code for redirection
    $sql = "SELECT r_course FROM tb_registration WHERE r_tid = '$r_tid'";
    $result = mysqli_query($con, $sql);
    $registration = mysqli_fetch_assoc($result);
    
    // Update status
    $sql = "UPDATE tb_registration SET r_status = '$status' WHERE r_tid = '$r_tid'";
    $result = mysqli_query($con, $sql);
    
    if ($result) {
        $_SESSION['success'] = "Registration status updated successfully";
    } else {
        $_SESSION['error'] = "Error updating status: " . mysqli_error($con);
    }
    
    header('Location: view_student_list.php?code=' . $registration['r_course']);
    exit();
}

// If no valid action, redirect to dashboard
header('Location: advisor.php');
exit();
?>

<div class="container">
<br><br>
	<table class="table table-striped table-hover">
	    <tr>
	      <td>Transaction ID</td>
	      <td><?php echo $row['r_tid']; ?></td>
	    </tr>
	   	<tr>
	      <td>Semester</td>
	      <td><?php echo $row['r_sem']; ?></td>
	    </tr>
	    <tr>
	      <td>Student ID</td>
	      <td><?php echo $row['u_sno']; ?></td>
	    </tr>
	    <tr>
	      <td>Student Name</td>
	      <td><?php echo $row['u_name']; ?></td>
	    </tr>
	    <tr>
	      <td>Course</td>
	      <td><?php echo $row['c_code']; ?></td>
	    </tr>
	    <tr>
	      <td>Course Name</td>
	      <td><?php echo $row['c_name']; ?></td>
	    </tr>
	    <tr>
	      <td>Approval</td>
	      <td>
				<?php
				?>
		  </td>
	    </tr>	    
	</table>

</div>

<?php include 'footer.php';?>



