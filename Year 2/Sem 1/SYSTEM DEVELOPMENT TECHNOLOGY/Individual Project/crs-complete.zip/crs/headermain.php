<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Registration System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
  :root {
    --primary-blue: #4285f4;      /* Softer Google Blue */
    --secondary-blue: #5c9fff;    /* Light Blue */
    --hover-blue: #1a73e8;        /* Accent Blue */
    --light-blue: #f3f8ff;        /* Very Light Blue Background */
    --white: #ffffff;
  }

  .navbar {
    background: linear-gradient(135deg, var(--primary-blue) 0%, var(--hover-blue) 100%) !important;
    padding: 1rem 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }

  .navbar-brand {
    font-size: 1.4rem;
    font-weight: 600;
    color: var(--white) !important;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .navbar-brand i {
    font-size: 1.5rem;
  }

  .nav-link {
    color: var(--white) !important;
    padding: 0.7rem 1.2rem !important;
    border-radius: 6px;
    transition: all 0.2s ease;
    font-weight: 500;
    opacity: 0.9;
  }

  .nav-link:hover {
    background-color: rgba(255,255,255,0.1);
    opacity: 1;
  }

  .nav-link.active {
    background-color: rgba(255,255,255,0.2);
    opacity: 1;
  }

  .navbar-nav {
    gap: 0.3rem;
  }

  /* Dropdown styling */
  .dropdown-menu {
    background: var(--white);
    border: none;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 8px;
    margin-top: 0.5rem;
  }

  .dropdown-item {
    padding: 0.7rem 1.2rem;
    color: var(--hover-blue);
    transition: all 0.2s ease;
  }

  .dropdown-item:hover {
    background: var(--light-blue);
    color: var(--primary-blue);
  }

  /* Search form styling */
  .d-flex .form-control {
    border: none;
    border-radius: 6px;
    padding: 0.6rem 1rem;
    background: rgba(255,255,255,0.1);
    color: white;
    min-width: 200px;
  }

  .d-flex .form-control::placeholder {
    color: rgba(255,255,255,0.7);
  }

  .d-flex .btn-search {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.6rem 1.2rem;
    border-radius: 6px;
    margin-left: 0.5rem;
    transition: all 0.2s ease;
  }

  .d-flex .btn-search:hover {
    background: rgba(255,255,255,0.25);
  }

  @media (max-width: 991.98px) {
    .navbar-nav {
      padding: 1rem 0;
    }
    .nav-link {
      padding: 0.8rem 1rem !important;
    }
  }
  </style>
</head>

<body>

<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-graduation-cap"></i>
      Course Registration System
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="index.php">
            <i class="fas fa-home me-2"></i>Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="register.php">
            <i class="fas fa-user-plus me-2"></i>Register
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">
            <i class="fas fa-sign-in-alt me-2"></i>Login
          </a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control" type="search" placeholder="Search">
        <button class="btn btn-search" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
