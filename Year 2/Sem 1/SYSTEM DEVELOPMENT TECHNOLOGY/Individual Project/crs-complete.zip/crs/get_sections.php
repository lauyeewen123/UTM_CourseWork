<?php
include 'dbconnect.php';

$course_code = isset($_GET['code']) ? mysqli_real_escape_string($con, $_GET['code']) : '';

// Get course details
$course_query = "SELECT c_section, c_max FROM tb_course WHERE c_code = '$course_code'";
$course_result = mysqli_query($con, $course_query);
$course = mysqli_fetch_assoc($course_result);

// Get current enrollment per section
$section_query = "SELECT r_section, COUNT(*) as enrolled
                 FROM tb_registration 
                 WHERE r_course = '$course_code'
                 AND r_status IN (1,2)
                 GROUP BY r_section";
$section_result = mysqli_query($con, $section_query);

$enrollments = array();
while ($row = mysqli_fetch_assoc($section_result)) {
    $enrollments[$row['r_section']] = $row['enrolled'];
}

// Prepare section data
$sections = array();
for ($i = 1; $i <= $course['c_section']; $i++) {
    $enrolled = isset($enrollments[$i]) ? $enrollments[$i] : 0;
    $sections[] = array(
        'number' => $i,
        'enrolled' => $enrolled,
        'max' => $course['c_max'],
        'available' => $enrolled < $course['c_max']
    );
}

header('Content-Type: application/json');
echo json_encode(['sections' => $sections]); 