<?php
session_start();
include('dbconnect.php');

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

try {
    // Verify staff is logged in and has proper permissions
    if (!isset($_SESSION['logged_in']) || $_SESSION['usertype'] !== 'itstaff') {
        throw new Exception("Unauthorized access");
    }

    if(isset($_POST['process_registration'])) {
        // Sanitize inputs
        $student_id = sanitize_input($_POST['student_id']);
        $course_id = sanitize_input($_POST['course_id']);
        $status = sanitize_input($_POST['status']);
        $remarks = sanitize_input($_POST['remarks']);
        $processed_by = $_SESSION['funame']; // Get from session for security

        // Validate student ID format
        if (!preg_match("/^S[0-9]{3}$/", $student_id)) {
            throw new Exception("Invalid student ID format");
        }

        // Validate course ID exists
        $course_check = "SELECT course_id FROM courses WHERE course_id = ?";
        $check_stmt = mysqli_prepare($con, $course_check);
        mysqli_stmt_bind_param($check_stmt, "s", $course_id);
        mysqli_stmt_execute($check_stmt);
        $course_result = mysqli_stmt_get_result($check_stmt);
        
        if(mysqli_num_rows($course_result) == 0) {
            throw new Exception("Invalid course ID");
        }
        mysqli_stmt_close($check_stmt);

        // Update registration status
        $query = "UPDATE course_registrations 
                 SET status = ?, 
                     remarks = ?,
                     processed_by = ?,
                     processed_date = NOW()
                 WHERE student_id = ? AND course_id = ?";

        $stmt = mysqli_prepare($con, $query);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . mysqli_error($con));
        }

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sssss", 
            $status,
            $remarks,
            $processed_by,
            $student_id,
            $course_id
        );

        // Execute the update
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Update failed: " . mysqli_stmt_error($stmt));
        }

        // Log the action
        $log_query = "INSERT INTO activity_log (user_id, action, details, action_date) 
                      VALUES (?, 'PROCESS_REGISTRATION', ?, NOW())";
        $log_stmt = mysqli_prepare($con, $log_query);
        $log_details = "Processed registration for Student: $student_id, Course: $course_id, Status: $status";
        mysqli_stmt_bind_param($log_stmt, "ss", $processed_by, $log_details);
        mysqli_stmt_execute($log_stmt);

        $_SESSION['success'] = "Registration processed successfully";
        header("Location: staff_dashboard.php");
        exit();

    }
} catch (Exception $e) {
    error_log("Staff processing error: " . $e->getMessage());
    $_SESSION['error'] = $e->getMessage();
    header("Location: staff_dashboard.php");
    exit();
} finally {
    // Clean up
    if (isset($stmt)) {
        mysqli_stmt_close($stmt);
    }
    if (isset($log_stmt)) {
        mysqli_stmt_close($log_stmt);
    }
    if (isset($con)) {
        mysqli_close($con);
    }
}
?> 