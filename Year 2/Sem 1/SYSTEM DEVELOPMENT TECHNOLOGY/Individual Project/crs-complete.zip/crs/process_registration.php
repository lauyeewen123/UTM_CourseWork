<?php
session_start();
require_once 'crssession.php';
require_once 'dbconnect.php';

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if(isset($_POST['submit_all'])) {
    $uic = mysqli_real_escape_string($con, $_SESSION['funame']);
    $update_sql = "UPDATE tb_registration 
                   SET r_status = 2
                   WHERE r_student = '$uic'
                   AND r_status = 1";
    
    if(mysqli_query($con, $update_sql)) {
        $_SESSION['success'] = "All registrations submitted successfully!";
    } else {
        $_SESSION['error'] = "Error updating registrations.";
    }
    header("Location: modifyregistration.php");
    exit();
}

if(isset($_POST['cancel'])) {
    $tid = mysqli_real_escape_string($con, $_POST['cancel']);
    $uic = mysqli_real_escape_string($con, $_SESSION['funame']);
    
    $sql = "DELETE FROM tb_registration 
            WHERE r_tid = '$tid' 
            AND r_student = '$uic' 
            AND r_status = 1";
    
    if(mysqli_query($con, $sql)) {
        $_SESSION['success'] = "Registration cancelled successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($con);
    }
    header("Location: modifyregistration.php");
    exit();
}
?> 