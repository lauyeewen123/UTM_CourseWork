<?php
ob_start();
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get pending registrations
$sql = "SELECT r.*, c.c_name, u.u_name, s.s_desc as status_desc,
        c.c_max, 
        (SELECT COUNT(*) FROM tb_registration 
         WHERE r_course = r.r_course AND r_status = '2') as current_enrolled
        FROM tb_registration r
        JOIN tb_course c ON r.r_course = c.c_code
        JOIN tb_user u ON r.r_student = u.u_sno
        JOIN tb_status s ON r.r_status = s.s_id
        WHERE r.r_status = '1'
        ORDER BY r.r_tid ASC";

$result = mysqli_query($con, $sql);

// Handle status updates
if (isset($_POST['status'])) {
    $r_tid = mysqli_real_escape_string($con, $_POST['r_tid']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    
    // Check course capacity before approving
    if ($status == '2') {
        $check_sql = "SELECT c.c_max, 
                     (SELECT COUNT(*) FROM tb_registration 
                      WHERE r_course = r.r_course AND r_status = '2') as current_enrolled
                     FROM tb_registration r
                     JOIN tb_course c ON r.r_course = c.c_code
                     WHERE r.r_tid = '$r_tid'";
        $check_result = mysqli_query($con, $check_sql);
        $check_data = mysqli_fetch_assoc($check_result);
        
        if ($check_data['current_enrolled'] >= $check_data['c_max']) {
            $_SESSION['error'] = "Cannot approve: Course has reached maximum capacity";
            header("Location: staff_pending_registrations.php");
            exit();
        }
    }
    
    $update_sql = "UPDATE tb_registration SET r_status = '$status' WHERE r_tid = '$r_tid'";
    if (mysqli_query($con, $update_sql)) {
        $_SESSION['success'] = "Registration status updated successfully";
        header("Location: staff_pending_registrations.php");
        exit();
    } else {
        $_SESSION['error'] = "Error updating status: " . mysqli_error($con);
    }
}
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <h4 class="mb-0">Pending Approvals</h4>
            </div>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover" id="pendingTable">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Course Capacity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                                    <td>
                                        <?php echo $row['current_enrolled']; ?>/<?php echo $row['c_max']; ?>
                                        <?php if ($row['current_enrolled'] >= $row['c_max']): ?>
                                            <span class="badge bg-danger">Full</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form method="POST" class="d-inline" onsubmit="return confirmAction(this)">
                                            <input type="hidden" name="r_tid" value="<?php echo $row['r_tid']; ?>">
                                            <input type="hidden" name="update_status" value="1">
                                            <button type="submit" name="status" value="2" class="btn btn-success btn-sm" data-action="approve">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button type="submit" name="status" value="3" class="btn btn-danger btn-sm" data-action="reject">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">No pending registrations found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
function confirmAction(form) {
    const button = form.querySelector('button[type="submit"]:focus');
    const action = button.getAttribute('data-action');
    const studentName = form.closest('tr').cells[0].textContent;
    const courseName = form.closest('tr').cells[1].textContent;
    const capacity = form.closest('tr').cells[2].textContent;
    
    let message = `Are you sure you want to ${action} this registration?\n\n` +
                 `Student: ${studentName}\n` +
                 `Course: ${courseName}\n` +
                 `Current Capacity: ${capacity}\n\n`;
    
    if (action === 'approve') {
        message += 'Click OK to approve this registration.';
    } else {
        message += 'Click OK to reject this registration.';
    }
    
    return confirm(message);
}

$(document).ready(function() {
    $('#pendingTable').DataTable({
        "pageLength": 25
    });
});
</script>

<?php include 'footer.php'; ?>
<?php ob_end_flush(); ?> 