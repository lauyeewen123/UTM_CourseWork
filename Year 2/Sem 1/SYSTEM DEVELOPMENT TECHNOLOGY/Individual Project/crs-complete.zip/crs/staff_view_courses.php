<?php
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get all courses with lecturer names and enrollment counts
$sql = "SELECT c.*, u.u_name as lecturer_name,
        (SELECT COUNT(*) FROM tb_registration r 
         WHERE r.r_course = c.c_code AND r.r_status = '2') as enrolled_students
        FROM tb_course c
        LEFT JOIN tb_user u ON c.c_lec = u.u_sno
        ORDER BY c.c_code";
$result = mysqli_query($con, $sql);
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff_course_management.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back to Course Management
                </a>
                <h4 class="mb-0">All Courses</h4>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="coursesTable">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credit Hours</th>
                            <th>Lecturer</th>
                            <th>Enrollment</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['c_code']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['c_credit']); ?></td>
                                <td><?php echo htmlspecialchars($row['lecturer_name']); ?></td>
                                <td>
                                    <?php echo $row['enrolled_students']; ?>/<?php echo $row['c_max']; ?>
                                    <?php if ($row['enrolled_students'] >= $row['c_max']): ?>
                                        <span class="badge bg-danger">Full</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['enrolled_students'] >= $row['c_max']): ?>
                                        <span class="badge bg-danger">Full</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Available</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#coursesTable').DataTable({
        "pageLength": 25
    });
});
</script>

<?php include 'footer.php'; ?> 