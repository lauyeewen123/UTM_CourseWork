<?php
session_start();
include 'headermain.php';
require_once 'includes/email_helper.php';  // Make sure this is included

// Add this temporarily at the top of register.php
error_log("POST data: " . print_r($_POST, true));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Print all POST data
    error_log("POST Data: " . print_r($_POST, true));
    
    // After successful registration query
    if ($stmt->execute()) {
        // Get form values and log them
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $usertype = isset($_POST['usertype']) ? $_POST['usertype'] : '';
        
        error_log("Email: $email");
        error_log("Name: $name");
        error_log("User Type: $usertype");
        
        if (empty($email) || empty($name) || empty($usertype)) {
            error_log("Missing required fields for email sending");
            $_SESSION['success_msg'] = "Account created but missing data for email.";
            header("Location: success.php");
            exit();
        }
        
        // Try to send email
        try {
            $emailSent = sendWelcomeEmail($email, $name, $usertype);
            
            if ($emailSent) {
                $_SESSION['success_msg'] = "Account created successfully and welcome email sent!";
            } else {
                $_SESSION['success_msg'] = "Account created successfully but email could not be sent.";
                error_log("Email sending failed for user: $email");
            }
        } catch (Exception $e) {
            error_log("Exception while sending email: " . $e->getMessage());
            $_SESSION['success_msg'] = "Account created but email sending failed.";
        }
        
        header("Location: success.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Course Registration System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        .register-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 2.5rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }
        .form-floating {
            margin-bottom: 1.2rem;
        }
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.15);
        }
        .password-requirements {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 1.2rem;
            margin: 1.5rem 0;
        }
        .requirements-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .requirements-list li {
            margin-bottom: 0.8rem;
            color: #6c757d;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            transition: all 0.3s ease;
            opacity: 0.7;
        }
        .requirements-list li i {
            min-width: 20px;
            transition: all 0.3s ease;
        }
        .requirements-list li.valid {
            color: #198754;
            opacity: 1;
        }
        .requirements-list li.valid i {
            transform: scale(1.2);
        }
        .requirements-list li i.fa-check {
            color: #198754;
        }
        .requirements-list li i.fa-times {
            color: #dc3545;
        }
        .password-strength {
            height: 4px;
            background: #e9ecef;
            margin-top: 0.5rem;
            border-radius: 2px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            width: 0;
            transition: all 0.3s ease;
            border-radius: 2px;
        }
        .strength-weak { width: 33%; background: #dc3545; }
        .strength-medium { width: 66%; background: #ffc107; }
        .strength-strong { width: 100%; background: #198754; }
        .password-toggle {
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .password-toggle:hover {
            transform: scale(1.1);
        }
        .password-toggle.active {
            color: #0d6efd;
        }
        .btn-register {
            padding: 0.8rem 2rem;
            font-weight: 500;
            font-size: 1.1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            background: linear-gradient(45deg, #0d6efd, #0b5ed7);
            border: none;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3);
        }
        .section-title {
            color: #0d6efd;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
            font-weight: 600;
        }
        .form-section {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            border: 2px solid #e9ecef;
        }
        .login-link {
            color: #0d6efd;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .login-link:hover {
            color: #0b5ed7;
            text-decoration: underline;
        }
        #id-helper-text {
            margin-top: 0.25rem;
            transition: color 0.3s ease;
        }
        
        .form-floating .form-control:focus ~ #id-helper-text {
            opacity: 1;
        }
        
        .form-control.is-valid ~ #id-helper-text {
            color: #198754 !important;
        }
        
        .form-control.is-invalid ~ #id-helper-text {
            color: #dc3545 !important;
        }
        
        .form-floating .form-control {
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
    </style>
</head>
<body>

<div class="container py-4">
    <div class="register-container">
        <h2 class="text-center mb-4">Create Your Account</h2>
        <p class="text-center text-muted mb-4">Join our community and start your learning journey today</p>

        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <form action="registerprocess.php" method="POST" id="registerForm" onsubmit="return validateForm()">
            <div class="form-section">
                <div class="section-title">Account Information</div>
                <div class="form-floating">
                    <input type="text" class="form-control" id="sno" name="funame" placeholder="Student/Staff Number" required>
                    <label for="sno"><i class="fas fa-id-card me-2"></i>Student/Staff Number (S001/L001/IT001)</label>
                </div>
            </div>

            <div class="form-section">
                <div class="section-title">Personal Information</div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
                            <label for="name"><i class="fas fa-user me-2"></i>Full Name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="email" class="form-control" id="email" name="femail" placeholder="Email" required>
                            <label for="email"><i class="fas fa-envelope me-2"></i>Email</label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="tel" class="form-control" id="contact" name="contact" placeholder="Contact Number" required>
                            <label for="contact"><i class="fas fa-phone me-2"></i>Contact Number</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <label for="gender"><i class="fas fa-venus-mars me-2"></i>Gender</label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="date" class="form-control" id="dob" name="dob" required>
                            <label for="dob"><i class="fas fa-calendar me-2"></i>Date of Birth</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" id="state" name="state" required>
                                <option value="">Select State</option>
                                <option>Johor</option>
                                <option>Kedah</option>
                                <option>Kelantan</option>
                                <option>Melaka</option>
                                <option>Negeri Sembilan</option>
                                <option>Pahang</option>
                                <option>Perak</option>
                                <option>Perlis</option>
                                <option>Pulau Pinang</option>
                                <option>Sabah</option>
                                <option>Sarawak</option>
                                <option>Selangor</option>
                                <option>Terengganu</option>
                                <option>W.P Kuala Lumpur</option>
                                <option>W.P Labuan</option>
                                <option>W.P Putrajaya</option>
                            </select>
                            <label for="state"><i class="fas fa-map-marker-alt me-2"></i>State</label>
                        </div>
                    </div>
                </div>

                <div class="form-floating">
                    <textarea class="form-control" id="address" name="address" placeholder="Address" style="height: 100px" required></textarea>
                    <label for="address"><i class="fas fa-home me-2"></i>Address</label>
                </div>
            </div>

            <div class="form-section">
                <div class="section-title">Security</div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating position-relative">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            <label for="password"><i class="fas fa-lock me-2"></i>Password</label>
                            <i class="fas fa-eye password-toggle" onclick="togglePassword('password')"></i>
                            <div class="password-strength">
                                <div class="password-strength-bar"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating position-relative">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                            <label for="confirm_password"><i class="fas fa-lock me-2"></i>Confirm Password</label>
                            <i class="fas fa-eye password-toggle" onclick="togglePassword('confirm_password')"></i>
                        </div>
                    </div>
                </div>

                <div class="password-requirements mt-3">
                    <h6><i class="fas fa-shield-alt me-2"></i>Password Requirements:</h6>
                    <ul class="requirements-list">
                        <li id="length"><i class="fas fa-times"></i>At least 8 characters long</li>
                        <li id="uppercase"><i class="fas fa-times"></i>Contains at least one uppercase letter</li>
                        <li id="lowercase"><i class="fas fa-times"></i>Contains at least one lowercase letter</li>
                        <li id="number"><i class="fas fa-times"></i>Contains at least one number</li>
                        <li id="special"><i class="fas fa-times"></i>Contains at least one special character</li>
                    </ul>
                </div>
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-register">Create Account</button>
                <p class="text-center mt-3">Already have an account? <a href="login.php" class="login-link">Login here</a></p>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
document.getElementById('password').addEventListener('input', function() {
    const password = this.value;
    validatePassword(password);
    updatePasswordStrength(password);
});

function validatePassword(password) {
    const requirements = {
        length: { regex: /.{8,}/, element: document.getElementById('length') },
        uppercase: { regex: /[A-Z]/, element: document.getElementById('uppercase') },
        lowercase: { regex: /[a-z]/, element: document.getElementById('lowercase') },
        number: { regex: /[0-9]/, element: document.getElementById('number') },
        special: { regex: /[!@#$%^&*(),.?":{}|<>]/, element: document.getElementById('special') }
    };

    Object.keys(requirements).forEach(req => {
        const { regex, element } = requirements[req];
        const isValid = regex.test(password);
        
        if (isValid) {
            element.classList.add('valid');
            element.querySelector('i').className = 'fas fa-check';
        } else {
            element.classList.remove('valid');
            element.querySelector('i').className = 'fas fa-times';
        }
    });
}

function updatePasswordStrength(password) {
    const strengthBar = document.querySelector('.password-strength-bar');
    let strength = 0;
    
    // Calculate password strength
    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;
    
    // Update strength bar
    strengthBar.className = 'password-strength-bar';
    if (strength >= 4) {
        strengthBar.classList.add('strength-strong');
    } else if (strength >= 2) {
        strengthBar.classList.add('strength-medium');
    } else if (strength >= 1) {
        strengthBar.classList.add('strength-weak');
    }
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling.nextElementSibling;
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
        icon.classList.add('active');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
        icon.classList.remove('active');
    }
    
    // Add click animation
    icon.style.transform = 'scale(0.8)';
    setTimeout(() => {
        icon.style.transform = 'scale(1)';
    }, 100);
}

function validateForm() {
    const sno = document.getElementById('sno').value.toUpperCase();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    
    // First validate the format
    const validFormat = /^(IT|[SL])\d{3}$/.test(sno);
    if (!validFormat) {
        alert('Please enter a valid ID format:\nS001-S999 for Students\nL001-L999 for Lecturers\nIT001-IT999 for IT Staff');
        return false;
    }

    // Determine user type for confirmation message
    let userType = '';
    if (sno.startsWith('S')) userType = 'Student';
    else if (sno.startsWith('L')) userType = 'Lecturer';
    else if (sno.startsWith('IT')) userType = 'IT Staff';

    // Create confirmation message
    const confirmMessage = `Please confirm your registration details:\n\n` +
        `ID: ${sno}\n` +
        `Type: ${userType}\n` +
        `Name: ${name}\n` +
        `Email: ${email}\n\n` +
        `Are you sure you want to create this account?`;

    // Show confirmation dialog
    return confirm(confirmMessage);
}

// Update the form to use this validation
document.getElementById('registerForm').onsubmit = function(e) {
    if (!validateForm()) {
        e.preventDefault(); // Prevent form submission if user cancels
        return false;
    }
    return true;
};

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        });
    }, 5000);
});

// Add this function to format the ID with leading zeros
function formatID(input) {
    // Allow typing by returning the raw input if it's not complete
    if (input.length < 2) return input;

    let prefix = '';
    let numbers = '';
    
    // Extract prefix and numbers
    if (input.startsWith('IT')) {
        prefix = 'IT';
        numbers = input.slice(2);
    } else if (input.startsWith('S') || input.startsWith('L')) {
        prefix = input.charAt(0);
        numbers = input.slice(1);
    }
    
    // Allow typing numbers freely
    numbers = numbers.replace(/[^0-9]/g, '');
    
    // Only format with leading zeros if we have a complete number
    if (numbers.length === 3) {
        // Prevent 000
        if (numbers === '000') {
            return input; // Keep the original input to show error
        }
        return prefix + numbers;
    }
    
    // Return the current input while typing
    return prefix + numbers;
}

// Update the input event listener
document.getElementById('sno').addEventListener('input', function() {
    let input = this.value.toUpperCase();
    const helperText = document.getElementById('id-helper-text') || createHelperText(this);
    
    // Allow free typing but limit length
    if (input.startsWith('IT')) {
        input = input.slice(0, 5); // IT + 3 digits
    } else {
        input = input.slice(0, 4); // S/L + 3 digits
    }
    
    // Basic format check
    const hasValidPrefix = /^(IT|[SL])/.test(input);
    const hasValidFormat = /^(IT|[SL])\d{0,3}$/.test(input);
    const isComplete = /^(IT|[SL])\d{3}$/.test(input);
    const isZero = isComplete && (input.endsWith('000'));
    
    // Update the input value
    this.value = input;
    
    // Update helper text and validation state
    updateHelperText(helperText, input, hasValidPrefix, isComplete, isZero);
    updateValidationState(this, hasValidFormat, isComplete, isZero);
});

function createHelperText(inputElement) {
    const helper = document.createElement('div');
    helper.id = 'id-helper-text';
    helper.className = 'form-text small';
    inputElement.parentNode.appendChild(helper);
    return helper;
}

function updateHelperText(helperText, input, hasValidPrefix, isComplete, isZero) {
    if (isZero) {
        helperText.innerHTML = '<i class="fas fa-exclamation-circle"></i> ID number cannot be 000';
        helperText.style.color = '#dc3545';
        return;
    }

    if (!hasValidPrefix) {
        helperText.innerHTML = '<i class="fas fa-info-circle"></i> Please start with S (Student), L (Lecturer), or IT (IT Staff)';
        helperText.style.color = '#6c757d';
        return;
    }

    if (input.startsWith('S')) {
        helperText.innerHTML = '<i class="fas fa-info-circle"></i> Student ID format: S001 to S999';
    } else if (input.startsWith('L')) {
        helperText.innerHTML = '<i class="fas fa-info-circle"></i> Lecturer ID format: L001 to L999';
    } else if (input.startsWith('IT')) {
        helperText.innerHTML = '<i class="fas fa-info-circle"></i> IT Staff ID format: IT001 to IT999';
    }

    helperText.style.color = isComplete ? '#198754' : '#0d6efd';
}

function updateValidationState(inputElement, hasValidFormat, isComplete, isZero) {
    if (!hasValidFormat || isZero) {
        inputElement.classList.remove('is-valid');
        inputElement.classList.add('is-invalid');
    } else if (isComplete) {
        inputElement.classList.remove('is-invalid');
        inputElement.classList.add('is-valid');
    } else {
        // While typing, remove both classes
        inputElement.classList.remove('is-valid', 'is-invalid');
    }
}

// Add this CSS to your existing styles
document.head.insertAdjacentHTML('beforeend', `
<style>
    #id-helper-text {
        margin-top: 0.25rem;
        transition: color 0.3s ease;
    }
    
    .form-floating .form-control:focus ~ #id-helper-text {
        opacity: 1;
    }
    
    .form-control.is-valid ~ #id-helper-text {
        color: #198754 !important;
    }
    
    .form-control.is-invalid ~ #id-helper-text {
        color: #dc3545 !important;
    }
    
    .form-floating .form-control {
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
</style>
`);

// Add this at the bottom of your existing JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check for success message
    <?php if(isset($_SESSION['success_msg'])): ?>
        Swal.fire({
            title: 'Success!',
            text: '<?php echo $_SESSION['success_msg']; ?>',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'login.php'; // Redirect to login page
            }
        });
        <?php unset($_SESSION['success_msg']); // Clear the message ?>
    <?php endif; ?>

    // Check for error message
    <?php if(isset($_SESSION['error'])): ?>
        Swal.fire({
            title: 'Error!',
            text: '<?php echo $_SESSION['error']; ?>',
            icon: 'error',
            confirmButtonText: 'OK'
        });
        <?php unset($_SESSION['error']); // Clear the message ?>
    <?php endif; ?>
});
</script>

</body>
</html>



