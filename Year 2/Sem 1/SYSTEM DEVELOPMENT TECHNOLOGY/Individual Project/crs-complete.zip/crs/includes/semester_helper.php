<?php
function getCurrentSemester($con) {
    $query = "SELECT s_code FROM tb_semester WHERE s_status = 'active' LIMIT 1";
    $result = mysqli_query($con, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['s_code']; // This should return "2024/2025-1"
    }
    
    // Debug
    error_log("getCurrentSemester query: " . $query);
    error_log("getCurrentSemester result: " . print_r($result, true));
    
    return "2024/2025-1"; // Fallback default value
}

function formatSemesterName($semester) {
    return $semester['s_name'] . " (" . $semester['s_code'] . ")";
}
?> 