<?php
// Remove the use statements from here
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;

// Fix the paths - assuming phpmailer folder is in your project root
require_once __DIR__ . '/../phpmailer/src/Exception.php';
require_once __DIR__ . '/../phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../phpmailer/src/SMTP.php';

function sendWelcomeEmail($userEmail, $userName, $userType) {
    // Add debug logging
    error_log("Starting email send process to: $userEmail");
    
    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'lauyeewen@graduate.utm.my';
        // Put your new app password here
        $mail->Password = 'penq njiw pogk kezt';
        
        // Try with TLS instead of SSL
        $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;  // Changed port for TLS

        // For debugging
        $mail->SMTPDebug = 3;  // Increased debug level
        $mail->Debugoutput = 'error_log';

        // Recipients
        $mail->setFrom('lauyeewen@graduate.utm.my', 'Course Registration System');
        $mail->addAddress($userEmail);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to Course Registration System';
        
        // Email body with better styling
        $mail->Body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
            <h2 style='color: #1a73e8; text-align: center;'>Welcome to Course Registration System!</h2>
            
            <div style='background-color: #f8f9fa; padding: 20px; border-radius: 5px;'>
                <p>Hi <strong>$userName</strong>,</p>
                <p>Your account has been successfully created as a <strong>$userType</strong>.</p>
                
                <div style='margin: 20px 0;'>
                    <p><strong>Account Details:</strong></p>
                    <ul>
                        <li>User Type: $userType</li>
                        <li>Email: $userEmail</li>
                    </ul>
                </div>
                
                <p>You can now login to the system using your credentials.</p>
                
                <div style='margin: 20px 0; padding: 15px; background-color: #e8f0fe; border-radius: 5px;'>
                    <p style='margin: 0;'><strong>Next Steps:</strong></p>
                    <ul>
                        <li>Login to your account</li>
                        <li>Complete your profile</li>
                        <li>Start exploring the system</li>
                    </ul>
                </div>
            </div>
            
            <div style='margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;'>
                <p>Best regards,</p>
                <p><strong>Course Registration System Team</strong></p>
            </div>
            
            <div style='margin-top: 20px; font-size: 12px; color: #666; text-align: center;'>
                <p>This is an automated message, please do not reply to this email.</p>
            </div>
        </div>";

        $mail->send();
        error_log("Email sent successfully to: $userEmail");
        return true;
    } catch (\Exception $e) {
        error_log("Email sending failed. Error: " . $e->getMessage());
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
} 