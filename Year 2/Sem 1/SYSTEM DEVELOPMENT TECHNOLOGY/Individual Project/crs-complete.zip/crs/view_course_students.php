<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';
include 'includes/semester_helper.php';

$lecturer_id = $_SESSION['funame'];
$course_code = isset($_GET['code']) ? mysqli_real_escape_string($con, $_GET['code']) : '';
$current_semester = getCurrentSemester($con);

// Debug
error_log("Checking access - Lecturer: $lecturer_id, Course: $course_code, Semester: $current_semester");

// Verify course exists and belongs to lecturer using course_assignment
$course_sql = "SELECT c.*, ca.ca_semester 
               FROM tb_course c 
               INNER JOIN tb_course_assignment ca ON c.c_code = ca.ca_course
               WHERE c.c_code = ? 
               AND ca.ca_lecturer = ?
               AND ca.ca_semester = ?
               AND ca.ca_status = 'active'";

if ($stmt = mysqli_prepare($con, $course_sql)) {
    mysqli_stmt_bind_param($stmt, "sss", $course_code, $lecturer_id, $current_semester);
    mysqli_stmt_execute($stmt);
    $course_result = mysqli_stmt_get_result($stmt);
    
    // Debug
    error_log("Rows found: " . mysqli_num_rows($course_result));
} else {
    die("Query failed: " . mysqli_error($con));
}

if (!$course_result || mysqli_num_rows($course_result) == 0) {
    echo '<div class="alert alert-danger m-3">Course not found or access denied.</div>';
    include 'footer.php';
    exit();
}

$course = mysqli_fetch_assoc($course_result);

// Get student registrations for this course
$students_sql = "SELECT r.*, u.u_name, u.u_email, u.u_contact,
                 (SELECT COUNT(*) FROM tb_registration 
                  WHERE r_student = r.r_student 
                  AND r_sem = r.r_sem) as total_courses
                FROM tb_registration r
                JOIN tb_user u ON r.r_student = u.u_sno
                WHERE r.r_course = ?
                AND r.r_sem = ?
                ORDER BY r.r_section, u.u_name";

if ($stmt = mysqli_prepare($con, $students_sql)) {
    mysqli_stmt_bind_param($stmt, "ss", $course_code, $current_semester);
    mysqli_stmt_execute($stmt);
    $students_result = mysqli_stmt_get_result($stmt);
} else {
    die("Query failed: " . mysqli_error($con));
}

// Get registration statistics
$stats_sql = "SELECT 
    COUNT(*) as total,
    COUNT(CASE WHEN r_status = '1' THEN 1 END) as pending,
    COUNT(CASE WHEN r_status = '2' THEN 1 END) as approved,
    COUNT(CASE WHEN r_status = '3' THEN 1 END) as rejected
    FROM tb_registration 
    WHERE r_course = ? 
    AND r_sem = ?";

if ($stmt = mysqli_prepare($con, $stats_sql)) {
    mysqli_stmt_bind_param($stmt, "ss", $course_code, $current_semester);
    mysqli_stmt_execute($stmt);
    $stats_result = mysqli_stmt_get_result($stmt);
    $stats = mysqli_fetch_assoc($stats_result);
} else {
    die("Query failed: " . mysqli_error($con));
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="view_student_list.php">Course Overview</a></li>
            <li class="breadcrumb-item active"><?php echo htmlspecialchars($course['c_code']); ?></li>
        </ol>
    </nav>

    <!-- Course Header -->
    <div class="row mb-4">
        <div class="col">
            <h2><?php echo htmlspecialchars($course['c_code']); ?> - <?php echo htmlspecialchars($course['c_name']); ?></h2>
            <p class="text-muted">Semester: <?php echo htmlspecialchars($current_semester); ?></p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h6 class="card-title">Total Students</h6>
                    <h2 class="mb-0"><?php echo $stats['total']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h6 class="card-title">Approved</h6>
                    <h2 class="mb-0"><?php echo $stats['approved']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6 class="card-title">Pending</h6>
                    <h2 class="mb-0"><?php echo $stats['pending']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6 class="card-title">Rejected</h6>
                    <h2 class="mb-0"><?php echo $stats['rejected']; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Students Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Registered Students</h5>
        </div>
        <div class="card-body">
            <?php if (mysqli_num_rows($students_result) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Section</th>
                                <th>Status</th>
                                <th>Total Courses</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($student = mysqli_fetch_assoc($students_result)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['r_student']); ?></td>
                                    <td><?php echo htmlspecialchars($student['u_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['r_section']); ?></td>
                                    <td>
                                        <?php
                                        switch($student['r_status']) {
                                            case '1':
                                                echo '<span class="badge bg-warning">Pending</span>';
                                                break;
                                            case '2':
                                                echo '<span class="badge bg-success">Approved</span>';
                                                break;
                                            case '3':
                                                echo '<span class="badge bg-danger">Rejected</span>';
                                                break;
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($student['total_courses']); ?></td>
                                    <td>
                                        <a href="view_student_details.php?id=<?php echo urlencode($student['r_student']); ?>" 
                                           class="btn btn-primary btn-sm">
                                            <i class="fas fa-user me-1"></i> View Details
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <p class="mb-0">No students registered for this course.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

.table th {
    font-weight: 600;
    color: #2c3e50;
}

.badge {
    padding: 0.5em 0.8em;
}

.btn-sm {
    padding: 0.4rem 0.8rem;
}
</style>

<?php include 'footer.php'; ?> 