<?php
session_start();
//Connect to DB
include('dbconnect.php');

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

require_once 'includes/email_helper.php';

// Debug: Print all POST data
error_log("POST data: " . print_r($_POST, true));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Sanitize all inputs
        $username = strtoupper(mysqli_real_escape_string($con, $_POST['funame']));
        $password = $_POST['password'];
        $email = filter_var(mysqli_real_escape_string($con, $_POST['femail']), FILTER_SANITIZE_EMAIL);
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $contact = mysqli_real_escape_string($con, $_POST['contact']);
        $address = mysqli_real_escape_string($con, $_POST['address']);
        $dob = mysqli_real_escape_string($con, $_POST['dob']);
        $gender = mysqli_real_escape_string($con, $_POST['gender']);
        $state = mysqli_real_escape_string($con, $_POST['state']);

        // Validate username format - Update this validation
        if (!preg_match("/^(IT|[SL])\d{3}$/", $username)) {
            // Check if it's a valid number but just needs formatting
            if (preg_match("/^(IT|[SL])(\d{1,3})$/", $username, $matches)) {
                // Pad the number with zeros
                $prefix = $matches[1];
                $number = str_pad($matches[2], 3, '0', STR_PAD_LEFT);
                $username = $prefix . $number;
            } else {
                throw new Exception("Invalid ID format. Please use:\nS001-S999 for Students\nL001-L999 for Lecturers\nIT001-IT999 for IT Staff");
            }
        }

        // Determine user type from ID prefix - Fix this section
        $prefix = substr($username, 0, 1); // Changed from using strpos($username, '0')
        if (substr($username, 0, 2) === 'IT') {
            $prefix = 'IT';
        }

        switch($prefix) {
            case 'S':
                $utype = 2; // Student in tb_utype
                break;
            case 'L':
                $utype = 1; // Lecturer in tb_utype
                break;
            case 'IT':
                $utype = 3; // IT Staff in tb_utype
                break;
            default:
                throw new Exception("Invalid ID format");
        }

        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Current timestamp for u_req
        $currentTimestamp = date('Y-m-d H:i:s');

        // Use prepared statement
        $query = "INSERT INTO tb_user (u_sno, u_pwd, u_email, u_name, u_contact, u_address, 
                  u_dob, u_gender, u_state, u_utype, u_req) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($con, $query);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . mysqli_error($con));
        }

        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sssssssssss", 
            $username,        // u_sno VARCHAR(10)
            $hashedPassword,  // u_pwd VARCHAR(255)
            $email,          // u_email VARCHAR(30)
            $name,           // u_name VARCHAR(50)
            $contact,        // u_contact INT(11)
            $address,        // u_address VARCHAR(255)
            $dob,           // u_dob DATE
            $gender,        // u_gender ENUM('Male','Female')
            $state,         // u_state VARCHAR(20)
            $utype,         // u_utype INT(11)
            $currentTimestamp // u_req TIMESTAMP
        );

        // Execute the statement
        if (!mysqli_stmt_execute($stmt)) {
            throw new Exception("Registration failed: " . mysqli_stmt_error($stmt));
        }

        // Get form values
        $email = $_POST['femail'];
        $name = $_POST['name'];

        // Determine user type based on ID prefix for email
        if (substr($username, 0, 2) === 'IT') {
            $usertype = 'IT Staff';
        } else if (substr($username, 0, 1) === 'L') {
            $usertype = 'Lecturer';
        } else {
            $usertype = 'Student';
        }

        try {
            $emailSent = sendWelcomeEmail($email, $name, $usertype);
            
            if ($emailSent) {
                $message = "Account created successfully and welcome email sent!";
            } else {
                $message = "Account created successfully but email could not be sent.";
                error_log("Email sending failed for user: $email");
            }
        } catch (Exception $e) {
            error_log("Exception while sending email: " . $e->getMessage());
            $message = "Account created but email sending failed.";
        }
        
        // Beautiful popup with SweetAlert2
        echo "
        <html>
        <head>
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        </head>
        <body>
            <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '$message',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'login.php';
                }
            });
            </script>
        </body>
        </html>";
        exit();

    } catch (Exception $e) {
        // Log the error securely
        error_log("Registration error: " . $e->getMessage());
        
        // Redirect with appropriate error message
        $_SESSION['error'] = $e->getMessage();
        header("Location: register.php");
        exit();
        
    } finally {
        // Clean up
        if (isset($stmt)) {
            mysqli_stmt_close($stmt);
        }
        if (isset($con)) {
            mysqli_close($con);
        }
    }
}
?>