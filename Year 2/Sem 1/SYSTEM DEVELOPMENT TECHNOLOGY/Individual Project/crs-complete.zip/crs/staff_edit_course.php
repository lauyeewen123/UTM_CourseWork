<?php 
ob_start();
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headerit.php';
include 'dbconnect.php';

// Get course code from URL
$course_code = isset($_GET['code']) ? mysqli_real_escape_string($con, $_GET['code']) : '';

// If no course code provided, redirect to courses page
if (empty($course_code)) {
    $_SESSION['error'] = "No course selected for editing";
    header("Location: staff.php");
    exit();
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $c_name = mysqli_real_escape_string($con, $_POST['c_name']);
    $c_credit = mysqli_real_escape_string($con, $_POST['c_credit']);
    $c_max = mysqli_real_escape_string($con, $_POST['c_max']);
    $c_lec = mysqli_real_escape_string($con, $_POST['c_lec']);

    // Validate inputs
    $errors = array();
    
    if (empty($c_name)) $errors[] = "Course name is required";
    if (empty($c_credit)) $errors[] = "Credit hours are required";
    if (empty($c_max)) $errors[] = "Maximum students is required";
    if (empty($c_lec)) $errors[] = "Lecturer is required";

    // Check if new max students is less than current enrolled
    $check_sql = "SELECT COUNT(*) as enrolled 
                  FROM tb_registration 
                  WHERE r_course = '$course_code' 
                  AND r_status = '2'";
    $check_result = mysqli_query($con, $check_sql);
    $enrolled = mysqli_fetch_assoc($check_result)['enrolled'];

    if ($c_max < $enrolled) {
        $errors[] = "Maximum students cannot be less than current enrolled students ($enrolled)";
    }

    if (empty($errors)) {
        $sql = "UPDATE tb_course 
                SET c_name = '$c_name', 
                    c_credit = '$c_credit', 
                    c_max = '$c_max', 
                    c_lec = '$c_lec' 
                WHERE c_code = '$course_code'";
        
        if (mysqli_query($con, $sql)) {
            $_SESSION['success'] = "Course updated successfully";
            header("Location: staff.php");
            exit();
        } else {
            $errors[] = "Error: " . mysqli_error($con);
        }
    }
}

// Get current course details
$sql = "SELECT * FROM tb_course WHERE c_code = '$course_code'";
$result = mysqli_query($con, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Course not found";
    header("Location: staff.php");
    exit();
}

$course = mysqli_fetch_assoc($result);

// Get list of lecturers for dropdown - Updated query
$sql_lecturers = "SELECT u_sno, u_name FROM tb_user WHERE u_utype = '1' ORDER BY u_name";
$result_lecturers = mysqli_query($con, $sql_lecturers);

if (!$result_lecturers) {
    die("Error fetching lecturers: " . mysqli_error($con));
}

// Get current enrollment count
$sql_enrolled = "SELECT COUNT(*) as enrolled 
                 FROM tb_registration 
                 WHERE r_course = '$course_code' 
                 AND r_status = '2'";
$result_enrolled = mysqli_query($con, $sql_enrolled);
$enrolled_count = mysqli_fetch_assoc($result_enrolled)['enrolled'];
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Edit Course: <?php echo htmlspecialchars($course_code); ?></h4>
                    <span class="badge bg-info">Current Enrollment: <?php echo $enrolled_count; ?></span>
                </div>
                <div class="card-body">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" onsubmit="return confirmUpdate()">
                        <div class="mb-3">
                            <label class="form-label">Course Code</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($course_code); ?>" 
                                   readonly disabled>
                        </div>

                        <div class="mb-3">
                            <label for="c_name" class="form-label">Course Name</label>
                            <input type="text" class="form-control" id="c_name" name="c_name"
                                   value="<?php echo htmlspecialchars($course['c_name']); ?>"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label for="c_credit" class="form-label">Credit Hours</label>
                            <input type="number" class="form-control" id="c_credit" name="c_credit"
                                   value="<?php echo htmlspecialchars($course['c_credit']); ?>"
                                   min="1" max="4" required>
                        </div>

                        <div class="mb-3">
                            <label for="c_max" class="form-label">Maximum Students</label>
                            <input type="number" class="form-control" id="c_max" name="c_max"
                                   value="<?php echo htmlspecialchars($course['c_max']); ?>"
                                   min="<?php echo $enrolled_count; ?>" max="100" required>
                            <small class="text-muted">Minimum value is current enrollment (<?php echo $enrolled_count; ?>)</small>
                        </div>

                        <div class="mb-3">
                            <label for="c_lec" class="form-label">Lecturer</label>
                            <select class="form-select" id="c_lec" name="c_lec" required>
                                <option value="">Select Lecturer</option>
                                <?php 
                                // Reset result pointer
                                mysqli_data_seek($result_lecturers, 0);
                                
                                while ($lecturer = mysqli_fetch_assoc($result_lecturers)): 
                                ?>
                                    <option value="<?php echo htmlspecialchars($lecturer['u_sno']); ?>"
                                            <?php echo ($course['c_lec'] == $lecturer['u_sno']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($lecturer['u_name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <?php if (mysqli_num_rows($result_lecturers) == 0): ?>
                                <div class="text-danger mt-2">
                                    No lecturers found in the system. Please add lecturers first.
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Update Course</button>
                            <a href="staff.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function confirmUpdate() {
    // Get the course details
    const courseName = document.getElementById('c_name').value;
    const creditHours = document.getElementById('c_credit').value;
    const maxStudents = document.getElementById('c_max').value;
    const lecturer = document.getElementById('c_lec');
    const lecturerName = lecturer.options[lecturer.selectedIndex].text;
    
    // Create confirmation message
    const message = `Are you sure you want to update this course?\n\n` +
                   `Course Code: <?php echo htmlspecialchars($course_code); ?>\n` +
                   `Course Name: ${courseName}\n` +
                   `Credit Hours: ${creditHours}\n` +
                   `Maximum Students: ${maxStudents}\n` +
                   `Lecturer: ${lecturerName}\n\n` +
                   `Click OK to confirm the update.`;
    
    return confirm(message);
}
</script>

<?php 
include 'footer.php';
ob_end_flush();
?> 