<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'dbconnect.php';

// Get course code from URL
$course_code = isset($_GET['code']) ? mysqli_real_escape_string($con, $_GET['code']) : '';

// If no course code provided, redirect to courses page
if (empty($course_code)) {
    $_SESSION['error'] = "No course selected for deletion";
    header("Location: staff.php");
    exit();
}

// Check if course exists and get enrollment info
$sql = "SELECT c.*, 
        COUNT(CASE WHEN r.r_status = '2' THEN 1 END) as enrolled_count,
        COUNT(CASE WHEN r.r_status = '1' THEN 1 END) as pending_count
        FROM tb_course c
        LEFT JOIN tb_registration r ON c.c_code = r.r_course
        WHERE c.c_code = '$course_code'
        GROUP BY c.c_code";
$result = mysqli_query($con, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Course not found";
    header("Location: staff.php");
    exit();
}

$course = mysqli_fetch_assoc($result);

// Check if course has enrolled or pending students
if ($course['enrolled_count'] > 0 || $course['pending_count'] > 0) {
    $_SESSION['error'] = "Cannot delete course: Has " . 
                        $course['enrolled_count'] . " enrolled and " . 
                        $course['pending_count'] . " pending students";
    header("Location: staff.php");
    exit();
}

// Process deletion
try {
    // Start transaction
    mysqli_begin_transaction($con);

    // Delete course registrations first (if any exist)
    $sql_reg = "DELETE FROM tb_registration WHERE r_course = '$course_code'";
    if (!mysqli_query($con, $sql_reg)) {
        throw new Exception("Error deleting course registrations: " . mysqli_error($con));
    }

    // Delete the course
    $sql_course = "DELETE FROM tb_course WHERE c_code = '$course_code'";
    if (!mysqli_query($con, $sql_course)) {
        throw new Exception("Error deleting course: " . mysqli_error($con));
    }

    // Commit transaction
    mysqli_commit($con);
    
    $_SESSION['success'] = "Course deleted successfully";
    header("Location: staff.php");
    exit();

} catch (Exception $e) {
    // Rollback transaction on error
    mysqli_rollback($con);
    
    $_SESSION['error'] = $e->getMessage();
    header("Location: staff.php");
    exit();
}
?> 