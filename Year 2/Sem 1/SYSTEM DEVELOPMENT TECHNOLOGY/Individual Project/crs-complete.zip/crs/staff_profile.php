<?php 
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

$staff_id = $_SESSION['u_sno'];

// Fetch staff details
$sql = "SELECT * FROM tb_user WHERE u_sno = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param('s', $staff_id);
$stmt->execute();
$result = $stmt->get_result();
$staff = mysqli_fetch_assoc($result);
?>

<div class="container py-4">
    <!-- Modern Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb bg-white shadow-sm p-3 rounded-3 border">
            <li class="breadcrumb-item">
                <a href="staff.php" class="text-decoration-none">
                    <i class="fas fa-home text-primary"></i> Dashboard
                </a>
            </li>
            <li class="breadcrumb-item active">
                <i class="fas fa-user-circle text-primary"></i> My Profile
            </li>
        </ol>
    </nav>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 rounded-3 mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Profile Card -->
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                <div class="card-body text-center p-4">
                    <div class="profile-image-wrapper mb-4">
                        <?php if (!empty($staff['u_profile_pic'])): ?>
                            <img src="<?php echo htmlspecialchars($staff['u_profile_pic']); ?>" 
                                 class="profile-image" 
                                 alt="Profile Picture">
                        <?php else: ?>
                            <div class="default-profile-image">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <h4 class="fw-bold mb-1"><?php echo htmlspecialchars($staff['u_name']); ?></h4>
                    <p class="text-muted mb-3">
                        <i class="fas fa-id-badge me-2"></i>
                        <?php echo htmlspecialchars($staff['u_sno']); ?>
                    </p>
                    <a href="edit_staff_profile.php" class="btn btn-primary w-100">
                        <i class="fas fa-edit me-2"></i>Edit Profile
                    </a>
                </div>
            </div>
        </div>

        <!-- Information Cards -->
        <div class="col-md-8">
            <div class="row g-4">
                <!-- Contact Information -->
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div class="card-header bg-transparent border-0 pt-4 pb-0">
                            <h5 class="mb-0">
                                <i class="fas fa-address-card text-primary me-2"></i>
                                Contact Information
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">Email Address</label>
                                        <p class="mb-0">
                                            <a href="mailto:<?php echo htmlspecialchars($staff['u_email']); ?>" 
                                               class="text-decoration-none d-flex align-items-center">
                                                <i class="fas fa-envelope text-primary me-2"></i>
                                                <?php echo htmlspecialchars($staff['u_email']); ?>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">Phone Number</label>
                                        <p class="mb-0">
                                            <a href="tel:<?php echo htmlspecialchars($staff['u_contact']); ?>" 
                                               class="text-decoration-none d-flex align-items-center">
                                                <i class="fas fa-phone text-primary me-2"></i>
                                                <?php echo htmlspecialchars($staff['u_contact']); ?>
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personal Information -->
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-3">
                        <div class="card-header bg-transparent border-0 pt-4 pb-0">
                            <h5 class="mb-0">
                                <i class="fas fa-user text-primary me-2"></i>
                                Personal Information
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">Gender</label>
                                        <p class="mb-0">
                                            <i class="fas fa-venus-mars text-primary me-2"></i>
                                            <?php echo htmlspecialchars($staff['u_gender'] ?? 'Not Specified'); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">Date of Birth</label>
                                        <p class="mb-0">
                                            <i class="fas fa-birthday-cake text-primary me-2"></i>
                                            <?php echo $staff['u_dob'] ? date('d F Y', strtotime($staff['u_dob'])) : 'Not Specified'; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Address Information -->
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-3">
                        <div class="card-header bg-transparent border-0 pt-4 pb-0">
                            <h5 class="mb-0">
                                <i class="fas fa-map-marked-alt text-primary me-2"></i>
                                Location Information
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">State</label>
                                        <p class="mb-0">
                                            <i class="fas fa-map-marker-alt text-primary me-2"></i>
                                            <?php echo htmlspecialchars($staff['u_state'] ?? 'Not Specified'); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label class="text-muted mb-2">Address</label>
                                        <p class="mb-0">
                                            <i class="fas fa-home text-primary me-2"></i>
                                            <?php echo nl2br(htmlspecialchars($staff['u_address'] ?? 'Not Specified')); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Profile Picture</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center p-4">
                <img src="" id="fullImage" class="img-fluid rounded" alt="Full Profile Picture">
            </div>
        </div>
    </div>
</div>

<style>
.default-profile-image {
    width: 100%;
    height: 100%;
    background: #f0f2f5;  /* Light gray background */
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #8e9093;  /* Gray icon color */
    font-size: 4rem;
    border: none;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.profile-image-wrapper {
    width: 150px;
    height: 150px;
    margin: 0 auto;
    position: relative;
}

.profile-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.card {
    transition: transform 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
}

.info-item {
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 0.5rem;
    height: 100%;
}

.info-item label {
    font-size: 0.875rem;
    font-weight: 500;
}

.info-item p {
    font-size: 1rem;
    color: #333;
}

.breadcrumb {
    font-size: 0.9rem;
}

@media (max-width: 768px) {
    .profile-image-wrapper {
        width: 120px;
        height: 120px;
    }
}
</style>

<script>
function showFullImage(src) {
    document.getElementById('fullImage').src = src;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
</script>

<?php include 'footer.php'; ?> 