<?php
require_once 'includes/email_helper.php';

// Test the email function
$result = sendWelcomeEmail(
    'yeewen1214@gmail.com',  // Replace with your test email address
    'Test User',
    'Student'
);

if($result) {
    echo "Test email sent successfully!";
} else {
    echo "Failed to send test email.";
} 