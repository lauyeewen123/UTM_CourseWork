<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

$lecturer_id = $_SESSION['funame'];
$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    error_log("POST Data: " . print_r($_POST, true));  // Debug POST data
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $contact = mysqli_real_escape_string($con, $_POST['contact']);
    $gender = $_POST['gender'];
    if (!in_array($gender, ['Male', 'Female'])) {
        $gender = null; // or set a default value
    }
    $dob = mysqli_real_escape_string($con, $_POST['dob']);
    $state = mysqli_real_escape_string($con, $_POST['state']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Verify current password
    $verify_sql = "SELECT u_pwd FROM tb_user WHERE u_sno = ?";
    if ($stmt = mysqli_prepare($con, $verify_sql)) {
        mysqli_stmt_bind_param($stmt, "s", $lecturer_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);

        if ($user && password_verify($current_password, $user['u_pwd'])) {
            // Update profile information
            $update_sql = "UPDATE tb_user SET 
                          u_name = ?, 
                          u_email = ?, 
                          u_contact = ?,
                          u_gender = ?,
                          u_dob = ?,
                          u_state = ?,
                          u_address = ?
                          WHERE u_sno = ?";
            if ($stmt = mysqli_prepare($con, $update_sql)) {
                mysqli_stmt_bind_param($stmt, "ssssssss", 
                    $name, $email, $contact, $gender, $dob, $state, $address, $lecturer_id);
                $result = mysqli_stmt_execute($stmt);
                error_log("Update result: " . ($result ? "Success" : "Failed"));  // Debug update result
                if (!$result) {
                    error_log("SQL Error: " . mysqli_stmt_error($stmt));  // Debug SQL error
                }
            }

            // Update password if provided
            if (!empty($new_password) && $new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $password_sql = "UPDATE tb_user SET u_pwd = ? WHERE u_sno = ?";
                if ($stmt = mysqli_prepare($con, $password_sql)) {
                    mysqli_stmt_bind_param($stmt, "ss", $hashed_password, $lecturer_id);
                    mysqli_stmt_execute($stmt);
                }
            }

            $success_message = "Profile updated successfully!";
        } else {
            $error_message = "Current password is incorrect.";
        }
    }
}

// Get lecturer details
$sql = "SELECT * FROM tb_user WHERE u_sno = ? AND u_utype = '1'";
if ($stmt = mysqli_prepare($con, $sql)) {
    mysqli_stmt_bind_param($stmt, "s", $lecturer_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $lecturer = mysqli_fetch_assoc($result);
} else {
    die("Query failed: " . mysqli_error($con));
}
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="lecturer_profile.php">My Profile</a></li>
            <li class="breadcrumb-item active">Edit Profile</li>
        </ol>
    </nav>

    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Edit Profile</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="" id="editProfileForm" onsubmit="return confirmUpdate(event)">
                <!-- Basic Information Section -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-user me-2"></i>Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Staff ID</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($lecturer['u_sno']); ?>" readonly>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($lecturer['u_name']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($lecturer['u_email']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="text" class="form-control" name="contact" value="<?php echo htmlspecialchars($lecturer['u_contact']); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" <?php echo ($lecturer['u_gender'] === 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($lecturer['u_gender'] === 'Female') ? 'selected' : ''; ?>>Female</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="dob" value="<?php echo htmlspecialchars($lecturer['u_dob']); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">State</label>
                                <input type="text" class="form-control" name="state" value="<?php echo htmlspecialchars($lecturer['u_state']); ?>">
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($lecturer['u_address']); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Password Change Section -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0"><i class="fas fa-lock me-2"></i>Change Password</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <div class="password-requirements">
                                    <h6><i class="fas fa-info-circle me-2"></i>Password Requirements:</h6>
                                    <ul class="requirements-list">
                                        <li id="length">
                                            <i class="fas fa-check"></i>
                                            At least 8 characters long
                                        </li>
                                        <li id="uppercase">
                                            <i class="fas fa-check"></i>
                                            Contains at least one uppercase letter
                                        </li>
                                        <li id="lowercase">
                                            <i class="fas fa-check"></i>
                                            Contains at least one lowercase letter
                                        </li>
                                        <li id="number">
                                            <i class="fas fa-check"></i>
                                            Contains at least one number
                                        </li>
                                        <li id="special">
                                            <i class="fas fa-check"></i>
                                            Contains at least one special character
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="form-label">Current Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="current_password" id="currentPassword" required>
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('currentPassword')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">New Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="new_password" id="newPassword">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('newPassword')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                                <small class="text-muted">Leave blank if you don't want to change the password</small>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="confirm_password" id="confirmPassword">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('confirmPassword')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-flex gap-2 justify-content-end">
                    <a href="lecturer_profile.php" class="btn btn-light">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Changes
                    </button>
                </div>
            </form>
            <br><br><br>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0,0,0,0.05);
}

.card-header {
    border-bottom: 1px solid rgba(0,0,0,0.05);
}

.form-control:read-only {
    background-color: #f8f9fa;
}

.form-label {
    font-weight: 500;
    color: #2c3e50;
}

.alert-info {
    background-color: #f8f9fa;
    border-color: #e9ecef;
    color: #2c3e50;
}

.alert-info ul {
    padding-left: 1.2rem;
}

.btn-light {
    background-color: #f8f9fa;
    border-color: #e9ecef;
}

.btn-light:hover {
    background-color: #e9ecef;
    border-color: #dde2e6;
}

.input-group .btn {
    z-index: 0;
}

.password-requirements {
    background-color: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 1rem;
}

.requirements-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.requirements-list li {
    margin-bottom: 0.5rem;
    color: #6c757d;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.requirements-list li i {
    color: #ccc;
    transition: color 0.3s ease;
}

.requirements-list li.valid {
    color: #198754;
}

.requirements-list li.valid i {
    color: #198754;
}
</style>

<script>
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const type = input.type === 'password' ? 'text' : 'password';
    input.type = type;
    
    // Toggle eye icon
    const icon = event.currentTarget.querySelector('i');
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
}

function validatePassword(password) {
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };

    Object.keys(requirements).forEach(requirement => {
        const element = document.getElementById(requirement);
        if (requirements[requirement]) {
            element.classList.add('valid');
        } else {
            element.classList.remove('valid');
        }
    });

    return Object.values(requirements).every(Boolean);
}

document.getElementById('newPassword').addEventListener('input', function() {
    validatePassword(this.value);
});

function confirmUpdate(event) {
    event.preventDefault();
    
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword) {
        if (!validatePassword(newPassword)) {
            Swal.fire({
                title: 'Invalid Password',
                text: 'Please make sure your password meets all requirements.',
                icon: 'error'
            });
            return false;
        }
        
        if (newPassword !== confirmPassword) {
            Swal.fire({
                title: 'Password Mismatch',
                text: 'New password and confirm password do not match.',
                icon: 'error'
            });
            return false;
        }
    }
    
    Swal.fire({
        title: 'Confirm Update',
        text: 'Are you sure you want to update your profile?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, update it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('editProfileForm').submit();
        }
    });

    
    return false;
}
</script>

<!-- Add SweetAlert2 library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php include 'footer.php'; ?> 