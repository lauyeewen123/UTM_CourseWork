<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}
include 'headeradvisor.php';
include 'dbconnect.php';

// Get student ID from URL
$student_id = filter_var($_GET['id'], FILTER_SANITIZE_STRING);
$lecturer_id = $_SESSION['funame'];

// Get student details
$stmt = $con->prepare("
    SELECT DISTINCT u.*, 
           COUNT(DISTINCT r.r_course) as total_courses
    FROM tb_user u
    JOIN tb_registration r ON u.u_sno = r.r_student
    JOIN tb_course c ON r.r_course = c.c_code
    WHERE u.u_sno = ? AND c.c_lec = ?
    GROUP BY u.u_sno
");
$stmt->bind_param("ss", $student_id, $lecturer_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    $_SESSION['error'] = "Student not found or access denied";
    header('Location: advisor.php');
    exit();
}
?>

<div class="container py-4">
    <div class="row">
        <div class="col-12 mb-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="advisor.php">Dashboard</a></li>
                    <li class="breadcrumb-item active">Student Details</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <!-- Student Profile Card -->
            <div class="card mb-4">
                <div class="card-body text-center">
                    <img src="https://via.placeholder.com/150" class="rounded-circle mb-3" alt="Profile Picture">
                    <h4 class="card-title"><?php echo htmlspecialchars($student['u_name']); ?></h4>
                    <p class="text-muted mb-1"><?php echo htmlspecialchars($student['u_sno']); ?></p>
                    <p class="text-muted mb-4">Student</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Email</span>
                        <span class="text-primary"><?php echo htmlspecialchars($student['u_email']); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Contact</span>
                        <span><?php echo htmlspecialchars($student['u_contact']); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>State</span>
                        <span><?php echo htmlspecialchars($student['u_state']); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Total Courses</span>
                        <span class="badge bg-primary rounded-pill"><?php echo $student['total_courses']; ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="col-md-8">
            <!-- Course Registrations -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Course Registrations</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="courseTable">
                            <thead>
                                <tr>
                                    <th>Course Code</th>
                                    <th>Course Name</th>
                                    <th>Credit</th>
                                    <th>Status</th>
                                    <th>Registration Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $con->prepare("
                                    SELECT r.*, c.c_name, c.c_credit, s.s_desc
                                    FROM tb_registration r
                                    JOIN tb_course c ON r.r_course = c.c_code
                                    JOIN tb_status s ON r.r_status = s.s_id
                                    WHERE r.r_student = ? AND c.c_lec = ?
                                    ORDER BY r.r_date DESC
                                ");
                                $stmt->bind_param("ss", $student_id, $lecturer_id);
                                $stmt->execute();
                                $result = $stmt->get_result();

                                while ($reg = $result->fetch_assoc()) {
                                    $statusClass = ($reg['r_status'] == '1') ? 'warning' : 
                                                 (($reg['r_status'] == '2') ? 'success' : 'danger');
                                    
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($reg['r_course']) . "</td>";
                                    echo "<td>" . htmlspecialchars($reg['c_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($reg['c_credit']) . "</td>";
                                    echo "<td><span class='badge bg-{$statusClass}'>" . 
                                         htmlspecialchars($reg['s_desc']) . "</span></td>";
                                    echo "<td>" . date('Y-m-d', strtotime($reg['r_date'])) . "</td>";
                                    echo "<td>
                                            <a href='courseapprovalprocess.php?id=" . $reg['r_tid'] . "' 
                                               class='btn btn-sm btn-primary'>Update Status</a>
                                          </td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#courseTable').DataTable({
        "pageLength": 10,
        "order": [[4, "desc"]]
    });
});
</script>

<?php include 'footer.php'; ?> 