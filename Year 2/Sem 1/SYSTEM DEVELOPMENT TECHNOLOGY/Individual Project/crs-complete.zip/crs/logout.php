<?php

session_start();
$_SESSION['success'] = 'You have been successfully logged out.';
session_destroy();
header('Location: login.php');
exit();
?>