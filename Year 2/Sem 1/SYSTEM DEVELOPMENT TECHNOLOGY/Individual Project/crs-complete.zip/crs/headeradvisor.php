<!DOCTYPE html>
<html lang="en">
<head>
  <title>Course Registration System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

  <style>
  :root {
    --primary-blue: #4285f4;      /* Softer Google Blue */
    --secondary-blue: #5c9fff;    /* Light Blue */
    --hover-blue: #1a73e8;        /* Accent Blue */
    --light-blue: #f3f8ff;        /* Very Light Blue Background */
    --white: #ffffff;
  }

  .navbar {
    background: linear-gradient(135deg, var(--primary-blue) 0%, var(--hover-blue) 100%) !important;
    padding: 1rem 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }

  .navbar-brand {
    font-size: 1.4rem;
    font-weight: 600;
    color: var(--white) !important;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .navbar-brand i {
    font-size: 1.5rem;
  }

  .nav-link {
    color: var(--white) !important;
    padding: 0.7rem 1.2rem !important;
    border-radius: 6px;
    transition: all 0.2s ease;
    font-weight: 500;
    opacity: 0.9;
  }

  .nav-link:hover {
    background-color: rgba(255,255,255,0.1);
    opacity: 1;
  }

  .nav-link.active {
    background-color: rgba(255,255,255,0.2);
    opacity: 1;
  }

  .navbar-nav {
    gap: 0.3rem;
  }

  /* Special styling for action buttons */
  .nav-action {
    background: rgba(255,255,255,0.1);
    border-radius: 6px;
    margin: 0 0.2rem;
  }

  .nav-action:hover {
    background: rgba(255,255,255,0.2);
  }

  /* Logout button */
  .nav-link.logout {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.3);
  }

  .nav-link.logout:hover {
    background: rgba(255,255,255,0.25);
  }

  /* Search form styling */
  .d-flex .form-control {
    border: none;
    border-radius: 6px;
    padding: 0.6rem 1rem;
    background: rgba(255,255,255,0.1);
    color: white;
  }

  .d-flex .form-control::placeholder {
    color: rgba(255,255,255,0.7);
  }

  .d-flex .btn-secondary {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.3);
    color: white;
    padding: 0.6rem 1.2rem;
    transition: all 0.2s ease;
  }

  .d-flex .btn-secondary:hover {
    background: rgba(255,255,255,0.25);
  }

  @media (max-width: 991.98px) {
    .navbar-nav {
      padding: 1rem 0;
    }
    .nav-link {
      padding: 0.8rem 1rem !important;
    }
  }

  /* Add these styles to your existing CSS */
  .dropdown-menu {
    background: var(--white);
    border: none;
    box-shadow: 0 2px 15px rgba(0,0,0,0.1);
    border-radius: 8px;
    margin-top: 0.5rem;
  }

  .dropdown-item {
    padding: 0.7rem 1.2rem;
    color: #333;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s ease;
  }

  .dropdown-item:hover {
    background: var(--light-blue);
    color: var(--primary-blue);
  }

  .dropdown-item i {
    width: 20px;
    text-align: center;
  }

  .navbar .nav-link.dropdown-toggle::after {
    margin-left: 0.5rem;
  }

  /* Active state for dropdown items */
  .dropdown-item.active, 
  .dropdown-item:active {
    background-color: var(--primary-blue);
    color: white;
  }
  </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">
            <i class="fas fa-graduation-cap me-2"></i>CRS Academic Advisor
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="advisor.php">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                </li>
                
                <!-- Courses Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="coursesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-book"></i> Courses
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="courselist.php">
                                <i class="fas fa-list-ul"></i> View All Courses
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Overview Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="overviewDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-chart-bar"></i> Overview
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="view_student_list.php">
                                <i class="fas fa-graduation-cap"></i> Course Overview
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>

            <!-- Right-aligned menu items -->
            <ul class="navbar-nav ms-auto">
                <!-- Add Profile Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> Profile
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="lecturer_profile.php">
                                <i class="fas fa-user"></i> View Profile
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="edit_lecturer_profile.php">
                                <i class="fas fa-edit"></i> Edit Profile
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
