<?php
require_once 'session_config.php';
checkITStaffLogin();

include('headerit.php');
include('dbconnect.php');

// Get all students
$sql = "SELECT u.*, 
        (SELECT COUNT(*) FROM tb_registration r WHERE r.r_student = u.u_sno AND r_status = '2') as enrolled_courses
        FROM tb_user u 
        WHERE u.u_utype = '2' 
        ORDER BY u.u_name";
$result = mysqli_query($con, $sql);
?>

<div class="container py-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a href="staff.php" class="btn btn-secondary me-3">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
                <h4 class="mb-0">Student List</h4>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="studentsTable">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>State</th>
                            <th>Enrolled Courses</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['u_sno']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_email']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_contact']); ?></td>
                                <td><?php echo htmlspecialchars($row['u_state']); ?></td>
                                <td><?php echo $row['enrolled_courses']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables -->
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#studentsTable').DataTable({
        "pageLength": 25
    });
});
</script>

<?php include 'footer.php'; ?> 