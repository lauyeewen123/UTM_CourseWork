<?php
// Remove or comment out session_start() from this file since it's already handled in the main files
// session_start();  // Remove this line

if(!session_id()) {
    session_start();
}

// General login check function
function checkLogin() {
    if(isset($_SESSION['u_sno']) != session_id()) {
        header('Location: login.php');
        exit();
    }

    // Session timeout check
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
        session_unset();
        session_destroy();
        header("Location: login.php?error=session_timeout");
        exit();
    }

    $_SESSION['last_activity'] = time();
}

// Specific user type checks
function checkITStaffLogin() {
    checkLogin();
    if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== "itstaff") {
        header("Location: login.php?error=unauthorized");
        exit();
    }
}

function checkStudentLogin() {
    checkLogin();
    if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== "student") {
        header("Location: login.php?error=unauthorized");
        exit();
    }
}

function checkAdvisorLogin() {
    checkLogin();
    if (!isset($_SESSION['usertype']) || $_SESSION['usertype'] !== "advisor") {
        header("Location: login.php?error=unauthorized");
        exit();
    }
}
?> 