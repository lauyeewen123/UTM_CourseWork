<?php 

include('crssession.php');

if(!session_id())
{
  session_start();
}

include 'headeradvisor.php';?>

<div class="container">

Lecturer page

</div>

<?php include 'footer.php';?>
