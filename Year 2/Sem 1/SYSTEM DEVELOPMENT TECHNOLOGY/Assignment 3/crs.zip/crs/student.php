<?php 
include('crssession.php');

if(!session_id())
{
  session_start();
}

include 'headerstudent.php';
?>


<div class="container">

Student page

</div>

<?php include 'footer.php';?>
