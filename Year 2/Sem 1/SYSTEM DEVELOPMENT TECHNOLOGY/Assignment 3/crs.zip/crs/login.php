<?php include 'headermain.php';?>

<div class="container">
  
  <br><br><h5>Login</h5><br>
  <form method="POST" action="loginprocess.php">
  <fieldset>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4">Please enter your staff or student number</label>
      <input type="text" name="funame" class="form-control"  aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Enter password</label>
      <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Enter your password" autocomplete="off" required>
    </div>

    <br><br>

     <button type="Submit" class="btn btn-primary" >Login</button>
     <br><br><br>
   </fieldset>
 </form>
</div>




<?php include 'footer.php';?>