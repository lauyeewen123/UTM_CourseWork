<?php
//Connect to DB
include('dbconnect.php');

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];
$femail = $_POST['femail'];
$fname = $_POST['fname'];
$fcontact = $_POST['fcontact'];
$fstate = $_POST['fstate'];

//SQL Insert operation
$sql = "INSERT INTO tb_user(u_sno, u_pwd, u_email, u_name, u_contact, u_state, u_req, u_utype)
		VALUES ('$funame','$fpwd','$femail','$fname','$fcontact','$fstate',CURRENT_TIMESTAMP(),'2')";

//Execute SQl
mysqli_query($con, $sql);

//Close connection
mysqli_close($con);

//Confirmation registration successful or fail (individual project)

//Redirect user to login page
header('Location: login.php');

?>