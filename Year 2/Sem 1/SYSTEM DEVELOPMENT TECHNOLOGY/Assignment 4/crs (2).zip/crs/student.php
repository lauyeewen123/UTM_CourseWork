<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}

include 'headerstudent.php';
?>


<div class="container">
Student Page



</div>

<?php include 'footer.php';?>



