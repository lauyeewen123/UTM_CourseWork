<?php
session_start();



//Connect to DB
include('dbconnect.php');

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];


//SQL retrieve operation to get user data from DB

$sql = "SELECT * FROM tb_user
		WHERE u_sno='$funame' AND u_pwd= '$fpwd'";


//Execute SQL
$result= mysqli_query($con,$sql);

//Retrieve data
$row = mysqli_fetch_array($result);

//count result to check
$count = mysqli_num_rows($result);

//Rule-based AI login
if($count == 1) //Check user exist
{
	//Set session
	$_SESSION['u_sno'] = session_id();
	$_SESSION['funame'] = $funame; //can give any name, not variable

	if($row['u_utype'] == 1) //Check user type
	{
		//Lecturer
		header('Location: lecturer.php'); 
	}

	if($row['u_utype'] == 2) //Check user type
	{
		//Lecturer
		header('Location: student.php'); 

	}

	if($row['u_utype'] == 3) //Check user type
	{
		//Lecturer
		header('Location: staff.php'); 

	}
}

else // user not found
{
	//Redirect to login error page (individual project)
	header('Location: login.php'); //Temp redirect page
}

//Close connection
mysqli_close($con);


?>