<?php include 'headermain.php';?>


<div class="container">
<br><h5>Please fill all following details</h5>
 <form method= "POST" action="registerprocess.php">
  <fieldset>
    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Please enter your staff or student number</label>
      <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
    </div>

    <div>
      <label for="exampleInputPassword1" class="form-label mt-4">Create your Password</label>
      <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create Password" autocomplete="off" fdprocessedid="01aawe" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Email address</label>
      <input type="email" name="femail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
    </div>
    
     <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Enter your full names</label>
      <input type="text" name="fname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your full name according to IC" required>
    </div>

    <div>
      <label for="exampleInputEmail1" class="form-label mt-4"> Enter your contact number</label>
      <input type="text" name="fcontact" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your mobile or fixed line number" required> 
    </div>
    

    <div>
      <label for="exampleSelect1" class="form-label mt-4">Select your state</label>
      <select class="form-select" name="fstate" id="exampleSelect1" fdprocessedid="nz1zx"> 
        <option>Johor</option>
        <option>Kedah</option>
        <option>Kelantan</option>
        <option>Melaka</option>
        <option>Negeri Sembilan</option>
        <option>Pahang</option>
        <option>Pulau Pinang</option>
        <option>Perak</option>
        <option>Perlis</option>
        <option>Sabah</option>
        <option>Sarawak</option>
        <option>Selangor</option>
        <option>Terengganu</option>
        <option>W.P Kuala Lumpur</option>
        <option>W.P Labuan</option>
        <option>W.P Putrajaa</option>
      </select>
    </div><br>
    <button type="submit" class="btn btn-primary">Submit</button>
    <button type="reset" class="btn btn-danger">Clear form</button>
    <br><br><br><br><br>
    </fieldset>
  </form>    
  

</div>

<?php include 'footer.php';?>



