<?php 
include('crssession.php');
if(!session_id())
{
	session_start();
}

include 'headerlec.php';
?>


<div class="container">
Lecture Page


</div>

<?php include 'footer.php';?>



